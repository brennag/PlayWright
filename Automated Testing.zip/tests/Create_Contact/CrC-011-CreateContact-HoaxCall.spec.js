const {test, expect} = require ('@playwright/test');
const testdata =JSON.parse(JSON.stringify(require('../../testdata/data.json')));
const{PageObjects} = require('../../pageobjects/PageObjects')
const {appendToLogFile } = require('../testlogs');

test('CRC-011', async ({browser}) =>
    {
        appendToLogFile(`\n=======================${__filename}==========================`)
        const context = await browser.newContext();
        const page = await context.newPage();

        const pages=new PageObjects(page)
        const {loginpage,Contactformpage,SearchCommentspage,RecentlistContactSearchpage,ContactformTagspage} =pages

        await loginpage.goTO()
        await loginpage.validLogin(testdata.FCOusername,testdata.FCOpassword,testdata.FCOposition)
        await loginpage.waitForNewPageAndCheckTitle()

        const Incidentlocation ='FLAT 3 69 ATLANTIC ROAD LONDON SW9 8P'
        const IncidentType ='P11'
        const IncidentSubType='PQ41'

        //creating a contact 
        await Contactformpage.SaveCallerDetails('ram','1992-07-25','Third Party','999 Emergency','9273739',null,'ARCH 280 COLDHARBOUR LANE LONDON SW9 8SE')
        const Contact_ID = await Contactformpage.createcontact(Incidentlocation,IncidentType,IncidentSubType)

        //hovering over the Hoax call button it shows Hoax Call
        await page.pause()
        await page.hover("dialog-run-script-icon[name='(LBL_CALLTAKER_hoax_call)']")
        const title = await page.locator("dialog-run-script-icon[name='(LBL_CALLTAKER_hoax_call)'] button").getAttribute('title')
        await expect(title).toEqual('Hoax Call')
        await page.waitForTimeout(2000)

        //Hoax Call dialog
        await Contactformpage.HoaxCall.click()
        await expect(page.locator("//*[contains(@class,'dialog-header flex-row flex-justify-space-between ng-scope')]")).toContainText('Hoax Call')//verifying hoax call dialog
        appendToLogFile('Hoax Call Dialog displayed')
        //Complete the list of predefined statements and questions in the Dialog
        const callername ='Steven'
        await page.locator("input[name='(LBL_HOAX_CONTINUE?)']").click()
        await page.locator("input[name='(LBL_HOAX_VOICERECORD)']").click()
        await page.locator("input[name='(LBL_HOAX_PROSECUTED)']").click()
        await page.locator("input[name='(LBL_HOAX_NAME)']").fill(callername)
        await page.locator("input[name='(LBL_HOAX_MOBILEPHONE)']").click()
        await page.locator("input[name='(LBL_HOAX_NOATTENDANCE)']").click()
        await page.locator(".btn.btn-primary.submit-btn.cd-tabbable.ng-binding").click()

        //checking whether the dialog closed
        await expect(page.locator("//*[contains(@class,'dialog-header flex-row flex-justify-space-between ng-scope')]")).toBeHidden()
        appendToLogFile("Hoax Call Dialog closed")

        //Search Comments reflect the answers provided in the Hoax call dialog.

        const comments1=`CALL CHALLENGE - HOAX CALL: COMPLETE`
        const comments2 =`The caller was asked if this is a hoax call`
        const comments3 =`The caller was asked if they know that their voice is being recorded.`
        const comments4=`The caller was asked if they realised that if this is a hoax call, they may be prosecuted.`
        const comments5=`The caller was asked what their name is: ${callername}`
        const comments6 =`Call Type: Mobile`
        const comments7=`Suspected/Hoax Call – NO attendance required: Yes`
        await SearchCommentspage.searchcomments(comments1)
        await SearchCommentspage.searchcomments(comments2)
        await SearchCommentspage.searchcomments(comments3)
        await SearchCommentspage.searchcomments(comments4)
        await SearchCommentspage.searchcomments(comments5)
        await SearchCommentspage.searchcomments(comments6)
        await SearchCommentspage.searchcomments(comments7)

        //Review the tags on the contact
        const searchtag ='Call Challenge'
        const selectedtags =await ContactformTagspage.contactformtags()
        let found =false;
        for (let tag of selectedtags) {
            if (tag.trim() === searchtag)
                 {  
                appendToLogFile(`Pass:${searchtag} tag has been added.`);
                found = true;
                break; 
            }
        }
        if(!found){
                appendToLogFile(`False:${searchtag} tag not found.`)
        }
        
        //Observe that there is no access for the calltaker to the Incident board.
        await expect(page.locator("li[title='Incidents']")).toBeHidden()
        appendToLogFile("Incident board not visible to call taker.")

        //Review the Contact Board for the contact that has just been saved
        await RecentlistContactSearchpage.recentlistcontactsearch(Contact_ID)
        appendToLogFile('Test Passed')
    }
)