const {test, expect} = require ('@playwright/test');
const testdata =JSON.parse(JSON.stringify(require('../../testdata/data.json')));
const {login} =require('../../pageobjects/General/login')
const{InvokeCommand}=require('../../pageobjects/General/InvokeCommand')
const{DialogOpen}=require('../../pageobjects/General/DialogOpen')
const{IncidentSearchwithDateTime}=require('../../pageobjects/Incident/IncidentSearchwithDateTime')
const{PageObjects}=require('../../pageobjects/PageObjects')
test('dialog validation' ,async({browser}) =>
{
    const context = await browser.newContext();
    const page = await context.newPage();
    const pages = new PageObjects(page)
    const{loginpage,InvokeCommandpage,DialogOpenpage,IncidentAdvSearchpage}=pages
 


    const IncidentSearchwithDateTimepage = new IncidentSearchwithDateTime(page)
    await loginpage.goTO()
    await loginpage.validLogin(testdata.Supervisorusername,testdata.Supervisorpassword,testdata.Supervisorposition)
    const Mappage = await loginpage.waitForNewPageAndCheckTitle()
    // await InvokeCommandpage.invokecommand('create incident')

    // const Dialogname = 'create incident'
    // const dialogvalid =await DialogOpenPage.DialogOpen(Dialogname)
    // if(dialogvalid==0){
    //     console.log("Dialog opened")
    // }
    // let res =await closeIncidentpage.closeIncident('MPS20210409000003','C01 - Violence Against the Person','Contact Record','205 - Rowdy Behaviour','700','Supervisor - Ready to Close')
    // console.log(res)
    // console.log(await IncidentAdvSearchpage.incidentAdvSearch(null,'MPS20250610000010',null))
    let id =await IncidentSearchwithDateTimepage.incidentsearchwithdatetime(['10','6','2025'],['10','6','2025'],['8','25'],['13','19'],'Vehicle - Theft of','BRICK KILN QUAY SAXMUNDHAM ROAD ALDEBURGH IP15 5PD')
    console.log(id)
    await page.pause()

}

)