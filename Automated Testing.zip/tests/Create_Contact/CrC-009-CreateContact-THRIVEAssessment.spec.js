const {test, expect} = require ('@playwright/test');
const testdata =JSON.parse(JSON.stringify(require('../../testdata/data.json')));
const { appendToLogFile } = require('../testlogs');
//const {SelectIncident}=require('../../pageobjects/Incident/SelectIncidents')
const{PageObjects}=require('../../pageobjects/PageObjects')
test ('CrC-009', async({browser}) => {
    appendToLogFile(`\n=======================${__filename}==========================`)
    const context = await browser.newContext();
    const page = await context.newPage();
    const pages = new PageObjects(page)
    const{loginpage,Contactformpage,SearchCommentspage,Thrivepage,RecentlistContactSearchpage,logoutpage,SelectIncidentpage}=pages;
    //Loginto Oncall Application
    //console.log ('CrC-009 Create Contact - THRIVE+ Assessment');
    await loginpage.goTO()
    await loginpage.validLogin(testdata.FCOusername,testdata.FCOpassword,testdata.FCOposition);
    let Mappage= await loginpage.waitForNewPageAndCheckTitle()
    appendToLogFile("Pass: Successfully logged in as FCO");
    //const SelectIncidentPage= new SelectIncident (Mappage);
    const Incidentlocation ='FLAT 3 69 ATLANTIC ROAD LONDON SW9 8P'
    const IncidentType ='P15'
    const IncidentSubType='PQ54'
    const values = [['Property', 'Damage to property', 'Threat Assessment Comment'], ['Medium', 'Environmental harm', 'Harm Assessment Comment'],['Medium', 'Risk Assessment Comment'], ['Yes', 'Suspect seen', 'Investigation Assessment Comment'], ['Low', 'Health or disability', 'Vulnerability Comment'], ['No', 'Attendance', 'Engagement Comment'], ['Prevention Comment'], ['No', 'Local Authority', 'Intervention Comment']];
    const dropdownsAndInputFields = [[`lbl_thrive_who_what`,`lbl_thrive_type_of_threat`, `lbl_thrive_threat_comment`], [`lbl_thrive_likely_level_of_harm`, `lbl_thrive_type_of_harm`, `lbl_thrive_harm_comment`], [`lbl_thrive_risk_level`, `lbl_thrive_risk_comment`], [`lbl_thrive_investigation`, `lbl_thrive_investigation_rationale`, `lbl_thrive_investigation_comment`], [`lbl_thrive_vulnerability`, `lbl_thrive_vulnerability_reason`, `lbl_thrive_vulnerability_comment`], [`lbl_thrive_engagement`, `lbl_thrive_type_of_engagement`, `lbl_thrive_engagement_comment`], [`lbl_thrive_prevention_comment`], [`lbl_thrive_intervention`, `lbl_thrive_intervention_partner_agency`, `lbl_thrive_intervention_comment`]];
    //Steps:1,2 & 3 - Create a contact
    const Contact_ID = await Contactformpage.createcontact(Incidentlocation,IncidentType,IncidentSubType)
    appendToLogFile(`Pass: Contact created:"${Contact_ID}`);
    //Step 4: Click on Run THRIVE+ assessment button
    await page.pause()
    await Contactformpage.RunThrive.click();
    //Step 5 & 6: Click on the 'Full THRIVE+ guidance document' link. & Complete Full THRIVE+ document link
    await Thrivepage.thrive(values);
    await RecentlistContactSearchpage.recentlistcontactsearch(Contact_ID)
    //Step 8: Press Send to Dispatch button
    await Contactformpage.sendtodespatch.click();
    //Step 9: Search for comments
    let comment = `Initial THRIVE+ Assessment Completed\n\nTHREAT: Property - Damage to property\nThreat Assessment Comment\nHARM: Medium - Environmental harm\nHarm Assessment Comment\nRISK: Medium\nRisk Assessment Comment\nINVESTIGATION: Yes - Suspect seen\nInvestigation Assessment Comment\nVULNERABILITY: Low - Health or disability\nVulnerability Comment\nENGAGEMENT: No - Attendance\nEngagement Comment\nPREVENTION: \nPrevention Comment\nINTERVENTION: No - Local Authority\nIntervention Comment`
    await SearchCommentspage.searchcomments(comment);
    await page.pause();
    await logoutpage.logout();
    await page.waitForTimeout(5000)
    //Login as despatcher
    await loginpage.goTO();
    await loginpage.validLogin(testdata.Operatorusername,testdata.Operatorpassword,testdata.Operatorposition);
    Mappage= await loginpage.waitForNewPageAndCheckTitle();

    await SelectIncidentpage.SelectIncident(Contact_ID);
    await SearchCommentspage.searchcomments(comment);
    appendToLogFile('Test Passed')


})

