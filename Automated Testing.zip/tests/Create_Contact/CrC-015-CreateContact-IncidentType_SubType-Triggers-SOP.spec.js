const {test, expect} = require ('@playwright/test');
const testdata =JSON.parse(JSON.stringify(require('../../testdata/data.json')));
const{PageObjects} = require('../../pageobjects/PageObjects')
const {appendToLogFile } = require('../testlogs');


test('CRC-015' ,async({browser})=>
    {
        appendToLogFile(`\n=======================${__filename}==========================`)
        const context = await browser.newContext();
        const page = await context.newPage();
        const pages = new PageObjects(page)
        const {loginpage,Contactformpage,ContactformSOPSearchpage,SOPPanelSOPSearchpage,SOPExecutionpage} =pages
        await loginpage.goTO()
        await loginpage.validLogin(testdata.FCOusername,testdata.FCOpassword,testdata.FCOposition)
        const Mappage =await loginpage.waitForNewPageAndCheckTitle()
        const Incidentlocation ='9A BEDFORD ROAD LONDON SW4 7S'
        const IncidentType ='A02'
        const IncidentSubType='AQ05'
        
        //creating a contact 
        await Contactformpage.SaveCallerDetails('ram','1992-07-25','Third Party','999 Emergency','9273739',null,'ARCH 280 COLDHARBOUR LANE LONDON SW9 8SE')
        const Contact_ID = await Contactformpage.createcontact(Incidentlocation,IncidentType,IncidentSubType)     
        //checking whether SOP added to contact
        const SOPname ='Automation SOP'
        await ContactformSOPSearchpage.ContactformSOPSearch(SOPname)

        //To check SOP added in SOP manager -ALL SOPs
        await SOPPanelSOPSearchpage.SOPPanelSOPSearch(Contact_ID,SOPname)

        
        //SOP Execution
        const taskprogressvalue = await SOPExecutionpage.SOPExecution(SOPname)
        if(taskprogressvalue ==100)
            {
                appendToLogFile("Pass: All SOP tasks executed successfully")
            }
        else{
            appendToLogFile("Fail: All SOP Tasks Not Executed")
        }
        appendToLogFile('Test Passed')


    }
)