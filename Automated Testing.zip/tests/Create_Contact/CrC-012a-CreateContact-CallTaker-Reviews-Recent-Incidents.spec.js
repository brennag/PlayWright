const {test, expect} = require ('@playwright/test');
const testdata =JSON.parse(JSON.stringify(require('../../testdata/data.json')));
const{PageObjects} = require('../../pageobjects/PageObjects')
const {appendToLogFile } = require('../testlogs');


test('CRC-012a' , async({browser}) =>
{
    appendToLogFile(`\n=======================${__filename}==========================`)
    const context = await browser.newContext()
    const page = await context.newPage()
    const pages = new PageObjects(page)
    const {loginpage,Contactformpage,RecentlistContactSearchpage,RecentlistContextMenupage,CloseContactpage,IncidentChronologypage} =pages
    await loginpage.goTO()
    await loginpage.validLogin(testdata.FCOusername,testdata.FCOpassword,testdata.FCOposition)
    const Mappage =await loginpage.waitForNewPageAndCheckTitle()
    const pages1 = new PageObjects(Mappage)
    const{AddCommentspage,SearchCommentspage}=pages1

    //Step1: Create a contact for several incidents each having a different priority
    const Contact1 =await Contactformpage.createcontact('100A ADYS ROAD LONDON SE15 4D','P10','PQ37')
    await page.locator("#clearForm").click()
    const Contact2 =await Contactformpage.createcontact('100A ADYS ROAD LONDON SE15 4D','A02','AQ04')
    await page.locator("#clearForm").click()
    const Contact3 = await Contactformpage.createcontact('100A ADYS ROAD LONDON SE15 4D','P06','PQ19')
    await page.locator("#clearForm").click()
    const Contact4  = await Contactformpage.createcontact('100A ADYS ROAD LONDON SE15 4D','C07','CQ23')
    await page.locator("#clearForm").click()

    await RecentlistContactSearchpage.recentlistcontactsearch(Contact1)
    await RecentlistContactSearchpage.recentlistcontactsearch(Contact2)
    await RecentlistContactSearchpage.recentlistcontactsearch(Contact3)
    await RecentlistContactSearchpage.recentlistcontactsearch(Contact4)
    await page.locator("//a[normalize-space()='Clear Results']").click()

    
    //Step2 : Click on the View as Grid icon : Recent List appears in tabular format.
    await page.locator("button[title='View as Grid']").click()
    const listview =await page.locator("//div[contains(@class,'grid-header HeaderRow')]").isVisible()//checking header row visible in list view
    if(listview){
        appendToLogFile("Pass : Recent List appears in tabular format.")
    }
    else{
        appendToLogFile("Fail : Recent List NOT in tabular format.")
    }
    
    //Step3 : Edit Incident from context menu for one incident
    await page.locator("//button[@title='View as Columns']").click()
    await page.waitForTimeout(1000)
    const Contact_ID =await RecentlistContextMenupage.recentlistContactContextMenu(Contact2,'Edit Contact')
    await Mappage.bringToFront()
    await expect(page.locator(".event-panel-content")).toBeVisible()
    appendToLogFile("Pass : Incident Panel Opened")

    //Step4: Add Remarks and verify
    let remarks ='CRC-012a'
    await AddCommentspage.addcomments(remarks)
    await SearchCommentspage.searchcomments(remarks)
    
    // await page.pause()
    //Step5: Close the incident and open incident chronlogy
    await page.bringToFront()
    await CloseContactpage.closecontact(Contact_ID,remarks,'700')
    // await IncidentContextMenuPage.IncidentContextMenu('Incident Chronology')
    // await page.pause()

    //Step6: A list of comments and remarks entered appears for the Incident with the oldest at the top and showing the Remark.
    let resolution ='Contact closed'
    await IncidentChronologypage.incidentchronology(Contact_ID,resolution)

    //Step7: closing Incident Chronology
    await page.locator("#event-chronology-close-btn").click()
    await expect(page.locator("div[class='dialog-header flex-row']")).toBeHidden()
    appendToLogFile("Pass: The Incident Chronology dialog closed successfullly")
    appendToLogFile('Test Passed')

}


)