const {test, expect} = require ('@playwright/test');
const testdata =JSON.parse(JSON.stringify(require('../../testdata/data.json')));
// const {login} =require('../../pageobjects/General/login')
// const {Contactform}=require('../../pageobjects/CreateContact/Contactform')
const {PageObjects}=require('../../pageobjects/PageObjects')


test('sampletest', async ({browser}) =>
    {
        // appendToLogFile(`\n=========${__filename}==========`)
        const context = await browser.newContext();
        const page = await context.newPage();
  
        const pages = new PageObjects(page);
        const{loginpage,Contactformpage,CommonUtilspage,IncidentBoardSearchpage,InvokeCommandpage,ContactformSOPSearchpage}=pages
        await loginpage.goTO()
        await loginpage.validLogin('paravapalli','Ingr.112233','101/AP')
        const Mappage = await loginpage.waitForNewPageAndCheckTitle()
        await page.pause()
        
        //let type=`C06 - Robbery - Business`
        //let subtype='CQ20 - Suspect Present'
        //const Incident_ID=await Contactformpage.createcontact('87 GLADSTONE STREET ABERTYLERI NP13 1NE',type,subtype)
        // console.log(await DatabaseValidationspage.IncidentvalidationDB())
        //let [Incidentid,Incident_type,IncidentSubtype]=await DatabaseValidationspage.IncidentvalidationDB(Incident_ID)
        //console.log(Incidentid)
        //await expect(Incidentid).toEqual(Incident_ID)
        //await expect(Incident_type).toEqual(type)
        //await expect(IncidentSubtype).toEqual(subtype)
     
        // appendToLogFile("example test runnig")
        // appendToLogFile("example test for dialog validation done")
        
        
        // await ContactformPage.createcontact(null,'A01','AQ01')
        // await page.locator("#COMMAND_DIALOG_COMMENTS").click()
        // await page.locator("div[title='Search for keywords']").click()
        // await page.locator("input[placeholder='Remark Search']").fill('Created the contact')
        // console.log(await page.locator(".remark-metadata").textContent()) 
       

    }
)