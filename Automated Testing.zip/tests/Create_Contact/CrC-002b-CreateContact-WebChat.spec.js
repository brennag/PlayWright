const {test, expect} = require ('@playwright/test');
const testdata =JSON.parse(JSON.stringify(require('../../testdata/data.json')));
const { appendToLogFile } = require('../testlogs'); // Import logging function
const{PageObjects} = require('../../pageobjects/PageObjects')

test('CRC-002b', async ({browser}) =>
    {  
        appendToLogFile(`\n=======================${__filename}==========================`)
        const context = await browser.newContext();
        const page = await context.newPage();
        const pages=new PageObjects(page);
        const{loginpage,Contactformpage,SearchCommentspage,IncidentChronologypage,RemoveNewlinepage,CommonUtilspage}=pages;
        //Step1: Login with the FCO role
        await loginpage.goTO()
        await loginpage.validLogin(testdata.FCOusername,testdata.FCOpassword,testdata.FCOposition)
        const Mappage = await loginpage.waitForNewPageAndCheckTitle()
        appendToLogFile("Pass: Successfully logged in as FCO");

        //Step2: Create Contact using Webchat as source and verify location 
        await Contactformpage.SaveCallerDetails('Test12',null,null,'Webchat','74383920',null,null)
        const Contact1 = await Contactformpage.createcontact('210 DENMARK HILL LONDON SE5 8DX','C12','CQ43')
        // console.log("Pass:Contact created using the Webchat source")
        appendToLogFile("Pass: Contact created using the Webchat source");

        //Step3: Verify the contact is created successfully with comments against the contact and chronology are correct andd contact information validated
        const comments ='Created the contact at'
        await SearchCommentspage.searchcomments(comments)
        await expect(page.locator("//div[@class='ct-event-header']//span[contains(text(),'|')]")).toContainText(/\d{2}\/\d{2}\/\d{4} \d{2}:\d{2}:\d{2}/); // regex to check the info contains date and time format
        const text =await RemoveNewlinepage.removenewline(await page.locator("//div[@class='ct-event-header']//span[contains(text(),'|')]").textContent())
        const Datetime=text.trim()
        appendToLogFile(`Pass: Date and Time and status '${Datetime}' displayed in Contact Information form`);
        await IncidentChronologypage.incidentchronology(Contact1,'Contact created:')
        appendToLogFile('Test Passed')

    }
)