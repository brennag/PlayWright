const {test, expect} = require ('@playwright/test');
const testdata =JSON.parse(JSON.stringify(require('../../testdata/data.json')));
const{PageObjects} = require('../../pageobjects/PageObjects')
const {appendToLogFile } = require('../testlogs');


test('CRC-007e', async ({browser}) =>
    {  
        appendToLogFile(`\n=======================${__filename}==========================`) 
        const context = await browser.newContext();
        const page = await context.newPage();
       
        const pages=new PageObjects(page)
        const{loginpage,Contactformpage,SearchCommentspage,RecentlistContactSearchpage,NearByIncidentspage,RemoveNewlinepage,AddCommentspage,
            RecentlistContextMenupage,CloseContactpage,CreateContactPageobj}=pages;

        await loginpage.goTO()
        await loginpage.validLogin(testdata.FCOusername,testdata.FCOpassword,testdata.FCOposition)
        const Mappage = await loginpage.waitForNewPageAndCheckTitle()

        //Step1: Create Contact and send for despatch and verify it on despatch board
        await Contactformpage.SaveCallerDetails('Test12',null,null,null,'78994749030',null,null)
        const Incident1 = await Contactformpage.createcontact('13 CAMBRIA ROAD LONDON SE5 9A',null,null)
        await CreateContactPageobj.sendtodespatch.click()
        await RecentlistContactSearchpage.recentlistcontactsearch(Incident1)

        //Step2: Create another contact with same incident location and verify location
        await CreateContactPageobj.CreateContactTab.click()
        await CreateContactPageobj.ClearForm.click()
        const Incident2 =await Contactformpage.createcontact('13 CAMBRIA ROAD LONDON SE5 9A','C04','CQ16')
       
        //Step3: Validate Nearby incidents showing Incident1
        await page.waitForTimeout(5000)
        await NearByIncidentspage.NearByIncidents(Incident1)
        // await page.pause()   
        //Step4: Contact info shows incident_id,date,time
        await expect(page.locator("//div[@class='ct-event-header']")).toContainText(Incident2) 
        appendToLogFile(`Pass:Incident number :${Incident2} displayed at the top Contact information form`)
        await expect(page.locator("//div[@class='ct-event-header']//span[contains(text(),'|')]")).toContainText(/\d{2}\/\d{2}\/\d{4} \d{2}:\d{2}:\d{2}/); // regex to check the info contains date and time format
        const text =await RemoveNewlinepage.removenewline(await page.locator("//div[@class='ct-event-header']//span[contains(text(),'|')]").textContent())
        const Datetime=text.trim()
        appendToLogFile(`Pass:Date and Time and status :'${Datetime}'  displayed at the top of Contact Information form `)

        //Step5: Update contact with (the advice given to the caller) a comment.
        const comments ='the advice given to the caller'
        await AddCommentspage.addcomments(comments)
        await SearchCommentspage.searchcomments(comments)

        //Step6:From My History access the context menu for the contact, choose Close
        await RecentlistContextMenupage.recentlistContactContextMenu(Incident2,'close')

        //step 7: close the contact by giving remark and disposition code
        await CloseContactpage.closecontact(Incident2,'CRC-007e','700')
        await expect(page.locator("//div[@class='ct-event-header']")).toContainText('Closed') 
        appendToLogFile(`Pass: The Contact ${Incident2} closed successfully`)

        await page.locator("input[placeholder='Search Incidents...']").fill(Incident2)
        await expect(page.locator("//span[@class='results-title']")).toContainText(`Showing 0 results for "${Incident2}"`)
        appendToLogFile(`Pass:The Contact: ${Incident2} is Closed and removed from My History`) 
        appendToLogFile('Test Passed')    
    }
)

