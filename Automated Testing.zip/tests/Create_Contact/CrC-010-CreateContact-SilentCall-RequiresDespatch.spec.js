const {test, expect} = require ('@playwright/test');
const testdata =JSON.parse(JSON.stringify(require('../../testdata/data.json')));
const{SelectIncident}=require('../../pageobjects/Incident/SelectIncidents')
const{SearchComments}=require('../../pageobjects/CreateContact/SearchComments')
const{PageObjects} = require('../../pageobjects/PageObjects')
const {appendToLogFile } = require('../testlogs');
// const{login}=require('../../pageobjects/General/login')


test('CRC-010', async ({browser}) =>
    {
        appendToLogFile(`\n=======================${__filename}==========================`)
        const context = await browser.newContext();
        const page = await context.newPage();
        const pages=new PageObjects(page)
        // const loginpage1= new login(page)
        const {loginpage,Contactformpage,logoutpage,IncidentBoardSearchpage,SearchCommentspage} =pages
       
        // await pages.loginpage.goTO()
        await loginpage.goTO()
        await loginpage.validLogin(testdata.FCOusername,testdata.FCOpassword,testdata.FCOposition)
        await loginpage.waitForNewPageAndCheckTitle()
        
        const Incidentlocation ='50 AKERMAN ROAD LONDON SW9 6S'
        const IncidentType ='P04'
        const IncidentSubType='PQ10'

        //creating a contact 
        await Contactformpage.SaveCallerDetails('ram','1992-07-25','Third Party','999 Emergency','9273739',null,'ARCH 280 COLDHARBOUR LANE LONDON SW9 8SE')
        const Contact_ID = await Contactformpage.createcontact(Incidentlocation,IncidentType,IncidentSubType)

        //Silent Call Dialog
        await Contactformpage.SilentCall.click()
        await expect(page.locator("//*[contains(@class,'dialog-header flex-row flex-justify-space-between ng-scope')]")).toContainText("Silent Call")//verifying the dialog
        appendToLogFile(`Pass:Silent Call dialog opened`)
        await expect(page.locator("//h5[starts-with(text(),'MPS')]")).toContainText(Contact_ID)// checking the incident id
        //Complete Silent Call responses -Record outcome to each question by ticking first 2 boxes.
        await page.locator("input[name='(LBL_MISSING_PER_POL_ASSISTANCE)']").click()
        //await page.waitForTimeout(5000)
        await page.locator("input[name='(LBL_MISSING_PER_COUGH)']").click()
        //await page.waitForTimeout(5000)
        await page.locator("input[name='(LBL_MISSING_PER_DISCONNECTED)']").click()
        //await page.waitForTimeout(5000)
        await page.locator(".btn.btn-primary.submit-btn.cd-tabbable.ng-binding").click()
        //await page.waitForTimeout(10000)
        //await page.pause()
        //verifying silent call all questions not marked warning
        const warningmessage ='All Silent Call questions were not marked as asked'
        await expect(page.locator("//h5[starts-with(text(), 'All Silent')]")).toContainText(warningmessage)
        appendToLogFile(`warning message: ${warningmessage} found`)
        await page.locator(".btn.btn-primary.submit-btn.cd-tabbable.ng-binding").click()

        //search comments for Challenge incomplete
    
        const comments=`SILENT CALL - CHALLENGE INCOMPLETE:`

        await SearchCommentspage.searchcomments(comments)
        // await ContactSearchCommentspage.searchComments("SILENT CALL - CHALLENGE INCOMPLETE")

        //Enter new Incident Type Sub Type (that requires despatch) and save changes
        await Contactformpage.ContactForm.click()
        const Incident_ID =await Contactformpage.CreateInc(Incidentlocation,'C03','CQ11')

        //checking Incident Information updated
        await SearchCommentspage.searchcomments("Contact Type changed from P04(PQ10) to C03(CQ11)")

        //logout 
        await logoutpage.logout()
        await page.waitForTimeout(5000)
        //logging in as dispatcher
        await loginpage.goTO()
        await loginpage.validLogin(testdata.Operatorusername,testdata.Operatorpassword,testdata.Operatorposition)
        const Mappage=await loginpage.waitForNewPageAndCheckTitle()
        appendToLogFile(`Pass:Login as despatcher successful`)
        const SelectIncidentpage = new SelectIncident(Mappage)

        //Incident Board Searching for Incident
        await IncidentBoardSearchpage.incidentboardsearch(null,Incident_ID)

        //Validating Incident Panel
        await SelectIncidentpage.SelectIncident(Incident_ID)
        await Mappage.bringToFront()
        await expect(Mappage.locator(".dialog-text-display").nth(2)).toContainText('C03') 
        await expect(Mappage.locator(".dialog-text-display").nth(4)).toContainText('CQ11') 
       appendToLogFile('Pass: Incident type & Subtype matched')

        //Incident Panel Search Comments Validation
        const incidentcomments = `SILENT CALL - CHALLENGE INCOMPLETE:`
        const searchcommentspage1 = new SearchComments(Mappage)
        await searchcommentspage1.searchcomments(incidentcomments)
        appendToLogFile('Test Passed')

    }
)