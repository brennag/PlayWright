const {test, expect} = require ('@playwright/test')
const testdata =JSON.parse(JSON.stringify(require('../../testdata/data.json')))
//const{SelectIncident}=require('../../pageobjects/Incident/SelectIncidents')
const {appendToLogFile } = require('../testlogs');
const{PageObjects}=require('../../pageobjects/PageObjects');
const { CreateContactPage } = require('../../pageobjects/CreateContact/CreateContactpage');
const { RecentlistContactSearch } = require('../../pageobjects/CreateContact/RecentlistContactSearch');
const { IncomingMessage } = require('http');
//const{MissingPerson}= require (`../../Pageobjects/General/MissingPerson`)

test(`CrC-008 Create Contact - Missing Person, Call Taker raises Priority`, async({browser}) =>{
    test.setTimeout(500000);
    const context = await browser.newContext();
    const page = await context.newPage();
    const pages=new PageObjects(page)
    const {loginpage,Contactformpage,SearchCommentspage,SelectIncidentpage,MissingPersonpage,logoutpage,DialogOpenpage,RecentlistContactSearchpage} =pages
        //let pageObjects = new PageObjects(page);
    //const { loginPage, MissingPersonpage} = pageObjects;
    await loginpage.goTO()
    await loginpage.validLogin('FCO2','Ingr.112233','101012/AutoFCO2')
    await loginpage.waitForNewPageAndCheckTitle()
    
    let comment =`Missing Person added: \nDetails of Missing Person: \nName: Test\nSex: Male\nAddress: 1 AITKEN STREET ACCRINGTON BB5 6AX\n\nCircumstances of going missing: \nMissing From: AA METRO CENTRE WHICKHAM NE11 9XZ\nCircumstances: Missing Person\nIs behaviour out of character: False\nPerson reporting:\nName: ss\nHome Address: AA METRO CENTRE WHICKHAM NE11 9XZ\nPhone Number:8457283542\nCall Source: Officer\nCaller Type: Staff On Duty\n\nInitial risk identification: \nIs there any information that the person is likely to cause self-harm or attempt suicide?: True\nIs the person suspected to be the subject of a crime in progress, e.g. abduction?: True\nIs the person vulnerable due to age, infirmity or any other factor?: True`
   
    // await page.pause();
  
    const Incidentlocation ='50 AKERMAN ROAD LONDON SW9 6S'
    const IncidentType ='P15'
    const IncidentSubType='PQ54'

    //creating a contact 
    await Contactformpage.SaveCallerDetails('ram','1992-07-25','Third Party','999 Emergency','9273739',null,'ARCH 280 COLDHARBOUR LANE LONDON SW9 8SE')
   
    const Contact_ID = await Contactformpage.createcontact(Incidentlocation,IncidentType,IncidentSubType)
    
    await page.waitForTimeout(2000);
    await page.pause();

    
        //TODO - validate dropdown value is populated
 
        
        
   
    
    // This should be handled as automatically the SMF dialog is getting displayed after clicking on create contact button
    /*if(await oncallPage.closeButton.isVisible()){
        await oncallPage.closeButton.click();
    }

    await oncallPage.missingPersonButton.click();*/
    await Contactformpage.MissingPerson.click()
    await DialogOpenpage.DialogOpen("Missing Persons")

    //await expect(oncallPage.validatingDialogTitle(`Missing Persons`)).toBeVisible();
    await page.waitForTimeout(3000);
    await page.locator(`//*[text()="Details of Missing Person"]/parent::*/following-sibling::*//input`).nth(0).fill(`Test`);
    await page.locator(`//*[text()="Details of Missing Person"]/parent::*/following-sibling::*//input`).nth(2).fill(`12`);
    await page.locator(`//*[text()="Details of Missing Person"]/parent::*/following-sibling::*//input`).nth(3).fill(`12`);
    await page.locator(`//*[text()="Details of Missing Person"]/parent::*/following-sibling::*//input`).nth(4).fill(`1996`);
    //await oncallPage.validatingDialogTitle(`Missing Persons`).click();

    await MissingPersonpage.sexDropdowninMissingPersonDialog.click();
    await MissingPersonpage.selectingText(`Male`).click();

    // Now selecting the location manually in missing person dialog in Home address instead clicking on Use Attendance Location should fill the location automatically
    // await oncallPage.clickingonDropdownUsingID(`locationDialog`).click();
    await MissingPersonpage.pointingInputFieldsUsingID(`locationDialog`).nth(0).fill(`1 AITKEN STREET ACCRINGTON BB5 6AX`); // Filling home address and selecting address in missing persons dialog
    await MissingPersonpage.selectinglocationFromDropdown(`1 AITKEN STREET ACCRINGTON BB5 6AX`).nth(0).click();
    await expect(page.locator(`//*[text()="Missing Persons"]/parent::*/following-sibling::*//*[contains(@class,"check-circle")]`).nth(0)).toBeVisible();

    await MissingPersonpage.useCallerAddressButton.nth(1).click();
    // await oncallPage.pointingInputFieldsUsingID(`locationDialog`).nth(1).fill(`1 AITKEN STREET ACCRINGTON BB5 6AX`); // Filling missing from and selecting address in missing persons dialog
    //await MissingPersonpage.selectinglocationFromDropdown(`AA METRO CENTRE WHICKHAM NE11 9XZ`).nth(0).click();
    await MissingPersonpage.selectinglocationFromDropdown('ARCH 280 COLDHARBOUR LANE LONDON SW9 8SE').nth(0).click();
    await expect(page.locator(`//*[text()="Missing Persons"]/parent::*/following-sibling::*//*[contains(@class,"check-circle")]`).nth(1)).toBeVisible();

    await MissingPersonpage.inputFieldsInMissingPersonDialog(`'Circumstances'`).fill(`Missing Person`);// Filling Circumstances

    // Filling Vechile Details
    await MissingPersonpage.inputFieldsInMissingPersonDialog(`VRM`).fill(`ABC12`);
    await MissingPersonpage.inputFieldsInMissingPersonDialog(`Make`).fill(`Toyota`);
    await MissingPersonpage.inputFieldsInMissingPersonDialog(`Model`).fill(`Corolla`);
    await MissingPersonpage.dropdownInMissingPersonDialog('Colour').scrollIntoViewIfNeeded();
    await MissingPersonpage.dropdownInMissingPersonDialog('Colour').click();
    await MissingPersonpage.selectingText(`White`).click();

    await MissingPersonpage.useCallerDetails.click();
    // Verifying the details whether the details are autopopulated in the Person Reporting section in Missing Persons Dialog
    await MissingPersonpage.selectinglocationFromDropdown(`ARCH 280 COLDHARBOUR LANE LONDON SW9 8SE`).click();
    await expect(page.locator(`//*[text()="Missing Persons"]/parent::*/following-sibling::*//*[contains(@class,"check-circle")]`).nth(2)).toBeVisible();
    await expect(MissingPersonpage.inputFieldsInMissingPersonDialog(`'Name'`)).toHaveValue(`ram`);
    await expect(MissingPersonpage.pointingInputFieldsUsingID(`locationDialog`).nth(2)).toHaveValue(`ARCH 280 COLDHARBOUR LANE LONDON SW9 8SE`);
    await expect(MissingPersonpage.inputFieldsInMissingPersonDialog(`Phone Number`)).toHaveValue(`9273739`);
    const valueInCallSourceField = await page.locator(`//*[@label="'Call Source'"]/parent::*/parent::*/parent::*/parent::*//*[contains(@class,"select__single")]`).textContent();
    console.log(valueInCallSourceField);
    await expect(valueInCallSourceField).toBe('999 Emergency');
    const valueInCallerTypeField = await page.locator(`//*[@label="'Caller Type    '"]/parent::*/parent::*/parent::*/parent::*//*[contains(@class,"select__single")]`).textContent();
    console.log(valueInCallerTypeField);
    await expect(valueInCallerTypeField).toBe('Third Party');

    // Selecting the options in Initial risk identification
    await page.locator(`//*[text()="Initial risk identification"]`).scrollIntoViewIfNeeded();
    await expect(page.locator(`//*[text()="Initial risk identification"]`)).toBeVisible();
    await MissingPersonpage.checkboxInMissingPersonDialog.nth(0).scrollIntoViewIfNeeded();
    await MissingPersonpage.checkboxInMissingPersonDialog.nth(0).click({force: true});
    await MissingPersonpage.checkboxInMissingPersonDialog.nth(1).click({force: true});
    await MissingPersonpage.checkboxInMissingPersonDialog.nth(2).click({force: true});
    await MissingPersonpage.inputFieldsInMissingPersonDialog('Incident Number:').scrollIntoViewIfNeeded();
    await page.waitForTimeout(2000);
    const incidentID = await MissingPersonpage.inputFieldsInMissingPersonDialog('Incident Number:').inputValue();
    console.log(incidentID);
    await page.waitForTimeout(5000);
    await MissingPersonpage.submitButton.click();
    await expect(MissingPersonpage.validatingDialogTitle(`Missing Persons`)).toBeHidden();
    await page.waitForTimeout(2000);
    await page.pause()
    await expect(page.locator(`//*[@class="ct-agency-recommended-response"]//*[text()="Priority"]`)).toBeVisible();
    const priority = await page.locator(`//*[@id="agencygadgetResponse"]//*[@class="event-priority__container"]`).textContent();// Capturing the priority from the recommend response
    console.log(priority);
    const dgroup = await page.locator(`(//*[@id="agencygadgetResponse"]//*[@class="tabledata-class"])[5]`).textContent();
    console.log(dgroup);
    await page.pause()
    await Contactformpage.sendtodespatch.click();

    // Verifying the incidentID should be in History/Recent list
    //await expect(page.locator(`//*[@data-testid="eventItemWrapper"]//*[@title="${incidentID}"]`)).toBeVisible();
    await RecentlistContactSearchpage.recentlistcontactsearch(incidentID);

    await MissingPersonpage.addingTags(['ASE', 'AWN']);
    await page.waitForTimeout(2000);
    await newPage.close();
    await page.waitForTimeout(2000);
    // Logging out as call taker
    await logoutpage.logout();

    // Now loggin in as dispachter
    await loginpage.login(testdata.Operatorusername,testdata.Operatorpassword,testdata.Operatorposition);
    await page.waitForTimeout(10000);
    
    Mappage= await loginpage.waitForNewPageAndCheckTitle();

    await SelectIncidentpage.SelectIncident(incidentID);
    await SearchCommentspage.searchcomments(comment);

    //await MissingPersonpage.clickCommandLineButtonAndEnterCommandLine(`edit calltaker -e ${incidentID}`);
    //await expect(MissingPersonpage.validateIncidentInformationText(incidentID)).toBeVisible();
  
    await MissingPersonpage.verifyingTheTags(['ASE', 'AWN']);

    await MissingPersonpage.commentButton.click();
    console.log(comment);
    await expect(MissingPersonpage.commentText).toBeVisible();
    await oncallPage.validatingTheComment(comment);

    await oncallPage.supplementalInformationButton.click();
    await expect(oncallPage.supplementalInformationText).toBeVisible();

    await expect(oncallPage.verifyingWithTitleAttribute(`ABC12`)).toBeVisible();
    await expect(oncallPage.verifyingWithTitleAttribute(`Toyota`)).toBeVisible();
    await expect(oncallPage.verifyingWithTitleAttribute(`Corolla`)).toBeVisible();
    await expect(oncallPage.verifyingWithTitleAttribute(`WHI`)).toBeVisible();
    await expect(oncallPage.verifyingWithTitleAttribute(`Test`)).toBeVisible();
    await expect(oncallPage.verifyingWithTitleAttribute(`1996-12-11`)).toBeVisible();
    await expect(oncallPage.verifyingWithTitleAttribute(`Male`)).toBeVisible();
    await expect(oncallPage.verifyingWithTitleAttribute(`1 AITKEN STREET ACCRINGTON BB5 6AX`).nth(1)).toBeVisible();



    await page.waitForTimeout(10000);//*[@type="checkbox"]MPS20250408000038 MPS20250408000038 
    
})
