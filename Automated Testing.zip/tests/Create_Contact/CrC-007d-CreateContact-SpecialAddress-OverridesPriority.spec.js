const {test, expect} = require ('@playwright/test');
const testdata =JSON.parse(JSON.stringify(require('../../testdata/data.json')));
const{SearchComments} =require('../../pageobjects/CreateContact/SearchComments')
const{SelectIncident}=require('../../pageobjects/Incident/SelectIncidents')
const {appendToLogFile } = require('../testlogs');
const{PageObjects} = require('../../pageobjects/PageObjects')

test('CRC-007d', async ({browser}) =>
    {   
        appendToLogFile(`\n=======================${__filename}==========================`)
        const context = await browser.newContext();
        const page = await context.newPage();
        const pages=new PageObjects(page)
        const{loginpage,Contactformpage,SearchCommentspage,RecentlistContactSearchpage,IncidentBoardSearchpage,logoutpage}=pages;
        await loginpage.goTO()
        await loginpage.validLogin(testdata.FCOusername,testdata.FCOpassword,testdata.FCOposition)
        await loginpage.waitForNewPageAndCheckTitle()

        //Step1: Create a Contact for an emergency  call at a location near the special address and Verify the location
        await Contactformpage.SaveCallerDetails('Test12',null,null,'999 Emergency',null,null,null)
        const special_Address ='81 BOSS HOUSE 2 BOSS STREET LONDON SE1 2PT'
        const Incident_Type ='A02'
        const Incident_Sub_Type ='AQ04'
        const Incident_ID = await Contactformpage.createcontact(special_Address,Incident_Type,Incident_Sub_Type)
        appendToLogFile('Pass: Contact created for the special address')
        

        //Step2: Review Priority in BCU Routing part of contact form
        const Priority= await Contactformpage.priority.textContent()
        if(Priority=='P3'){
            appendToLogFile('Pass:Priority is overriden and is set to 3 not 1.')
        }
        else{
            appendToLogFile('Fail:Priority is not set Correctly for Special Address')
        }

        //Step3: Special Address information is automatically applied to the incident comments
        const comments = 'Priority 3 set from special address location.'
        await SearchCommentspage.searchcomments(comments)
      

        //Step4: Press send to despatch and incident appears on the recent list
        await Contactformpage.sendtodespatch.click()
        await RecentlistContactSearchpage.recentlistcontactsearch(Incident_ID)
        // await page.pause()

        //Step5: As a Dispatcher:Go to the relevant Incident Board and check that the comments from the Special Address' are added to the Incident comments
        await logoutpage.logout()
        await page.waitForTimeout(5000)
        await loginpage.goTO()
        await loginpage.validLogin(testdata.Operatorusername,testdata.Operatorpassword,testdata.Operatorposition)
        const Mappage=await loginpage.waitForNewPageAndCheckTitle()
        appendToLogFile(`Pass: login as Despatcher is successful`)
        const SelectIncidentPage = new SelectIncident(Mappage)
        const searchcommentspage1= new SearchComments(Mappage)
        await IncidentBoardSearchpage.incidentboardsearch(null,Incident_ID)
        await Mappage.bringToFront()
        await SelectIncidentPage.SelectIncident(Incident_ID)
        await searchcommentspage1.searchcomments(comments)

        appendToLogFile('Test Passed')
    

    }
)