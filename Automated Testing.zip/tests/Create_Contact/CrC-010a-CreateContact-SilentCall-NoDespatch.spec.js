const {test, expect} = require ('@playwright/test');
const testdata =JSON.parse(JSON.stringify(require('../../testdata/data.json')));
const{PageObjects} = require('../../pageobjects/PageObjects')
const {appendToLogFile } = require('../testlogs');

test('CRC-010a', async ({browser}) =>
    {
        appendToLogFile(`\n=======================${__filename}==========================`)
        const context = await browser.newContext();
        const page = await context.newPage();
        const pages=new PageObjects(page)
        const {loginpage,Contactformpage,SearchCommentspage,CloseContactpage} =pages

        await loginpage.goTO()
        await loginpage.validLogin(testdata.Operatorusername,testdata.Operatorpassword,testdata.Operatorposition)
        await loginpage.waitForNewPageAndCheckTitle()

        const Incidentlocation ='50 AKERMAN ROAD LONDON SW9 6S'
        const IncidentType ='P04'
        const IncidentSubType='PQ10'

        //creating a contact 
        await Contactformpage.SaveCallerDetails('ram','1992-07-25','Third Party','999 Emergency','9273739',null,'ARCH 280 COLDHARBOUR LANE LONDON SW9 8SE')
        const Contact_ID = await Contactformpage.createcontact(Incidentlocation,IncidentType,IncidentSubType)

        //Silent Call Dialog
        await Contactformpage.SilentCall.click()
        await expect(page.locator("//*[contains(@class,'dialog-header flex-row flex-justify-space-between ng-scope')]")).toContainText("Silent Call")//verifying the dialog
        appendToLogFile(`Pass: Silent Call Dialog displayed`)
        await expect(page.locator("//h5[starts-with(text(),'MPS')]")).toContainText(Contact_ID)// checking the incident id
        //Complete Silent Call responses -Record outcome to each question by ticking 4 boxes
        await page.locator("input[name='(LBL_MISSING_PER_POL_ASSISTANCE)']").click()
        await page.locator("input[name='(LBL_MISSING_PER_COUGH)']").click()
        await page.locator("input[name='(LBL_MISSING_PER_DIAL)']").click()
        await page.locator("input[name='(LBL_MISSING_PER_TAP)']").click()
        await page.locator("input[name='(LBL_MISSING_PER_DISCONNECTED)']").click()
        await page.locator("input[name='(LBL_MISSING_PER_CLOSE_CONTACT)']").click()
        await page.locator(".btn.btn-primary.submit-btn.cd-tabbable.ng-binding").click()

        // checking whether close contact dialog opened
        await expect(page.locator("//*[@class='dialog-header flex-row flex-justify-space-between ng-scope']//span")).toContainText(`Close Contact`)
        appendToLogFile(`Pass:Close Contact dialog displayed after siubmitting silent call options`)

        //close contact
        let Remark ='CRC-010a'
        let Resolution='700'
        await CloseContactpage.closecontact(Contact_ID,Remark,Resolution)

        //checking whether contact closed
        // await page.pause()
        // await Invokecommandpage.invokecommand(`close -e ${Contact_ID}`)
        // await expect(page.locator("//h5[starts-with(text(), 'Contact MPS')]")).toEqual(`Contact ${Contact_ID} is already closed.`);

        await SearchCommentspage.searchcomments('Closed the contact at')
        appendToLogFile('Test Passed')

    }

)