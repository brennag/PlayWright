const {test,expect} = require('@playwright/test')
const testdata =JSON.parse(JSON.stringify(require('../../testdata/data.json')));
const{appendToLogFile}=require('../testlogs')
const{PageObjects}=require('../../pageobjects/PageObjects')

test('CRI-046 & CRI-047 & CRI-048 & CRI-049', async({browser}) =>
    {
        appendToLogFile(`\n=======================${__filename}==========================`)
        const context = await browser.newContext()
        const page = await context.newPage()
        const pages = new PageObjects(page)
        const{loginpage,Contactformpage,ContactformSOPSearchpage, SOPPanelSOPSearchpage,SOPExecutionpage}=pages;
        await loginpage.goTO()
        await loginpage.validLogin(testdata.FCOusername,testdata.FCOpassword,testdata.FCOposition)
        await loginpage.waitForNewPageAndCheckTitle()

        //Step1.2 : call taker user:Create a contact for an emergency call,having SOP
        const Incidentlocation ='81 ALBERT BRIDGE ROAD LONDON SW11 4PH'
        const IncidentType ='A02'
        const IncidentSubType='AQ05'
        await Contactformpage.SaveCallerDetails('testuser','1992-07-25','Third Party','999 Emergency','9273739',null,'FLAT 49 GWEN MORRIS HOUSE WYNDHAM ROAD LONDON SE5 0AD')
        const Contact_ID = await Contactformpage.createcontact(Incidentlocation,IncidentType,IncidentSubType) 
        const SOPname ='Automation SOP' 
        await ContactformSOPSearchpage.ContactformSOPSearch(SOPname)  

        //Step3: Contact Information form, select SOPs and click on ACCEPT to accept the Task
        await page.locator("//*[contains(@class,'accept-task-btn')]").click()
        await page.waitForTimeout(2000)
        let timer =await page.locator(`//*[text()='Time On Task']/parent::*/following-sibling::*//*[@class="sop-time"]`).first().textContent()
        console.log(timer)
        if(timer!='00:00:00')
        {
            appendToLogFile(`Pass: The SOP task is accepted and the timer Starts`)
        }
        else{
            appendToLogFile(`Fail: The timer not started after accepting the task`)
        }


        //STEP4:Select the SOP manager icon from the top right of the main menu bar at the top of the screen.
        await SOPPanelSOPSearchpage.SOPPanelSOPSearch(Contact_ID,SOPname)
        if(await SOPPanelSOPSearchpage.yourSOPtasksvalidation(SOPname)){
            appendToLogFile(`Pass:The SOP added to the incident is listed in 'Your SOP tasks' `)
        }
        else{
            appendToLogFile(`Fail:The SOP added to the incident is NOT listed in 'Your SOP tasks' `)
        }
       

        //step5,6:execute sops
        const taskprogress =await SOPExecutionpage.SOPExecution(SOPname);
        console.log(taskprogress)
        if(taskprogress==100){
            appendToLogFile(`Pass: SOP tasks executed successfully`)
        }

        else{
            appendToLogFile(`Fail: SOP tasks NOT executed successfully`)
        }

        //Step7: Select the SOP manager icon from the top right of the main menu bar at the top of the screen and observe "Your SOP Tasks" section.
        if(!await SOPPanelSOPSearchpage.yourSOPtasksvalidation(SOPname)){
            appendToLogFile(`Pass:In the SOP dialog, the section "Your SOP Tasks" is empty.`)
        }
        else{
            appendToLogFile(`Fail:In the SOP dialog, the section "Your SOP Tasks" is NOT empty.`)
        }
    }

    

)