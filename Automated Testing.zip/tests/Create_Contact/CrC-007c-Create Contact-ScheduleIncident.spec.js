const {test, expect} = require ('@playwright/test');
const testdata =JSON.parse(JSON.stringify(require('../../testdata/data.json')));
const { appendToLogFile } = require('../testlogs'); // Import logging function
const{PageObjects} = require('../../pageobjects/PageObjects')

test('CRC-007C', async ({browser}) =>
    {       
        appendToLogFile(`\n=======================${__filename}==========================`)
        const context = await browser.newContext();
        const page = await context.newPage();
        const pages=new PageObjects(page)
        const{loginpage,Menupage,ScheduledIncidentpage,DialogOpenpage}=pages;

        //Step1: As a call taker select the main OnCall Despatch menu and go to incident > create > create scheduled incident
        await loginpage.goTO()
        await loginpage.validLogin(testdata.FCOusername,testdata.FCOpassword,testdata.FCOposition)
        const Mappage = await loginpage.waitForNewPageAndCheckTitle()
        // await Menupage.NaviagtingToOptionsInMenu('Actions','Incident','Create','Create Scheduled Incident',null)
        await DialogOpenpage.DialogOpen('Create Scheduled Incident','CREATE SCHEDULED INCIDENT')

        //Step2,3,4: Create Schedule incident with all the details, check schedule incident tab for the incident created and also the calendar
        let Incidenttitle ='CRC-007C'
        let Callername='testCaller'
        let incidenttype='C02 - Sexual Offences'
        let incidenttypecode='C02'
        let incidentsubtype ='CQ08'
        await ScheduledIncidentpage.savescheduledIncidentdetails('45 DYLWAYS LONDON SE5 8HN',incidenttype,incidentsubtype,Incidenttitle,Callername)
        await ScheduledIncidentpage.ScheduledIncidentSaveCallerDetails('newcaller','924823923','Non Emergency','14 ASCOT PARK BLYTHEWOOD LANE ASCOT SL5 8E')
        await ScheduledIncidentpage.CreateScheduledIncidentTimings({hours:2},25)
        
        //await page.pause()
        //schedule incident tab not able to filter with timings
        await ScheduledIncidentpage.ValidateScheduleIncidentsTab({hours:2,minutes:-3},Callername,Incidenttitle)
        // await page.pause()

        //step 5,6: Scheduled Incidents tab click on the context menu of the Scheduled Incident and select Edit Incident and validate data.
        await page.locator("//button[contains(@class,'VerticalEllipsisButton')]").first().click()
        await page.locator("//li[@title='Edit']").click()
        await page.waitForTimeout(2000)
        let dialogtitle =await page.locator("//div[@class='dialog-header flex-row']").textContent()
        if(dialogtitle.includes(`Edit Scheduled Incident`)){
            appendToLogFile(`Pass: Edit Scheduled Incident form displayed`)
            let editscheduledincidentinfo = await page.locator(`//dialog-scheduled-event-select//div[contains(@class,'hxgn-inner-select__single-value')]`).textContent()
            let {Year ,Month, Day,starthrs,startmin,endHrs,endmin} = await ScheduledIncidentpage.getDateTime()
           let date=`${await ScheduledIncidentpage.padNumber(Day)}/${await ScheduledIncidentpage.padNumber(Month)}/${Year}`
            let info=[incidenttypecode, incidentsubtype, date]
            if(info.every(element => editscheduledincidentinfo.includes(element))){
                appendToLogFile(`Pass:The Edit Scheduled Incident form appears showing the data as entered.`)
            }
            else{
                appendToLogFile(`Fail:The Edit Scheduled Incident form NOT showing the data as entered.`)
            }
        }
        else{
            appendToLogFile(`Fail:Edit Scheduled Incident form NOT displayed`)
        }
        appendToLogFile('Test Passed')
    }
    
)