const {test, expect} = require ('@playwright/test');
const testdata =JSON.parse(JSON.stringify(require('../../testdata/data.json')));
const{PageObjects} = require('../../pageobjects/PageObjects')
const{appendToLogFile}=require('../testlogs')

test('CRC-007', async ({browser}) =>
    {
        appendToLogFile(`\n=======================${__filename}==========================`)
        const context = await browser.newContext();
        const page = await context.newPage();
        const pages=new PageObjects(page)
        const{loginpage,Contactformpage,AddCommentspage,SearchCommentspage,CloseContactpage,IncidentChronologypage}=pages;
        await loginpage.goTO()
        await loginpage.validLogin(testdata.Operatorusername,testdata.Operatorpassword,testdata.Operatorposition)
        const Mappage = await loginpage.waitForNewPageAndCheckTitle()
       
        //Creating Contact
        const Incidentlocation ='LONDON RCC - SW19 JUBILEE WAY SOUTH WIMBLEDON LONDON'
        const IncidentType ='C04 - Burglary - Business & Community'
        const IncidentSubType='CQ16 - Contact record'
        await Contactformpage.SaveCallerDetails('ram','1992-07-25','Third Party','Non Emergency 101','9273739',null,'ARCH 280 COLDHARBOUR LANE LONDON SW9 8SE')
        const Contact_ID = await Contactformpage.createcontact(Incidentlocation,IncidentType,IncidentSubType)
        
        //Add Comments
        const comments ="CRC-007 test comments"
        await AddCommentspage.addcomments(comments)

        //Search for Comments
        await SearchCommentspage.searchcomments(comments)
        // await page.pause()

        //closing contact
        let Remark ='CRC-007'
        let Resolution ='700'
        await CloseContactpage.closecontact(Contact_ID,Remark,Resolution)
     
        
        //incident chronology check
        await IncidentChronologypage.incidentchronology(Contact_ID,Resolution)
        appendToLogFile('Test Passed')
    }
) 