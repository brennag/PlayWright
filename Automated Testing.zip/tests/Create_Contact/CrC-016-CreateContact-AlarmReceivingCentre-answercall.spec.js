const { test, expect } = require('@playwright/test');
const testdata = JSON.parse(JSON.stringify(require('../../testdata/data.json')));
const { PageObjects } = require('../../pageobjects/PageObjects');
const { appendToLogFile } = require('../testlogs'); // Import logging function


test('CrC-016', async ({ browser }) => {
    const filename = __filename
    appendToLogFile(`\n=======================${__filename}==========================`)
    const context = await browser.newContext();
    const page = await context.newPage();
    const pages = new PageObjects(page);
    const { loginpage, logoutpage, AMSDialogpage, DialogOpenpage, Contactformpage, AddCommentspage, IncidentBoardSearchpage } = pages;
    const comments = "//*-----CrC-016 Create Contact - Alarm Receiving Centre (answer call)----//";
    //await AddCommentspage.addcomments(comments)
    //Loginto Oncall Application
    await loginpage.goTO();
    //await loginpage.validLogin(testdata.FCOusername, testdata.FCOpassword, testdata.FCOposition);
    await loginpage.validLogin('FCO2', 'Ingr.112233','101012/AutoFCO2');
    let Mappage = await loginpage.waitForNewPageAndCheckTitle();
    appendToLogFile("Pass: Successfully logged in as FCO");
    // const SelectIncidentPage= new SelectIncident (Mappage);
    const Incidentlocation = 'FLAT 3 69 ATLANTIC ROAD LONDON SW9 8P'
    const IncidentType = 'P15'
    const IncidentSubType = 'PQ54'
    // Step 1: Simulate a call from an Alarm Centre and as a call taker user answer the call in the conversation stack.
    await Contactformpage.SaveCallerDetails('ram', '1992-07-25', 'Third Party', 'Non Emergency 101', '9273739', null, 'ARCH 280 COLDHARBOUR LANE LONDON SW9 8SE')
    const Contact_ID = await Contactformpage.createcontact(null, null, null)
    await page.pause();
    await AMSDialogpage.SelectAlarm("E000427", "CA");
    //await expect(this.dialogtitle).toBeHidden() //checking whether URN dialog is closed
    console.log("clicked on AMS Dialog");
    //await expect(this.dialogtitle).toBeHidden() //checking whether URN dialog is closed'
    const isvisible = await  page.getByRole('button', { name: '×', exact: true }).isVisible()
    if (isvisible)
        {
        await page.getByRole('button', { name: '×', exact: true }).click();
        }
    await page.pause();
    await logoutpage.logout();
    await page.waitForTimeout(5000);
    //As Dispatcher check Incident appears on correct BCU Board
    await loginpage.goTO()
    //await loginpage.validLogin(testdata.Operatorusername, testdata.Operatorpassword, testdata.Operatorposition);
    await loginpage.validLogin('paravapalli', 'Ingr.112233', '101/AP');
    Mappage = await loginpage.waitForNewPageAndCheckTitle();
    //Search for an Incident
    await IncidentBoardSearchpage.incidentboardsearch(null, Contact_ID);
    await page.pause()

})

