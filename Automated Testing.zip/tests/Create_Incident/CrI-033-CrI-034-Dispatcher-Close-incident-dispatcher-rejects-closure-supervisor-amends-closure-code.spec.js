const {test,expect} = require('@playwright/test')
const testdata =JSON.parse(JSON.stringify(require('../../testdata/data.json')));
const{appendToLogFile}=require('../testlogs')
const{PageObjects}=require('../../pageobjects/PageObjects')



test('CRI-033 & CRI-034', async({browser}) =>
{
    appendToLogFile(`\n=======================${__filename}==========================`)
    const context = await browser.newContext()
    const page = await context.newPage()
    const pages = new PageObjects(page)
    const{loginpage,Contactformpage,logoutpage,IncidentBoardSearchpage,InvokeCommandpage,DespatchUnitpage,ClearUnitpage,ChangeRolepage,AssignResultCodeNewpage,
        IncidentAdvSearchpage}=pages

    //Step1: Logon to OnCall Despatch as a First Contact operator and select Create Contact tab to display the Contact information form
    await loginpage.goTO()
    await loginpage.validLogin(testdata.FCOusername,testdata.FCOpassword,testdata.FCOposition)
    await loginpage.waitForNewPageAndCheckTitle()

    //Step2: simulate an emergency call by completing the Caller name, caller type, Source, caller location, caller address and save the caller details.
    await Contactformpage.SaveCallerDetails('TestUser',null,'Victim','999 Emergency','9654064094',null,'25 OSWIN STREET LONDON SE11 4TF')

    //Step3: create an incident with location verified and check incident is unassigned
    let Incidenttype ='C01'
    let Incidentsubtype ='CQ01'
    const Incident_ID= await Contactformpage.CreateInc('25 OSWIN STREET LONDON SE11 4TF',Incidenttype,Incidentsubtype)
    await logoutpage.logout()
    await page.waitForTimeout(10000)
    await loginpage.goTO()
    await loginpage.validLogin(testdata.Operatorusername,testdata.Operatorpassword,testdata.Operatorposition)
    await loginpage.waitForNewPageAndCheckTitle()
    const Incident_status =await IncidentBoardSearchpage.incidentboardsearch(null,Incident_ID)
    if(Incident_status=='Unassigned'){
        appendToLogFile(`Pass: Incident is Unassigned just after creation`)
    }
    else{
        appendToLogFile('Fail: Incident is NOT Unassigned just after creation')
    }

    //Step4: Dispatcher review the incident and decides that the incident is not ready for closure and assigns the incident to a unit. (Despath Unit)
    let result=await DespatchUnitpage.DespatchUnit(null,Incident_ID)
    const UnitId= result[0] 
    await page.waitForTimeout(2000)
    let Incident_status_after_unit_assigned = await IncidentBoardSearchpage.incidentboardsearch(null,Incident_ID)
    if(Incident_status_after_unit_assigned=='Assigned'){
         appendToLogFile(`Pass: Incident is assigned after unit despatched`)
    }
    else{
        appendToLogFile(`Fail: Incident is NOT assigned after unit despatched`)
    }

    //Step5: The unit verbally notifies the dispatcher via Airwave radio that they have finished with the incident, all officers are clear of the scene and the incident is ready for closure.Dispatcher clears the unit from the incident. (Clear Unit)
    await ClearUnitpage.ClearUnit(UnitId)
    await page.waitForTimeout(2000)
    let Incident_status_after_unit_cleared = await IncidentBoardSearchpage.incidentboardsearch(null,Incident_ID)
    if(Incident_status_after_unit_cleared=='(Despatcher Awaiting Review)'){
         appendToLogFile(`Pass: Incident is in 'Despatcher Awaiting Review' column after unit cleared`)
    }
    else{
        appendToLogFile(`Fail: Incident is NOT in 'Despatcher Awaiting Review' column after unit cleared`)
    }

    //Step6: Supervisor observes the supervisor incident board. (Login as Supervisor and check Incident board)
    // await ChangeRolepage.changerole('AS Supervisor (BCU - AS - Despatch Enhanced)','SupASE')
    await logoutpage.logout()
    await page.waitForTimeout(10000)
    await loginpage.goTO()
    await loginpage.validLogin(testdata.Supervisorusername,testdata.Supervisorpassword,testdata.Supervisorposition)
    await loginpage.waitForNewPageAndCheckTitle()
    let Incident_status_check_as_supervisor = await IncidentBoardSearchpage.incidentboardsearch(null,Incident_ID) 
    if(Incident_status_check_as_supervisor=='(Despatcher Awaiting Review)'){
        appendToLogFile(`Pass: Incident is in 'Awaiting Review' column checked as supervisor`)
   }
   else{
       appendToLogFile(`Fail: Incident is NOT in 'Awaiting Review' column checked as supervisor`)
   }

   //Step 7: Login as a First Contact and verify the user is not able to close the incident Verify the user is prompted that they do not have sufficient access rights
   await logoutpage.logout()
   await page.waitForTimeout(10000)
   await loginpage.goTO()
   await loginpage.validLogin(testdata.FCOusername,testdata.FCOpassword,testdata.FCOposition)
   await loginpage.waitForNewPageAndCheckTitle()
   await InvokeCommandpage.invokecommand(`close -e ${Incident_ID}`)
   await page.waitForTimeout(3000)
   await expect(page.locator(`//*[contains(@class,'dialog flex-col main-command-dialog-container')]//h5`)).toContainText(`User do not have sufficient access rights to close the Incident ${Incident_ID}`)
   appendToLogFile(`Pass: First contact operator does not have the right prompt displayed`)

   //Step 8,9:despatcher assign result code and add tag "Supervisor - Ready to Close"
//    await page.pause()
   await logoutpage.logout()
   await page.waitForTimeout(10000)
   await loginpage.goTO()
   await loginpage.validLogin(testdata.Operatorusername,testdata.Operatorpassword,testdata.Operatorposition)
   await loginpage.waitForNewPageAndCheckTitle()
   let Result_code ='C01 - Violence Against the Person'
   let Result_Classification='Contact Record'
   let Qualifier='205 - Rowdy Behaviour'
   let Resolution='700 - Detain/Detained'
   let tag ='Supervisor - Ready to Close'
   await AssignResultCodeNewpage.assignresultcode(Incident_ID,Result_code,Result_Classification,Qualifier,Resolution,tag)
   //*********Note: Note: Ready to close queue is not available for despatchers(even supervisors doesn’t have ) . (so can't verify this)

   //Step10: The supervisor selects the incident followed by more options and closes the incident and selects submit.
   await logoutpage.logout()
   await page.waitForTimeout(10000)
   await loginpage.goTO()
   await loginpage.validLogin(testdata.Supervisorusername,testdata.Supervisorpassword,testdata.Supervisorposition)
   let Mappage =await loginpage.waitForNewPageAndCheckTitle()
   const pages1 = new PageObjects(Mappage)
   const{IncidentPanelContextMenupage,SearchCommentspage}=pages1
   await Mappage.bringToFront()
   await IncidentPanelContextMenupage.incidentpanelcontextmenu(Incident_ID,'Close')
   await page.waitForTimeout(2000)
   await expect(Mappage.locator(`//*[@label='(LBL_CloseIncident_ResultCode)']//input[@type='text']`)).toHaveValue(Result_code)
   await expect(Mappage.locator(`//*[@label='(LBL_CloseIncident_ResultClassification)']//input[@type='text']`)).toHaveValue(Result_Classification)
   await expect(Mappage.locator(`//*[@label='(LBL_CloseIncident_Qualifier)']//input[@type='text']`)).toHaveValue(Qualifier)
   await expect(Mappage.locator(`//*[@label='(LBL_CloseIncident_Resolution)']//input[@type='text']`)).toHaveValue(Resolution)
   await Mappage.locator("//*[text()='Submit']").click()
   await Mappage.waitForTimeout(3000)
   if(await Mappage.locator(`//*[contains(text(),'Incident ${Incident_ID} was unable to close')]`).isVisible()){
    await Mappage.locator("//*[text()='Submit']").click()
    await Mappage.waitForTimeout(2000)
    await Mappage.locator("//*[text()='Submit']").click()
   }
   await page.pause()
   await SearchCommentspage.searchcomments(`Closed the event`)
   await SearchCommentspage.searchcomments(`Assigned Result Code: C01`)
   await page.waitForTimeout(2000)
   await page.bringToFront()
   if(!await IncidentBoardSearchpage.incidentboardsearch(null,Incident_ID)){
    appendToLogFile(`Pass:  Incident ${Incident_ID} is closed and removed from supervisor incident board`)
   }
   else{
    appendToLogFile(`Fail :Incident ${Incident_ID} is NOT removed from supervisor incident board`)
   }
   await logoutpage.logout()
   await page.waitForTimeout(10000)
   await loginpage.goTO()
   await loginpage.validLogin(testdata.Operatorusername,testdata.Operatorpassword,testdata.Operatorposition)
   await loginpage.waitForNewPageAndCheckTitle()
   if(!await IncidentBoardSearchpage.incidentboardsearch(null,Incident_ID)){
    appendToLogFile(`Pass:  Incident ${Incident_ID} is closed and removed from Despatcher incident board`)
   }
   else{
    appendToLogFile(`Fail :Incident ${Incident_ID} is NOT removed from Despatcher incident board`)
   }


   //Step11,12:Select Advanced search and search for the incident ID closed
   await page.setViewportSize({width:1920,height:1200})
   let status =await IncidentAdvSearchpage.incidentAdvSearch(null,Incident_ID,null)
   if(status=='Closed')
   {
    appendToLogFile(`Pass: Incident ${Incident_ID} is  displayed as 'closed'  in Incident advanced search`)
   }
   else{
    appendToLogFile(`Pass: Incident ${Incident_ID} is NOT displayed as 'closed'  in Incident advanced search`)
   }


}

)