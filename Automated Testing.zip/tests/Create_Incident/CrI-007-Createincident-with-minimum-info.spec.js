const {test,expect} = require('@playwright/test')
const testdata =JSON.parse(JSON.stringify(require('../../testdata/data.json')));
const{appendToLogFile}=require('../testlogs')
const{PageObjects}=require('../../pageobjects/PageObjects')

test('CRI-007', async({browser}) =>
    {
        appendToLogFile(`\n=======================${__filename}==========================`)
        const context = await browser.newContext()
        const page = await context.newPage()
        const pages = new PageObjects(page)
        const{loginpage,Contactformpage, CommonUtilspage, RecentlistContactSearchpage,IncidentBoardSearchpage,logoutpage}=pages;
        await loginpage.goTO()
        await loginpage.validLogin(testdata.FCOusername,testdata.FCOpassword,testdata.FCOposition)
        await loginpage.waitForNewPageAndCheckTitle()
        let Incidentlocation='81 COMBER GROVE LONDON SE5 0LD'

        //Step1:attempt to send to dispatch with only location information 
        await Contactformpage.AttendanceLocation.fill(Incidentlocation)
        await Contactformpage.locationsearch.click()
        await page.locator("svg[data-icon='check-circle']").waitFor()
        await issendtodespatchdisabled(Contactformpage,'location')

        //step2: attempt to send to dispatch with only incident type information (NO SUB-TYPE).
        await Contactformpage.ClearForm.click()
        await Contactformpage.Clearformpopupclearbutton.click()
        await CommonUtilspage.SelectDropdownValue('(LBL_CALLTAKER_TYPE_SELECT)','C05 - Robbery - Personal')
        //clearing sub type as it auto -populates
        await page.locator("//*[@label='(LBL_CALLTAKER_SUBTYPE_SELECT)']//div[contains(@class,'hxgn-inner-select__value-container--has-value')]/following-sibling::*/child::div[1]").click()
        await issendtodespatchdisabled(Contactformpage,'Incidenttype')

        //step3:  attempt to send to dispatch with only incident type and sub-type information.
        await Contactformpage.ClearForm.click()
        await Contactformpage.Clearformpopupclearbutton.click()
        await CommonUtilspage.SelectDropdownValue('(LBL_CALLTAKER_TYPE_SELECT)','C05 - Robbery - Personal')
        await issendtodespatchdisabled(Contactformpage,'Incident type &Sub-type')

        //Step4: attempt to send to dispatch with only location and incident type information (NO SUB-TYPE).
        await Contactformpage.ClearForm.click()
        await Contactformpage.Clearformpopupclearbutton.click()
        await page.waitForTimeout(3000)
        await Contactformpage.AttendanceLocation.fill(Incidentlocation)
        await Contactformpage.locationsearch.click()
        await page.locator("svg[data-icon='check-circle']").waitFor()
        await CommonUtilspage.SelectDropdownValue('(LBL_CALLTAKER_TYPE_SELECT)','C05 - Robbery - Personal')
        //clearing sub type as it auto -populates
        await page.locator("//*[@label='(LBL_CALLTAKER_SUBTYPE_SELECT)']//div[contains(@class,'hxgn-inner-select__value-container--has-value')]/following-sibling::*/child::div[1]").click()
        await page.waitForTimeout(3000)
        await issendtodespatchdisabled(Contactformpage,'Location, type &Incident type')

        //Step5: create a contact and select location, incident type and sub-type information and check on the board
        await Contactformpage.ClearForm.click()
        await Contactformpage.Clearformpopupclearbutton.click()
        await page.waitForTimeout(3000)
        const Contact_ID= await Contactformpage.createcontact(Incidentlocation,'C05','CQ17')
        await RecentlistContactSearchpage.recentlistcontactsearch(Contact_ID)
        await issendtodespatchdisabled(Contactformpage,'Location ,type & subtype')

        //Step6: As a call taker, select send to dispatch.Do not end the call. 
        await Contactformpage.sendtodespatch.click()
        await page.waitForTimeout(3000)
        let headertext = await page.locator("//div[@class='ct-event-header']").textContent()
        if(headertext.includes('Unassigned')){
         appendToLogFile(`Pass : The Incident ${Contact_ID} is sent to Dispatch`)
        }
        else{
         appendToLogFile(`Fail: The Incident ${Contact_ID} is NOT sent to Dispatch`)
        }
        //Step 7: Observe the incident board of the BCU that covers the area that the incident is located in.
        let DGroup = await page.locator("//table[@id='agencygadgetResponse']//td[6]").textContent()
        await logoutpage.logout()
        await page.waitForTimeout(10000)
        await loginpage.goTO()
        await loginpage.validLogin(testdata.Operatorusername,testdata.Operatorpassword,testdata.Operatorposition)
        await loginpage.waitForNewPageAndCheckTitle()
        await IncidentBoardSearchpage.incidentboardsearch(DGroup,Contact_ID)
        await context.close()
    }

)

    async function issendtodespatchdisabled(Contactformpage,enteredvalue){
        let buttonclass = await Contactformpage.sendtodespatch.getAttribute('class')
        if(buttonclass.includes('disabled'))
        {
            appendToLogFile(`send to despatch button disabled after entering only ${enteredvalue}`)
            return true
        }
        else{
            appendToLogFile(`send to despatch button NOT disabled after entering only ${enteredvalue}`)
            return false
        }
    }
