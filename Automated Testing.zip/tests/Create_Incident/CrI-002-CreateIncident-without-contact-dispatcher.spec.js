const {test,expect} = require('@playwright/test')
const testdata =JSON.parse(JSON.stringify(require('../../testdata/data.json')));
const{appendToLogFile}=require('../testlogs')
const{PageObjects}=require('../../pageobjects/PageObjects')
const{login}=require('../../pageobjects/General/login')


test('CRI-002', async({browser}) =>
{
    appendToLogFile(`\n=======================${__filename}==========================`)
    const context = await browser.newContext()
    const page = await context.newPage()
    const loginpage=new login(page)
    await loginpage.goTO()
    await loginpage.validLogin(testdata.Operatorusername,testdata.Operatorpassword,testdata.Operatorposition)
    const Mappage = await loginpage.waitForNewPageAndCheckTitle()
    const pages = new PageObjects(Mappage)
    const{DialogOpenpage,CommonUtilspage,SelectIncidentpage,IncidentPanelpage}=pages

    //Step1 :As a dispatcher, Navigate to map screen right click anywhere on the map and from the context menu choose "Create Incident Here" and start creating the incident
    await Mappage.bringToFront()
    await Mappage.locator(`//div[contains(@class,'ui-notification-body')]`).first().waitFor()
    await Mappage.locator(`//map-view`).click({button:'right'})
    await Mappage.locator(`//*[text()='Create Incident Here']`).click()
    let isDialogopen=await DialogOpenpage.DialogOpen(`Create Incident`)
    if(isDialogopen){
        appendToLogFile(`Pass:Create Incident dialog displayed`)
    }
    else{
        appendToLogFile(`Fail:Create Incident dialog  NOT displayed`)
    }

    // //Dismiss all notifications
    // await Mappage.getByRole('button', { name: 'Dismiss All' }).click();
    // await Mappage.evaluate(() => {
    //     const notifications = document.querySelectorAll('.ui-notification-wrapper');
    //     notifications.forEach(notification => notification.remove());
    // });

    //Step2,3: Populate Mandatory Columns with location pre filled and submit and check incident creation notification
    await Mappage.setViewportSize({width:1920,height:1200})
    let Incidenttype='00 - Unclassified Contact'
    let Incidentsubtype='00 - Contact Record'
    await Mappage.locator(`//*[contains(@class,'location-result')]`).first().click()
    let location =await Mappage.locator(`//input[contains(@class,'dialog-location-input')]`).first().inputValue()
    console.log(location)
    await CommonUtilspage.SelectDropdownValue('(LBL_Incident_Type)',Incidenttype)
    await CommonUtilspage.SelectDropdownValue('(LBL_Incident_Subtype)',Incidentsubtype)
    await Mappage.locator(`//div[contains(@class,'main-command-dialog-container')]//button[contains(@class,'submit-btn')]`).click()
    await expect(Mappage.locator(`//span[@title='Success']/parent::*/following-sibling::*`)).toBeVisible()
    appendToLogFile(`Pass: An incident creation notification is displayed to the user with the incident id.`)
    let text =await Mappage.locator(`//span[@title='Success']/parent::*/following-sibling::*`).textContent()
    let Incident_id = text.slice(14)
    console.log(Incident_id)

    //Step4: verifying Incident Board and check unassigned status 
    const pages2 = new PageObjects(page)
    let {IncidentBoardSearchpage,logoutpage,Contactformpage,RecentlistContactSearchpage}=pages2;
    await page.bringToFront()
    let incidentstatus =await IncidentBoardSearchpage.incidentboardsearch(null, Incident_id)
    if(incidentstatus=='Unassigned'){
        appendToLogFile(`Pass: Incident:${Incident_id} in the Unassigned queue`)
    }
    else{
        appendToLogFile(`Fail: Incident:${Incident_id} NOT in the Unassigned queue`)
    }

    //Step5: Validate Incident card for details
    await Mappage.bringToFront()
    await SelectIncidentpage.SelectIncident(Incident_id)
    await IncidentPanelpage.ValidateIncidentPanelDetails(Incident_id,Incidenttype,Incidentsubtype,location)
    appendToLogFile(`Pass: Incident panel showing data correctly`)
    
    //Step6,7:  As a call taker, create a contact and select location, incident type and sub-type information  and verify contact board send to despatch
   await logoutpage.logout()
   await page.waitForTimeout(10000)
   await loginpage.goTO()
   await loginpage.validLogin(testdata.FCOusername,testdata.FCOpassword,testdata.FCOposition)
   await loginpage.waitForNewPageAndCheckTitle()
   let Contact_ID=await Contactformpage.createcontact('60 FINSEN ROAD LONDON SE5 9AW','C05','CQ17')
   await RecentlistContactSearchpage.recentlistcontactsearch(Contact_ID)
   await Contactformpage.sendtodespatch.click()
   await page.waitForTimeout(3000)
   let headertext = await page.locator("//div[@class='ct-event-header']").textContent()
   if(headertext.includes('Unassigned')){
    appendToLogFile(`Pass : The Incident ${Contact_ID} is sent to Dispatch`)
   }
   else{
    appendToLogFile(`Fail: The Incident ${Contact_ID} is NOT sent to Dispatch`)
   }

   await context.close()
}

)