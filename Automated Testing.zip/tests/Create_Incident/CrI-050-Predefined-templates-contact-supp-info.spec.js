const {test,expect} = require('@playwright/test')
const testdata =JSON.parse(JSON.stringify(require('../../testdata/data.json')));
const{appendToLogFile}=require('../testlogs')
const{PageObjects}=require('../../pageobjects/PageObjects')
const{SelectIncident}=require('../../pageobjects/Incident/SelectIncidents')
const{Supplementalinfo}=require('../../pageobjects/Incident/Supplementalinfo')

test('CRI-050', async({browser}) =>
    {
        appendToLogFile(`\n=======================${__filename}==========================`)
        const context = await browser.newContext()
        const page = await context.newPage()
        const pages = new PageObjects(page)
        const{loginpage,Contactformpage,Supplementalinfopage}=pages;
        await loginpage.goTO()
        await loginpage.validLogin(testdata.FCOusername,testdata.FCOpassword,testdata.FCOposition)
        const Mappage=await loginpage.waitForNewPageAndCheckTitle()

        //Step1: call taker user:Create a contact 
        const Incidentlocation ='FLAT 3 1 LOUGHBOROUGH PARK LONDON SW9 8TP'
        const IncidentType ='C06'
        const IncidentSubType='CQ20'
        const Incident_ID = await Contactformpage.createcontact(Incidentlocation,IncidentType,IncidentSubType)
        let TabsList=['Person','Vehicle','Property','References']
        let ValuesList =[{'Title':'Mr','Surname':'Mega','PNC Reason Code':'01. Vehicle or Person Stopped'},
                         {'Colour':'Green','Request POLE Search':'Yes'},
                         {'Model':'JOnas Collections','Property Type':'Jewellery - including Watches'},
                         {'Reference Number':'Ref16231','Comments':'TESTING Reference'}]
        await Supplementalinfopage.SaveSupplementalinfo(TabsList,ValuesList)
        // await page.pause()
        let isDetailsSavedcontactform= await Supplementalinfopage.validateSupplementalInfo(TabsList,ValuesList)
        if(isDetailsSavedcontactform){
            appendToLogFile(`Pass:Supplemental info saved correctly in Contact form`)
        }
        else{
            appendToLogFile(`Fail:Supplemental info NOT saved correctly in Contact form`)
        }
        await Contactformpage.sendtodespatch.click()
        const Supplementalinfopage1 = new Supplementalinfo(Mappage)
        const SelectIncidentpage = new SelectIncident(Mappage)
        
        await Mappage.bringToFront()
        await SelectIncidentpage.SelectIncident(Incident_ID)
        let isDetailsSavedIncidentpanel=await Supplementalinfopage1.validateSupplementalInfo(TabsList,ValuesList)
        if(isDetailsSavedIncidentpanel){
            appendToLogFile(`Pass:Supplemental info saved correctly in Incident Panel`)
        }
        else{
            appendToLogFile(`Fail:Supplemental info NOT saved correctly in Incident Panel`)
        }
    }
)