const {test,expect} = require('@playwright/test')
const testdata =JSON.parse(JSON.stringify(require('../../testdata/data.json')));
const{appendToLogFile}=require('../testlogs')
const{PageObjects}=require('../../pageobjects/PageObjects')



test('Change Incident Priority', async({browser}) =>
    {
        appendToLogFile(`\n=======================${__filename}==========================`)
        const context = await browser.newContext()
        const page = await context.newPage()
        const pages = new PageObjects(page)
        const{loginpage,Contactformpage,InvokeCommandpage,DialogOpenpage,ChangeRolepage,CommonUtilspage}=pages
        await loginpage.goTO()
        await loginpage.validLogin('vpatlola','HxGN@123456','111104/vpatlola')
        let Mappage =await loginpage.waitForNewPageAndCheckTitle()

        let Incident_ID=await Contactformpage.CreateInc('FLAT 5 OVERY HOUSE WEBBER ROW LONDON SE1 8QX','P13','PQ45')
        let priority = await Contactformpage.priority.textContent()
        let prioritynumber =Number(priority.replace(/[^\d]/g, ''))
        console.log(prioritynumber)
        await DialogOpenpage.DialogOpen('Change Role','Change Role')
        let existingRole =await ChangeRolepage.changeRoleField.inputValue()
        if(!existingRole.includes('AS Operator (BCU - AS - Despatch Operator)')){
            await ChangeRolepage.changerole('AS Operator (BCU - AS - Despatch Operator)','DespASE')
        }
        await InvokeCommandpage.invokecommand(`CHANGE PRIORITY -e ${Incident_ID}`)
        await DialogOpenpage.DialogOpen('Change Incident Priority',null)
        let iswarningvisible=await page.locator(`//*[contains(@class,'main-command-dialog-container')]//h5[starts-with(text(),'User')]`).isVisible()
        if(iswarningvisible){
            let operatorchangeprioritytext=await page.locator(`//*[contains(@class,'main-command-dialog-container')]//h5`).textContent()
            if(operatorchangeprioritytext==`User does not have access to change the priority of ${Incident_ID}`){
                appendToLogFile('pass: Change priority access not available for dispatch operator')
             }
             else{
                 appendToLogFile('Fail:Change priority access available for dispatch operator')
             }
        }
        else{
            appendToLogFile(`Fail: Warning message not available for dispatch operator`)
        }
        await ChangeRolepage.changerole('AS Supervisor (BCU - AS - Despatch Enhanced)','SupASE')
        await InvokeCommandpage.invokecommand(`CHANGE PRIORITY -e ${Incident_ID}`)

        //Change Incident Priority dialog - Priority Upgrading
        await expect(page.locator(`//*[@label='(lbl_change_incident_priority_incident_id)']`)).toHaveValue(Incident_ID)
        await expect(page.locator(`//input[@name='(lbl_change_incident_priority_current_priority)']`)).toHaveValue(`${prioritynumber}`)
        // let currentpriority = await page.locator(`//input[@name='(lbl_change_incident_priority_current_priority)']`).inputValue()
        await CommonUtilspage.SelectDropdownValue('(lbl_change_incident_priority_new_priority)',prioritynumber-1)
        await CommonUtilspage.SelectDropdownValue('(lbl_change_incident_priority_reason)','Further Info received')
        await page.locator(`//*[contains(@class,'main-command-dialog-container')]//button[contains(@class,'submit-btn')]`).click()
        // await page.pause()

        //Validating Incident priority changed
        let opentabs=context.pages()
        Mappage=opentabs[1]
        const pages1= new PageObjects(Mappage)
        const{SelectIncidentpage,IncidentPanelpage,SearchCommentspage}=pages1
        await SelectIncidentpage.SelectIncident(Incident_ID)
        await Mappage.bringToFront()
        let new_priority=await IncidentPanelpage.priority.textContent()
        if(new_priority==`P${prioritynumber-1}`){
            appendToLogFile(`Pass:Priority Upgraded Successfully`)
        }
        else{
            appendToLogFile(`Fail: Priority NOT Upgraded`)
        }
        await SearchCommentspage.searchcomments(`Priority changed from ${prioritynumber} to ${prioritynumber-1}`)
        await SearchCommentspage.searchcomments(`Reason: Further Info received`)
       

        //Priority downgrading & validation
        await page.bringToFront()
        await InvokeCommandpage.invokecommand(`CHANGE PRIORITY -e ${Incident_ID}`)
        //await expect(page.locator(`//input[@name='(lbl_change_incident_priority_current_priority)']`)).toHaveValue(`${prioritynumber-1}`)
        await CommonUtilspage.SelectDropdownValue('(lbl_change_incident_priority_new_priority)',prioritynumber+1)
        await CommonUtilspage.SelectDropdownValue('(lbl_change_incident_priority_reason)','Original Grade in Error')
        await page.locator(`//*[contains(@class,'main-command-dialog-container')]//button[contains(@class,'submit-btn')]`).click()
        let new_priority2=await IncidentPanelpage.priority.textContent()
        if(new_priority2==`P${prioritynumber+1}`){
            appendToLogFile(`Pass:Priority downgraded Successfully`)
        }
        else{
            appendToLogFile(`Fail: Priority NOT downgraded`)
        }
        await SearchCommentspage.searchcomments(`Priority changed from ${prioritynumber} to ${prioritynumber+1}`)
        await SearchCommentspage.searchcomments(`Reason: Original Grade in Error`)

        await context.close()
    }
)