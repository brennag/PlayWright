import { test, expect } from '@playwright/test';
import { CreateContactPage } from '../../pageobjects/CreateContact/CreateContactpage';
const { PageObjects } = require('../../pageobjects/PageObjects');

test('Open Google', async ({ browser }) => {
  /*await page.goto('https://www.google.com');

  await expect(page).toHaveTitle(/Google/); // Validates the page title contains "Google"*/
const context = await browser.newContext();
const page = await context.newPage();
const pages = new PageObjects(page);
const { loginpage, Contactformpage, IncidentBoardSearchpage, logoutpage, AssignResultCodeNewpage, CloseIncidentpage, DialogOpenpage } = pages
await loginpage.goTO()
await loginpage.validLogin('FCO2', 'Ingr.112233', '101012/AutoFCO2')
//await loginpage.validLogin (testdata.Operatorusername,testdata.Operatorpassword,testdata.Operatorposition)
const Mappage = await loginpage.waitForNewPageAndCheckTitle()
const pages1 = new PageObjects(Mappage);
const { DuplicateAndCancelpage,IncidentChronologypage  } = pages1
  let PrimaryIncident_ID= 'MPS20250605000013'
  let IncidentID='MPS20250605000014'
  let Result_code = 'C14 - Public Order Offences'
  let Result_Classification = 'Contact Record'
  let Qualifier = '205 - Rowdy Behaviour'
  let Resolution = '700 - Detain/Detained'
  let tag = 'Supervisor - Ready to Close'
  let Loc1 = 'KING WILLIAM FOURTH - SE1 ROCKINGHAM STREET LONDON'
  let type = `C06 - Robbery - Business`
  let subtype = 'CQ20 - Suspect Present'
  await page.pause()
  await Contactformpage.SaveCallerDetails('ram','1992-07-25','Third Party','Non Emergency 101','9273739',null,'ARCH 280 COLDHARBOUR LANE LONDON SW9 8SE')
  const ContactID = await Contactformpage.createcontact(Loc1,type,subtype)
  console.log(ContactID)
  await page.pause()
  await DialogOpenpage.DialogOpen(`Close -e ${IncidentID}`, 'Close Incident')
  await CloseIncidentpage.closeIncident(IncidentID, Result_code, Result_Classification, Qualifier, Resolution, tag)
  await page.pause()
}
)

  /*let receviedComment= "** Cross Referenced to Event # MPS20250428000005  at: 02/05/2025 07:53:05 Linked - Possible duplicates, more details required by: Praveena ARAVAPALLI"
  
  let ExtractedUserName = receviedComment.substring(receviedComment.lastIndexOf(':') + 1).trim();
  let fullName = 'ARAVAPALLI, Praveena'
  //function nameContains(fullName, query) {
    //return 
    let r = await fullName.toLowerCase().includes(ExtractedUserName);
    console.log(r)
  //}
  //console.log(receviedComment)
  console.log (ExtractedUserName)
  
  await page.pause()
  const buffer = 50; // seconds

  const appTimeString = '14/05/2025 10:14:05'; // example timestamp from your app
  
  function parseAppTime(str) {
    const [day, month, year, hour, minute, second] = str.match(/\d+/g).map(Number);
    return new Date(year, month - 1, day, hour, minute, second);
  }
  
  const appTime = parseAppTime(appTimeString);
  const now = new Date();
  
  const diffInSeconds = (now - appTime) / 1000;
  
  if (diffInSeconds >= -buffer && diffInSeconds <= buffer) {
    console.log(`Time is within ±${buffer} seconds of app time`);
  } else {
    console.log(`Time difference exceeds ±${buffer} seconds`);
  }
  
  console.log(`Actual difference: ${diffInSeconds.toFixed(2)} seconds`);
}
)
function formatDateTime(date) {
    const pad = (num) => String(num).padStart(2, '0');
  
    const day = pad(date.getDate());
    const month = pad(date.getMonth() + 1); // Month is 0-based
    const year = date.getFullYear();
  
    const hours = pad(date.getHours());
    const minutes = pad(date.getMinutes());
    const seconds = pad(date.getSeconds());
  
    return `${day}/${month}/${year} ${hours}:${minutes}:${seconds}`;
  }
/*  // Let's say this is the timestamp from your app (simulate a few seconds ago)
const commentTime = new Date(Date.now() - 3000); // 3 seconds ago

// Get current time
const now = new Date();

// Compare timestamps (in milliseconds)
const bufferSeconds = 5;
const diffInSeconds = Math.abs((now - commentTime) / 1000);

if (diffInSeconds <= bufferSeconds) {
  console.log('✅ Timestamp is within 5 seconds');
} else {
  console.log('❌ Timestamp is outside the 5-second buffer');
}

console.log('Comment time:', formatDateTime(commentTime));
console.log('Now:', formatDateTime(now));
console.log(`Difference in seconds: ${diffInSeconds.toFixed(2)}`);
  
  // Example usage:
  const now = new Date();
  const formatted = formatDateTime(now);
  console.log('Formatted date/time:', formatted);*/