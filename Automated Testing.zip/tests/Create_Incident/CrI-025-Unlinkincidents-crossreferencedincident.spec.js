const { test, expect } = require('@playwright/test');
const testdata = JSON.parse(JSON.stringify(require('../../testdata/data.json')));
const{appendToLogFile}=require('../testlogs')
const { PageObjects } = require('../../pageobjects/PageObjects');
const { clear } = require('console');

test('CrI-025', async ({ browser }) => {
    
    appendToLogFile(`\n=========${__filename}==========`)
    const context = await browser.newContext();
    const page = await context.newPage();
    const pages = new PageObjects(page);
    const { loginpage, Contactformpage } = pages
    await loginpage.goTO()
    await loginpage.validLogin(testdata.Operatorusername,testdata.Operatorpassword,testdata.Operatorposition)
    const Mappage = await loginpage.waitForNewPageAndCheckTitle()
    const pages1 = new PageObjects(Mappage);
    const { CreateCrossReferencepage, SelectIncidentpage, SearchCommentspage} = pages1
    let PrimaryLocation = 'FLAT 13 NEWALL HOUSE ROCKINGHAM ESTATE HARPER ROAD LONDON SE1 6QD'
    let Loc1 = 'KING WILLIAM FOURTH - SE1 ROCKINGHAM STREET LONDON'
    let loc2 = 'FALMOUTH ROAD - SE1 51-100 FALMOUTH ROAD LONDON'
    let type = `C06 - Robbery - Business`
    let subtype = 'CQ20 - Suspect Present'

    //Step 1: As a dispatcher navigate to the map and locate and log 3 incidents that are within close proximity to each other. 3 incidents located and logged from the map
    const PrimaryIncident_ID = await Contactformpage.CreateInc(PrimaryLocation, type, subtype)
    await Contactformpage.ClearForm()
    const IncidentID1 = await Contactformpage.CreateInc(Loc1, type, subtype)
    //const IncidentID2 = await Contactformpage.CreateInc(loc2, type, subtype)
    console.log(`Primary Incident ID is: ${PrimaryIncident_ID}, Incident ID1 ${IncidentID1}`)
    let comment = 'Linked - Possible duplicates, more details required'
    await CreateCrossReferencepage.CreateCrossReference(PrimaryIncident_ID, IncidentID1, comment)
    await CreateCrossReferencepage.CancelCrossReference(PrimaryIncident_ID,[IncidentID1],"Cancel")
    //await page.pause()
    let comment1 = `Cross Reference Canceled to Event # ${PrimaryIncident_ID}  at:`
    await SelectIncidentpage.SelectIncident(IncidentID1)
    await SearchCommentspage.searchcomments(comment1)
    //await CreateCrossReferencepage.CRCommentsValidation(IncidentID1,"Cancel")
   /* let PrimaryIncident_ID= 'MPS20250521000018'
    let IncidentID1='MPS20250521000019'
    await page.pause()
    await CreateCrossReferencepage.VerifyCRinDialog()
    //let IncidentID2='MPS20250520000014'*/
    //let IncidentIDs = ['MPS20250520000013',  'MPS20250520000014']*/
       
}
)