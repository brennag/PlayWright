const {test,expect} = require('@playwright/test')
const testdata =JSON.parse(JSON.stringify(require('../../testdata/data.json')));
const{appendToLogFile}=require('../testlogs')
const{PageObjects}=require('../../pageobjects/PageObjects')



test('Change Contact Priority', async({browser}) =>
    {
        appendToLogFile(`\n=======================${__filename}==========================`)
        const context = await browser.newContext()
        const page = await context.newPage()
        const pages = new PageObjects(page)
        const{loginpage,Contactformpage,InvokeCommandpage,DialogOpenpage,ChangeRolepage,CommonUtilspage}=pages
        await loginpage.goTO()
        await loginpage.validLogin(testdata.FCOusername,testdata.FCOpassword,testdata.FCOposition)
        let Mappage =await loginpage.waitForNewPageAndCheckTitle()
        let Contact_Id = await Contactformpage.createcontact('55 FINSEN ROAD LONDON SE5 9AW','P13','PQ45')
        let priority = await Contactformpage.priority.textContent()
        let prioritynumber =Number(priority.replace(/[^\d]/g, ''))
        console.log(prioritynumber)

        //Upgrading priority as Calltaker
        await InvokeCommandpage.invokecommand(`CHANGE PRIORITY -e ${Contact_Id}`)

        //Change Contact Priority dialog - Priority Upgrading
        await expect(page.locator(`//*[@label='(lbl_change_contact_priority_contact_id)']`)).toHaveValue(Contact_Id)
        await expect(page.locator(`//input[@name='(lbl_change_contact_priority_current_priority)']`)).toHaveValue(`${prioritynumber}`)
        await CommonUtilspage.SelectDropdownValue('(lbl_change_contact_priority_new_priority)',prioritynumber-1)
        await CommonUtilspage.SelectDropdownValue('(lbl_change_contact_priority_reason)','Further Info received')
        await page.locator(`//*[contains(@class,'main-command-dialog-container')]//button[contains(@class,'submit-btn')]`).click()

        //Validating Incident priority changed
        let opentabs=context.pages()
        Mappage=opentabs[1]
        const pages1= new PageObjects(Mappage)
        await Mappage.bringToFront()
        const{SelectIncidentpage,IncidentPanelpage,SearchCommentspage}=pages1
        await SelectIncidentpage.SelectIncident(Contact_Id)
        await Mappage.bringToFront()
        let new_priority=await IncidentPanelpage.priority.textContent()
        if(new_priority==`P${prioritynumber-1}`){
            appendToLogFile(`Pass:Priority Upgraded Successfully`)
        }
        else{
            appendToLogFile(`Fail: Priority NOT Upgraded`)
        }

        //Change Contact Priority dialog - Priority downgrading
        await page.bringToFront()
        await InvokeCommandpage.invokecommand(`CHANGE PRIORITY -e ${Contact_Id}`)
        await CommonUtilspage.SelectDropdownValue('(lbl_change_contact_priority_new_priority)',prioritynumber+1)
        await CommonUtilspage.SelectDropdownValue('(lbl_change_contact_priority_reason)','Further Info received')
        await page.locator(`//*[contains(@class,'main-command-dialog-container')]//button[contains(@class,'submit-btn')]`).click()

        //downgrading -user does not have access
        await page.waitForTimeout(2000)
        let iswarningvisible=await page.locator(`//*[contains(@class,'main-command-dialog-container')]//h5[starts-with(text(),'User')]`).isVisible()
        if(iswarningvisible){
            let downgradewarning=await page.locator(`//*[contains(@class,'main-command-dialog-container')]//h5`).textContent()
            if(downgradewarning==`User does not have access to downgrade the priority of ${Contact_Id}`){
                appendToLogFile('pass:Priority downgrade warning displayed')
             }
             else{
                 appendToLogFile('Fail:Priority downgrade warning NOT displayed')
             }
        }
        await context.close()
    }
)
