const { test, expect } = require('@playwright/test');
const testdata = JSON.parse(JSON.stringify(require('../../testdata/data.json')));
const { PageObjects } = require('../../pageobjects/PageObjects');
const { appendToLogFile } = require('../testlogs')
const { clear } = require('console');
/*const { IncidentBoardSearch } = require('../../pageobjects/Incident/IncidentBoardSearch');
const { AssignResultCodeNew } = require('../../pageobjects/Incident/AssignResultCodeNew');
const { CreateCrossReference } = require('../../pageobjects/Incident/CreateCrossReference');
const { SearchComments } = require('../../pageobjects/CreateContact/SearchComments');*/
test('CRI-023-CreateIncident', async ({ browser }) => {

  appendToLogFile(`\n=========${__filename}==========`)
  const context = await browser.newContext();
  const page = await context.newPage();
  const pages = new PageObjects(page);
  const { loginpage, Contactformpage, IncidentBoardSearchpage, logoutpage,CloseIncidentpage} = pages
  await loginpage.goTO()
  await loginpage.validLogin('paravapalli', 'Ingr.112233', '101/AP')
  //await loginpage.validLogin (testdata.Operatorusername,testdata.Operatorpassword,testdata.Operatorposition)
  const Mappage = await loginpage.waitForNewPageAndCheckTitle()
  const pages1 = new PageObjects(Mappage);
  const { DuplicateAndCancelpage,IncidentChronologypage, AssignResultCodeNewpage } = pages1
  let PrimaryLocation = 'FLAT 13 NEWALL HOUSE ROCKINGHAM ESTATE HARPER ROAD LONDON SE1 6QD'
  let Loc1 = 'KING WILLIAM FOURTH - SE1 ROCKINGHAM STREET LONDON'
  let loc2 = 'FALMOUTH ROAD - SE1 51-100 FALMOUTH ROAD LONDON'
  let type = `C06 - Robbery - Business`
  let subtype = 'CQ20 - Suspect Present'
  let type1 = 'C14 - Public Order Offences'
  let subtype1 = 'CQ51 - Breach of the Peace'
  const PrimaryIncident_ID = await Contactformpage.CreateInc(PrimaryLocation, type, subtype)
  await Contactformpage.ClearForm()
  const IncidentID = await Contactformpage.CreateInc(Loc1, type1, subtype1)
  //let PrimaryIncident_ID= 'MPS20250610000010'
  //let IncidentID='MPS20250610000010'
  //await DuplicateAndCancelpage.DuplicateCancel(PrimaryIncident_ID,IncidentID,"Test")
  //let PrimaryIncident_ID="MPS20250527000024"
  //let ContactID="MPS20250527000023"
  await page.setViewportSize({ width: 1920, height: 1200 })
  await DuplicateAndCancelpage.DuplicateCancel(PrimaryIncident_ID, IncidentID, "Test")
  let SearchTxt = "Resolution: Type: 720"
  await IncidentChronologypage.incidentchronology(IncidentID, SearchTxt)
  await page.pause()
  await IncidentBoardSearchpage.incidentboardsearch(null, IncidentID)
  //await this.page.bringToFront()
  
  let Result_code = 'C14 - Public Order Offences'
  let Result_Classification = 'Contact Record'
  let Qualifier = '205 - Rowdy Behaviour'
  let Resolution = '700 - Detain/Detained'
  let tag = 'Supervisor - Ready to Close'
  const Incident_status =await IncidentBoardSearchpage.incidentboardsearch(null,IncidentID)
  if(Incident_status=='(Despatcher Awaiting Review)'){
      appendToLogFile(`Pass: Incident is under Awaitng Review column`)
  }
  else{
      appendToLogFile('Fail: Incident is NOT moved to Awaitign Review column')
  }
  await page.pause()
  await AssignResultCodeNewpage.assignresultcode(IncidentID, Result_code, Result_Classification, Qualifier, Resolution, tag)
  await page.bringToFront()
  //----

  await logoutpage.logout()
  await page.waitForTimeout(10000)
  await loginpage.goTO()
  await loginpage.validLogin(testdata.Supervisorusername, testdata.Supervisorpassword, testdata.Supervisorposition)
  //await loginpage.waitForNewPageAndCheckTitle()
  const Mappage2 = await loginpage.waitForNewPageAndCheckTitle()
  const pages3 = new PageObjects(Mappage2)
  const { DialogOpenpage, SelectIncidentpage,SearchCommentspage, CreateCrossReferencepage } = pages3
  //await page.bringToFront()
  let Incident_status_check_as_supervisor = await IncidentBoardSearchpage.incidentboardsearch(null,IncidentID) 
  if(Incident_status_check_as_supervisor=='(Despatcher Awaiting Review)'){
      appendToLogFile(`Pass: Incident is in 'Awaiting Review' column checked as supervisor`)
 }
 else{
     appendToLogFile(`Fail: Incident is NOT in 'Awaiting Review' column checked as supervisor`)
 }
  await page.pause()
  //  await Mappage.bringToFront()
  //await IncidentPanelContextMenupage.incidentpanelcontextmenu(IncidentID,'Close')
  await DialogOpenpage.DialogOpen('Close Incident', `Close -e ${IncidentID}`)
  await CloseIncidentpage.closeIncident(IncidentID, Result_code, Result_Classification, Qualifier, Resolution, tag)
  await SelectIncidentpage.SelectIncident(IncidentID)
  let comment=`Cross Referenced to Event # ${IncidentID}  at:`
  await SearchCommentspage.searchcomments(comment)
  await CreateCrossReferencepage.CRSectionOpen()
  await CreateCrossReferencepage.ContextMenuinCRSection.nth(0).click()//click on the context menu
  await CreateCrossReferencepage.OpenContextMenuinCRSection.click()
  let comment1= `Closed the event at`
  await SearchCommentspage.searchcomments(comment1)
  await page.pause()

  //await CreateCrossReferencepage.VerifyCrossReference
}

)