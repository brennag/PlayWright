const {test,expect} = require('@playwright/test')
const testdata =JSON.parse(JSON.stringify(require('../../testdata/data.json')));
const{appendToLogFile}=require('../testlogs')
const{PageObjects}=require('../../pageobjects/PageObjects')



test('CRI-040', async({browser}) =>
{
    appendToLogFile(`\n=======================${__filename}==========================`)
    const context = await browser.newContext()
    const page = await context.newPage()
    const pages = new PageObjects(page)
    const{loginpage,Contactformpage,RecentlistContactSearchpage,DialogOpenpage,RecentlistContextMenupage,CloseContactpage,AcknowledgeUnitpage,IncidentAdvSearchpage}=pages

    await loginpage.goTO()
    await loginpage.validLogin(testdata.FCOusername,testdata.FCOpassword,testdata.FCOposition)
    const Mappage = await loginpage.waitForNewPageAndCheckTitle()

    //Step1: As a call taker, create a Contact.
    const Contact_ID=await Contactformpage.createcontact('13 MADDOCK WAY LONDON SE17 3NH','C13','CQ45')
    await RecentlistContactSearchpage.recentlistcontactsearch(Contact_ID)

    //Step2: On the My History tab on the right, select the Contact and right click to open the menu. Select Close.
    await RecentlistContextMenupage.recentlistContactContextMenu(Contact_ID,'Close Contact')
    await DialogOpenpage.DialogOpen('Close Contact',null)
    await expect(page.locator(`//*[@label="(LBL_CANCELEVENT_EVENTID)"]//*[contains(@class,'hxgn-inner-select__single-value')]`)).toContainText(Contact_ID)
    appendToLogFile(`Pass: The Close Contact window appears with the Incident ID field already filled.`)

    //Step3: Type a remark, select a Disposition code and Submit.
    let isContactavailable =await CloseContactpage.closecontact(Contact_ID,'CRI-040','700')
    if(!isContactavailable){
        appendToLogFile(`Pass : The Contact '${Contact_ID}' is closed and no longer appears on My History tab`)
    }
    else{
        appendToLogFile(`Fail : The Contact '${Contact_ID}' is NOT closed and appears on My History tab`)
    }

    //Step4 : Advanced Incident search 
    await page.setViewportSize({ width: 1920, height: 1200 });
    const AllIncidents= await IncidentAdvSearchpage.incidentAdvSearch('Last 12 Hours',null,'Closed')
    if(AllIncidents.has(Contact_ID)){
        appendToLogFile(`Pass:The closed Contact ${Contact_ID} appears on the left side of the Incident Search window`) 
    }
    else{
        appendToLogFile(`Pass:The closed Contact ${Contact_ID} NOT appears on the left side of the Incident Search window`)
    }
    appendToLogFile(`Test Passed`)
    await context.close()
    

}
)