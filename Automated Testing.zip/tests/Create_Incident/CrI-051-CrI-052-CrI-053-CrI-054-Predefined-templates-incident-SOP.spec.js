const {test,expect} = require('@playwright/test')
const testdata =JSON.parse(JSON.stringify(require('../../testdata/data.json')));
const{appendToLogFile}=require('../testlogs')
const{PageObjects}=require('../../pageobjects/PageObjects')

test('CRI-051 & CRI-052 & CRI-053 & CRI-054', async({browser}) =>
    {
        appendToLogFile(`\n=======================${__filename}==========================`)
        const context = await browser.newContext()
        const page = await context.newPage()
        const pages = new PageObjects(page)
        const{loginpage,Contactformpage,logoutpage,IncidentBoardSearchpage}=pages;
        await loginpage.goTO()
        await loginpage.validLogin(testdata.FCOusername,testdata.FCOpassword,testdata.FCOposition)
        await loginpage.waitForNewPageAndCheckTitle()

        //Step1.2 : call taker user:Create a contact for an emergency call,having SOP
        const Incidentlocation ='FLAT A 39 VILLA ROAD LONDON SW9 7ND'
        const IncidentType ='A02'
        const IncidentSubType='AQ05'
        await Contactformpage.SaveCallerDetails('testuser','1992-07-25','Third Party','999 Emergency','9273739',null,'FLAT 49 GWEN MORRIS HOUSE WYNDHAM ROAD LONDON SE5 0AD')
        const Incident_ID = await Contactformpage.createcontact(Incidentlocation,IncidentType,IncidentSubType) 
        await Contactformpage.sendtodespatch.click()

        //Step3: As a dispatcher, observe the incident board.
        await logoutpage.logout()
        await page.waitForTimeout(10000)
        await loginpage.goTO()
        await loginpage.validLogin(testdata.Operatorusername,testdata.Operatorpassword,testdata.Operatorposition)
        const Mappage =await loginpage.waitForNewPageAndCheckTitle()
        await IncidentBoardSearchpage.incidentboardsearch(null,Incident_ID)

        //Step4: As a dispatcher, open the incident dialog.The SOP has been added to the incident. The SOP icon is visible on left hand panel of the incident dialog.
        const pages1 = new PageObjects(Mappage)
        const{SelectIncidentpage,ContactformSOPSearchpage, SOPPanelSOPSearchpage,SOPExecutionpage}=pages1
        await Mappage.bringToFront()
        await SelectIncidentpage.SelectIncident(Incident_ID)
        const SOPname ='Automation SOP' 
        await ContactformSOPSearchpage.ContactformSOPSearch(SOPname)

        //Step5: On the SOPs section ACCEPT the task.
        await Mappage.locator("//*[contains(@class,'accept-task-btn')]").click()
        await Mappage.waitForTimeout(2000)
        let timer =await Mappage.locator(`//*[text()='Time On Task']/parent::*/following-sibling::*//*[@class="sop-time"]`).first().textContent()
        console.log(timer)
        if(timer!='00:00:00')
        {
            appendToLogFile(`Pass: The SOP task is accepted and the timer Starts`)
        }
        else{
            appendToLogFile(`Fail: The timer not started after accepting the task`)
        }

        //STEP6:Select the SOP manager icon from the top right of the main menu bar at the top of the screen.
        await SOPPanelSOPSearchpage.SOPPanelSOPSearch(Incident_ID,SOPname)
        if(await SOPPanelSOPSearchpage.yourSOPtasksvalidation(SOPname)){
            appendToLogFile(`Pass:The SOP added to the incident is listed in 'Your SOP tasks' `)
        }
        else{
            appendToLogFile(`Fail:The SOP added to the incident is NOT listed in 'Your SOP tasks' `)
        }
       

        //step5,6:execute sops
        const taskprogress =await SOPExecutionpage.SOPExecution(SOPname);
        console.log(taskprogress)
        if(taskprogress==100){
            appendToLogFile(`Pass: All SOP tasks executed successfully`)
        }

        else{
            appendToLogFile(`Fail: All SOP tasks NOT executed successfully`)
        }

        //Step7: Select the SOP manager icon from the top right of the main menu bar at the top of the screen and observe "Your SOP Tasks" section.
        if(!await SOPPanelSOPSearchpage.yourSOPtasksvalidation(SOPname)){
            appendToLogFile(`Pass:In the SOP dialog, the section "Your SOP Tasks" is empty.`)
        }
        else{
            appendToLogFile(`Fail:In the SOP dialog, the section "Your SOP Tasks" is NOT empty.`)
        }



    }
)