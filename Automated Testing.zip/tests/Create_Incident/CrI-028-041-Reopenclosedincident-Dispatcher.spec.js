const { test, expect } = require('@playwright/test');
const testdata = JSON.parse(JSON.stringify(require('../../testdata/data.json')));
const { appendToLogFile } = require('../testlogs'); // Import logging function
const { PageObjects } = require('../../pageobjects/PageObjects')

test('CRI-028', async ({ browser }) => {
    appendToLogFile(`\n=======================${__filename}==========================`)
    const context = await browser.newContext();
    const page = await context.newPage();
    const pages = new PageObjects(page)
    const { loginpage, IncidentAdvSearchpage,  ReopenIncidentpage, CommonUtilspage,IncidentBoardSearchpage } = pages;

    //Step1: Login as a Calltaker
    await loginpage.goTO()
    await loginpage.validLogin(testdata.Operatorusername, testdata.Operatorpassword, testdata.Operatorposition)
    //await loginpage.validLogin('paravapalli','Ingr.112233','101/AP')
    const Mappage = await loginpage.waitForNewPageAndCheckTitle()
    const pages2 = new PageObjects(Mappage)
    const { SelectIncidentpage, SearchCommentspage } = pages2
    //await page.pause()
    //Step2: Use Advanced search to get the closed incidents.
    let IncidentIDs = await IncidentAdvSearchpage.incidentAdvSearch(null, null, 'Closed')
    let IncidentID = IncidentIDs.values().next().value;
    if (IncidentID) {
        appendToLogFile(`Pass: Found incident ${IncidentID} which is already closed.`)
    }
    else {
        appendToLogFile(`Fail: Failed to get any closed incident.`)
        throw new Error('Fail: Failed to get any closed incident. — stopping test')
    }
    console.log(IncidentID)
    //Step 4: Reopen the selected Incident
    await ReopenIncidentpage.ReopenIncident(IncidentID, "comments")
    //await page.pause()

    //Step 5: Search for the Incident and check whether it is under Unassigned column.
    const Incident_status = await IncidentBoardSearchpage.incidentboardsearch(null, IncidentID)
    if (Incident_status == 'Unassigned') {
        appendToLogFile(`Pass: Incident is under Awaitng Review column`)
    }
    else {
        appendToLogFile('Fail: Incident is NOT moved to Awaitign Review column')
    }
    //Step 5: Search for comments to check comments stating the incident is reopened.
    await CommonUtilspage.SwitchToMapPage()
    await SelectIncidentpage.SelectIncident(IncidentID)
    let comment = `Event ${IncidentID}  has been reopened at: `
    await SearchCommentspage.searchcomments(comment)
    
}
)