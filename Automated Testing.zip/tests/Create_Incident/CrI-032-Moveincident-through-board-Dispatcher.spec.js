const {test,expect} = require('@playwright/test')
const testdata =JSON.parse(JSON.stringify(require('../../testdata/data.json')));
const{appendToLogFile}=require('../testlogs')
const{PageObjects}=require('../../pageobjects/PageObjects')



test('CRI-032', async({browser}) =>
{
    appendToLogFile(`\n=======================${__filename}==========================`)
    const context = await browser.newContext()
    const page = await context.newPage()
    const pages = new PageObjects(page)
    const{loginpage,Contactformpage,ValidateIncidentcardpage,IncidentBoardSearchpage,HoldIncidentpage,IncidentCardContextMenupage,DespatchUnitpage,AcknowledgeUnitpage}=pages
    await loginpage.goTO()
    await loginpage.validLogin(testdata.Operatorusername,testdata.Operatorpassword,testdata.Operatorposition)
    const Mappage = await loginpage.waitForNewPageAndCheckTitle()
    const pages2= new PageObjects(Mappage)
    const{SelectIncidentpage,IncidentPanelpage}=pages2

    //Step1: Send an incident for dispatch using a incident type and sub-type that will route for a manual dispatch.
    const location='33 SUNRAY AVENUE LONDON SE24 9PX'
    const Incident_Type='C02 - Sexual Offences'
    const Incident_Sub_Type='CQ08 - Suspect Present'
    const Incident_ID=await Contactformpage.CreateInc(location,Incident_Type,Incident_Sub_Type)
    let Dgroup= await page.locator("//table[@id='agencygadgetResponse']//td[6]").textContent()
    let priority = await Contactformpage.priority.textContent()
    let Incident_Type_code =Incident_Type.split(' - ')[0]
    let Incident_Type_Description =Incident_Type.split(' - ')[1]
    let Incident_Sub_Type_code=Incident_Sub_Type.split(' - ')[0]
    let Incident_Sub_Type_Description=Incident_Sub_Type.split(' - ')[1]
    //Validating Incident card
    await ValidateIncidentcardpage.ValidateIncidentcard(Incident_ID,priority,Incident_Type_code,Incident_Type_Description,Incident_Sub_Type_code,Incident_Sub_Type_Description,location,Dgroup,null)
    let Incidentstatus =await IncidentBoardSearchpage.incidentboardsearch(Dgroup,Incident_ID)
    if(Incidentstatus=='Unassigned'){
        appendToLogFile(`Pass: Incident is Unassigned just after creation`)
    }
    else{
        appendToLogFile('Fail: Incident is NOT Unassigned just after creation')
    }
    // await page.pause()
    //Step2: The dispatcher sets the incident status to Held.
    await IncidentCardContextMenupage.incidentcardcontextmenu(Incident_ID,'Hold Incident')
    await HoldIncidentpage.HoldIncident(Incident_ID,'10')
    await page.waitForTimeout(2000)
    let Incidentstatus_after_held = await IncidentBoardSearchpage.incidentboardsearch(null,Incident_ID)
    if(Incidentstatus_after_held=='Awaits Tasking')
    {
        appendToLogFile('Pass: Incident is moved to Awaits Tasking after held')
    }
    else{
        appendToLogFile(`Fail: Incident is NOT moved to Await Tasking Column`)
    }
    
    //Step3: The dispatcher sets the incident status to unassigned.
    await IncidentCardContextMenupage.incidentcardcontextmenu(Incident_ID,'Move to Unassigned')
    await page.waitForTimeout(2000)
    let Incident_status_after_unassigned = await IncidentBoardSearchpage.incidentboardsearch(null,Incident_ID)
    if(Incident_status_after_unassigned=='Unassigned'){
        appendToLogFile(`Pass: Incident is Unassigned after setting the status as unassigned`)
    }
    else{
        appendToLogFile(`Pass: Incident is NOT  Unassigned after setting the status as unassigned`)
    }

    //Step4: The dispatcher assigns a unit 
    let result=await DespatchUnitpage.DespatchUnit(null,Incident_ID)
    const UnitId= result[0] 
    await page.waitForTimeout(2000)
    let Incident_status_after_unit_assigned = await IncidentBoardSearchpage.incidentboardsearch(null,Incident_ID)
    if(Incident_status_after_unit_assigned=='Assigned'){
         appendToLogFile(`Pass: Incident is assigned after unit despatched`)
    }
    else{
        appendToLogFile(`Fail: Incident is NOT assigned after unit despatched`)
    }

    //Step5:The unit accepts the assignment
    await AcknowledgeUnitpage.acknowledgeunit(UnitId,Incident_ID)
    await page.waitForTimeout(2000)
    let Incident_status_after_unit_acknowledged =await IncidentBoardSearchpage.incidentboardsearch(null,Incident_ID)
    if(Incident_status_after_unit_acknowledged=='Assigned'){
        appendToLogFile(`Pass: Incident remains assigned after unit accepts the assignment`)
   }
   else{
       appendToLogFile(`Fail: Incident is NOT assigned after unit accepts the assignment`)
   }
   appendToLogFile(`Test Passed`)
    await context.close()
}
)