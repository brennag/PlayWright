const {test, expect} = require ('@playwright/test');
const testdata =JSON.parse(JSON.stringify(require('../../testdata/data.json')));
const { appendToLogFile } = require('../testlogs'); // Import logging function
const{PageObjects} = require('../../pageobjects/PageObjects')

test('CRI-095 & CRI-096', async ({browser}) =>
    {       
        appendToLogFile(`\n=======================${__filename}==========================`)
        const context = await browser.newContext();
        const page = await context.newPage();
        const pages=new PageObjects(page)
        const{loginpage,Sidemenupage,Menupage,ScheduledIncidentpage,DialogOpenpage,IncidentSearchwithDateTimepage,IncidentBoardSearchpage}=pages;

        //Step1: As a dispatcher select the main OnCall Despatch menu and go to incident > create > create scheduled incident
        await loginpage.goTO()
        await loginpage.validLogin(testdata.Operatorusername,testdata.Operatorpassword,testdata.Operatorposition)
        await loginpage.waitForNewPageAndCheckTitle()
        // await Menupage.NaviagtingToOptionsInMenu('Actions','Incident','Create','Create Scheduled Incident',null)
        // await Sidemenupage.ThreeLevelMenu('Incident','Create','Create Scheduled Incident')
        await DialogOpenpage.DialogOpen('Create Scheduled Incident','CREATE SCHEDULED INCIDENT')

        //Step2,3,4: Create Schedule incident with all the details, check schedule incident tab for the incident created and also the calendar
        let Incidenttitle ='CRI-095'
        let Callername='testCaller'
        let incident_location ='FLAT 2 7 MOORLAND ROAD LONDON SW9 8UA'
        let incidenttype='C02 - Sexual Offences'
        let incident_type_desc ='Sexual Offences' 
        let incidentsubtype ='CQ08 - Suspect Present'
        await page.pause()
        await ScheduledIncidentpage.savescheduledIncidentdetails(incident_location,incidenttype,incidentsubtype,Incidenttitle,Callername) 
        await ScheduledIncidentpage.ScheduledIncidentSaveCallerDetails('newcaller','924823923','Non Emergency','14 ASCOT PARK BLYTHEWOOD LANE ASCOT SL5 8E')
        await ScheduledIncidentpage.CreateScheduledIncidentTimings({hours:2},'25')
        await ScheduledIncidentpage.ValidateScheduleIncidentsTab({hours:2,minutes:-3},Callername,Incidenttitle)

        //Step6,7: In the Scheduled Incidents tab list, select the context menu of the Scheduled incident and select edit date and delta
        await page.locator("//button[contains(@class,'VerticalEllipsisButton')]").first().click()
        await page.locator("//li[@title='Edit']").click()
        
        await page.waitForTimeout(2000)
        let newdelta ='7'
        await expect(await DialogOpenpage.DialogOpen('Edit Scheduled Incident',null)).toBe(true)
        await ScheduledIncidentpage.EditScheduledIncidentdetails({minutes:10},newdelta)
        await page.pause()
        
        if(await ScheduledIncidentpage.ValidateScheduleIncidentsTab({minutes:3},Callername,Incidenttitle))
        {
            appendToLogFile(`Pass: Scheduled Incident details are correctly changed`)
        }
        else{
            appendToLogFile(`Fail:Scheduled Incident details are NOT correctly changed`)
        }
        await page.waitForTimeout(3*60*1000)
        let {Year ,Month, Day,starthrs,startmin,endHrs,endmin}= await ScheduledIncidentpage.getDateTime()
        //Step8: Wait until the delta time before the incident is scheduled to start and observe the incident board for the appropriate BCU.
        const Incident_id =await IncidentSearchwithDateTimepage.incidentsearchwithdatetime([Year,Month,Day],[Year,Month,Day],[starthrs,startmin],[endHrs,endmin],incident_type_desc,incident_location)
        if(!await IncidentBoardSearchpage.incidentboardsearch(null,Incident_id))
        {
            appendToLogFile(`Pass: Scheduled Incident ${Incident_id} is available in the Incident board`)
        }
        else{
            appendToLogFile(`Fail: Scheduled Incident ${Incident_id} is NOT available in the Incident board`)
        }
    }
)