const { test, expect } = require('@playwright/test');
const testdata = JSON.parse(JSON.stringify(require('../../testdata/data.json')));
const { PageObjects } = require('../../pageobjects/PageObjects');
const{appendToLogFile}=require('../testlogs')
const { clear } = require('console');
test('CRI-023-027-Duplicateand Cancel for Contacts', async ({ browser }) => {

    appendToLogFile(`\n=========${__filename}==========`)
    const context = await browser.newContext();
    const page = await context.newPage();
    const pages = new PageObjects(page);
    const { loginpage, Contactformpage,RecentlistContactSearchpage } = pages
    await loginpage.goTO()
    await loginpage.validLogin(testdata.FCOusername,testdata.FCOpassword,testdata.FCOposition)
    const Mappage = await loginpage.waitForNewPageAndCheckTitle()
    const pages1 = new PageObjects(Mappage);
    const { CreateCrossReferencepage, SelectIncidentpage,IncidentChronologypage,SearchCommentspage, DuplicateAndCancelpage } = pages1
    let PrimaryLocation = 'FLAT 13 NEWALL HOUSE ROCKINGHAM ESTATE HARPER ROAD LONDON SE1 6QD'
    let Loc1 = 'KING WILLIAM FOURTH - SE1 ROCKINGHAM STREET LONDON'
    let type = `C06 - Robbery - Business`
    let subtype = 'CQ20 - Suspect Present'
    let type1='C14 - Public Order Offences'
    let subtype1='CQ51 - Breach of the Peace'
    //Step 16: Create 2 contacts to be used for Duplicate and Cancel.
    const PrimaryContact_ID = await Contactformpage.createcontact(PrimaryLocation, type, subtype)
    await Contactformpage.ClearForm()
    const ContactID = await Contactformpage.createcontact(Loc1,type1,subtype1)
    //Steps17-21: Perform Duplicate and cancel
    await DuplicateAndCancelpage.DuplicateCancel(PrimaryContact_ID,ContactID,"Test")
    await page.pause()
    let SearchTxt= "Resolution: Type: 720"
    //Step 22: Check in Chronology and verify the Disposition code: 720 as added.
    await IncidentChronologypage.incidentchronology(ContactID,SearchTxt)
    //Step 23: Verify in Recent contacts list for the cancelled contact.
    let output = await RecentlistContactSearchpage.recentlistcontactsearch(ContactID)
    if (output== false )
    appendToLogFile (`Pass: ContactID ${ContactID} not found under recentlist contacts as it is closed by Duplicate and Cancel`)
    else
    appendToLogFile (`Fail: ContactID ${ContactID} is still under recentlist of contacts`)
}

)