const { test, expect } = require('@playwright/test');
const testdata = JSON.parse(JSON.stringify(require('../../testdata/data.json')));
const { PageObjects } = require('../../pageobjects/PageObjects');
const{appendToLogFile}=require('../testlogs')
const { clear } = require('console');

test('CRI-020', async ({ browser }) => {

    appendToLogFile(`\n=========${__filename}==========`)
    const context = await browser.newContext();
    const page = await context.newPage();
    const pages = new PageObjects(page);
    const { loginpage, IncidentBoardSearchpage, DialogOpenpage, Contactformpage } = pages
    await loginpage.goTO()
    await loginpage.validLogin(testdata.Operatorusername,testdata.Operatorpassword,testdata.Operatorposition)
    const Mappage = await loginpage.waitForNewPageAndCheckTitle()
    const pages1 = new PageObjects(Mappage);
    const { CreateCrossReferencepage, SelectIncidentpage } = pages1
    let PrimaryLocation = 'FLAT 13 NEWALL HOUSE ROCKINGHAM ESTATE HARPER ROAD LONDON SE1 6QD'
    let Loc1 = 'KING WILLIAM FOURTH - SE1 ROCKINGHAM STREET LONDON'
    let loc2 = 'FALMOUTH ROAD - SE1 51-100 FALMOUTH ROAD LONDON'
    let type = `C06 - Robbery - Business`
    let subtype = 'CQ20 - Suspect Present'

    //Step 1: As a dispatcher navigate to the map and locate and log 3 incidents that are within close proximity to each other. 3 incidents located and logged from the map
    const PrimaryIncident_ID = await Contactformpage.CreateInc(PrimaryLocation, type, subtype)
    await Contactformpage.ClearForm()
    const IncidentID1 = await Contactformpage.CreateInc(Loc1, type, subtype)
    await Contactformpage.ClearForm()
    const IncidentID2 = await Contactformpage.CreateInc(loc2, type, subtype)
    await Contactformpage.ClearForm()
    console.log(`Primary Incident ID is: ${PrimaryIncident_ID}, Incident ID1 ${IncidentID1}, Incident ID2:${IncidentID2}`)
    let comment = 'Linked - Possible duplicates, more details required'
    await CreateCrossReferencepage.CreateCrossReference(PrimaryIncident_ID, IncidentID1, comment)
    await CreateCrossReferencepage.CreateCrossReference(PrimaryIncident_ID, IncidentID2, comment)
    /*let PrimaryIncident_ID= 'MPS20250522000029'
    let IncidentID1='MPS20250522000030'
    let IncidentID2='MPS20250522000031'
    //let IncidentIDs = ['MPS20250520000013',  'MPS20250520000014']
    //await page.pause()*/
    await CreateCrossReferencepage.VerifyCrossReference(PrimaryIncident_ID, [IncidentID1, IncidentID2])
    await CreateCrossReferencepage.VerifyCrossReference(IncidentID1, [PrimaryIncident_ID, IncidentID2])
    await CreateCrossReferencepage.VerifyCrossReference(IncidentID2, [PrimaryIncident_ID, IncidentID1])
    //await page.pause()
}
)