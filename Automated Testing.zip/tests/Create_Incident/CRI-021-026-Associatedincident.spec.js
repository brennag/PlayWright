const { test, expect } = require('@playwright/test');
const testdata = JSON.parse(JSON.stringify(require('../../testdata/data.json')));
const { PageObjects } = require('../../pageobjects/PageObjects');
const{appendToLogFile}=require('../testlogs')
const { clear } = require('console');
const { SearchComments } = require('../../pageobjects/CreateContact/SearchComments');
const { CreateContactPage } = require('../../pageobjects/CreateContact/CreateContactpage');
//const { AssociatedIncident } = require('../../pageobjects/Incident/AssociatedIncident');

test('CRI-021&CRI-026', async ({ browser }) => {

    appendToLogFile(`\n=========${__filename}==========`)
    const context = await browser.newContext();
    const page = await context.newPage();
    const pages = new PageObjects(page);
    const { loginpage, Contactformpage } = pages
    await loginpage.goTO()
    await loginpage.validLogin(testdata.Operatorusername,testdata.Operatorpassword,testdata.Operatorposition)
    const Mappage = await loginpage.waitForNewPageAndCheckTitle()
    const pages1 = new PageObjects(Mappage);
    const { CreateCrossReferencepage, SelectIncidentpage,AssociatedIncidentpage,SearchCommentspage } = pages1
    let PrimaryLocation = 'FLAT 13 NEWALL HOUSE ROCKINGHAM ESTATE HARPER ROAD LONDON SE1 6QD'
    let Loc1 = 'KING WILLIAM FOURTH - SE1 ROCKINGHAM STREET LONDON'
    let loc2 = 'FALMOUTH ROAD - SE1 51-100 FALMOUTH ROAD LONDON'
    let type = `C06 - Robbery - Business`
    let subtype = 'CQ20 - Suspect Present'
    let type1='C14 - Public Order Offences'
    let subtype1='CQ51 - Breach of the Peace'

    const PrimaryIncident_ID = await Contactformpage.CreateInc(PrimaryLocation, type, subtype)
    appendToLogFile (`Pass: Incident ${PrimaryIncident_ID} created.`)
    //const IncidentID1 = await Contactformpage.CreateInc(Loc1, type, subtype)

    //await page.pause()
    //To create Associated Incident
    await AssociatedIncidentpage.CreateAssociatedIncident(PrimaryIncident_ID,type1,subtype1)
    appendToLogFile (`Pass: Associated Incident dialog closed.`)
    //Open the incident panel for the original incident
    await SelectIncidentpage.SelectIncident(PrimaryIncident_ID)
    //Get the assoicated incident number from the cross reference section of the original incident
    await CreateCrossReferencepage.CRSectionOpen()
    let AssociatedIncidentID= await CreateCrossReferencepage.IncidentIDinCRSection.textContent()
    console.log(AssociatedIncidentID)
    appendToLogFile (`Pass: Associated Incident ID ${AssociatedIncidentID} created`)
    //To hide the cross reference section
    //await this.page.locator (`//img[@title="Hide"]`).click()
    await CreateCrossReferencepage.CRSectionHide()
    //Check for cross reference comments in the original incident
    let Comment = `Cross Referenced to Event # ${AssociatedIncidentID}`
    //let foundtext = await SeachCommentspage.searchcomments(Comment)
    await SearchCommentspage.searchcomments(Comment)
    //Open the Incident panel for the Associated Incident and check whether it is cross referenced to the first incident
    await SelectIncidentpage.SelectIncident(AssociatedIncidentID)
    await CreateCrossReferencepage.CRSectionOpen()
    let found = await CreateCrossReferencepage.VerifyCRinDialog(AssociatedIncidentID,[PrimaryIncident_ID])
    if(found==0)
    {
        appendToLogFile (`Pass: Primary Incident ${PrimaryIncident_ID} and Associated incident ${AssociatedIncidentID} are cross referenced`)
    }
    else
    {
        appendToLogFile (`Fail: Primary Incident ${PrimaryIncident_ID} and Associated incident ${AssociatedIncidentID} are not cross referenced`)
    }
    await CreateCrossReferencepage.CRSectionHide()
    //Verfiy cross refence comments for the associated incident 
    let Comment1= `Cross Referenced to Event # ${PrimaryIncident_ID}`
    await SearchCommentspage.searchcomments(Comment1)
    //await page.pause()
    //CrI-026 Unlink incidents - associated incident -Cancel cross reference between the associated incidents
    await CreateCrossReferencepage.CancelCrossReference(PrimaryIncident_ID,[AssociatedIncidentID],"Cancel")
   
    //CRI-026-Step9: Verify comments for the associated incident that the cross reference has cancelled.
    await SelectIncidentpage.SelectIncident(AssociatedIncidentID)
    await SearchCommentspage.searchcomments(`Cross Reference Canceled to Event # ${PrimaryIncident_ID}  at: `)
    //await page.pause()
    }
)