import {test, expect} from '@playwright/test';
//importing file system
import fs from 'fs';

test('Download a File', async({page}) =>{
    await page.goto('URL');
    const downloadPromise = page.waitForEvent('download');
    //the following will only work on files, which do not open in a new tab to preview the file.
    //If downloading a file, which opens a preview tab, run the browser in headless mode
    await page.getByText('Download File').click();
    const download = await downloadPromise;

    const suggestedFileName = download.suggestedFilename();
    const filePath = 'download/' + suggestedFileName;
    await download.saveAs(filePath);

    expect(await download.failure()).toBeNull();
    //node.js function to assert that the file exists in the file system
    expect(fs.existsSync(filePath)).toBeTruthy();
});