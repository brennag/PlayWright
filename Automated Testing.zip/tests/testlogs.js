const fs = require('fs');
const path = require('path');

const logFilePath = path.join(__dirname, 'testlogs.txt'); // Single log file

// Clear the log file at the start of each test run
// fs.writeFileSync(logFilePath, "=== Playwright Test Logs ===\n", 'utf8');

// Function to append logs to the file
// const appendToLogFile = (message) => {
//     fs.appendFileSync(logFilePath, `[${new Date().toISOString()}] ${message}\n`, 'utf8');//
// };


async function appendToLogFile( message){ // action= yes or not (this argument is used to confirm the user wants to add the message or not)
    const currentDateTime = new Date();
    const formattedYear = currentDateTime.getFullYear().toString().slice(-2);
    const formattedMonth = ('0' + (currentDateTime.getMonth() + 1)).slice(-2); // Adding 1 because months are zero-indexed
    const formattedDay = ('0' + currentDateTime.getDate()).slice(-2);
    const formattedTime = currentDateTime.toLocaleTimeString('en-US', { hour12: false, timeZone: 'Asia/Kolkata' }).replace(/:/g, ''); // Format: HHMMSS
    // const randomDigits = Math.floor(Math.random() * 100); // generates 2 random digits
 
    let fileName = `TestResult_${formattedYear}${formattedMonth}${formattedDay}`;
    let formattedDateTime = `${formattedYear}/${formattedMonth}/${formattedDay}_${formattedTime}`;
 
    //let filePath = `../PlayWright-OnCall/testlogs-console/${fileName}.txt`
    let filePath = `../AUTOMATED TESTING/testlogs-console/${fileName}.txt`
    fs.appendFileSync(filePath, `[${new Date().toISOString()}] ${message}\n`, 'utf8');//
}

module.exports = { appendToLogFile };
