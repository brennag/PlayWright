const { test, expect } = require('@playwright/test');
const { PageObjects } = require('../../pageobjects/PageObjects');
const { text } = require('stream/consumers');
const exp = require('constants');
const { map } = require('mssql');
const { log } = require('console');
const { login } = require('../../pageobjects/General/login');
const { checkAvailableUnits } = require('../../helpers/checkAvailableUnits');



test('CheckUnits', async ({ browser }) => {

    //call the checkAvailableUnits function
    // Replace with actual function or mock data
    const checkUnits = new checkAvailableUnits;
    const units = checkUnits.Check(); // TODO: Replace with actual data source, e.g., await checkAvailableUnits() if available
    const availableUnits = units.filter(unit => unit.isAvailable);
    console.log('Available Units:', units);
    // Check if the available units are not empty
    if (units.length > 0) {
        console.log('Available units found:', units);
    } else {
        console.log('No available units found.');
    }
    const filteredUnits = Array.isArray(units) ? units.filter(unit => unit.isAvailable) : [];

});
