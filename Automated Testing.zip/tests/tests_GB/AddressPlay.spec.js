const { test, expect } = require('@playwright/test');
import fs from 'fs';
import path from 'path';
import { parse } from 'csv-parse/sync';


test('AddressPlay', async ({ browser }) => {
    const csvFilePath = path.join(__dirname, '../../testdata/'); 
    const csvFileName = 'LondonPostCodesInnerLondonSouthEast.csv';
    const csvData = fs.readFileSync(path.join(csvFilePath, csvFileName), 'utf8');
    const testData = parse(csvData, { columns: true });
    const rowCount = testData.length;
    console.log(`Number of rows in ${csvFileName}: ${rowCount}`);
    const randomRowIndex = Math.floor(Math.random() * rowCount);
    console.log(`Random row index: ${randomRowIndex}`);
    const randomRow = testData[randomRowIndex];
    console.log(`Random row: ${JSON.stringify(randomRow)}`);
    const randomPostcode = randomRow.Postcode;
    console.log(`Random Postcode: ${randomPostcode}`);
    console.log("Script completed successfully.");
});