const { test, expect } = require('@playwright/test');
const { PageObjects } = require('../../pageobjects/PageObjects');
const { text } = require('stream/consumers');
const exp = require('constants');
const { map } = require('mssql');
const { log } = require('console');
const { login } = require('../../pageobjects/General/login');
const{appendToLogFile}=require('../../tests/testlogs');



test('Geocoding', async ({ browser }) => {
    appendToLogFile(`\n=======================${__filename}==========================`)
    const context = await browser.newContext();
    const page = await context.newPage();
    const pages = new PageObjects(page);
    const loginpage = pages.loginpage;
    const CommonUtilspage = pages.CommonUtilspage;
    console.log("==GC-001 - Location search using MPS provided gazetteer service - Eastings & Northings==");
    console.log("==GC-002 - Location search using MPS provided gazetteer service - Address==");
    console.log("==GC-003 - Location search using MPS provided gazetteer service - Postcode==");
    console.log("==GC-004 - Location search using MPS provided gazetteer service - Industry recognised transport hub shortcodes==");
    console.log("==GC-006 - Location search using MPS provided gazetteer service - Latitude/Longitude==");
    await loginpage.goTO();
    await loginpage.validLogin("AU2", "Ingr.112233", "10101/FCO1");
    await loginpage.waitForNewPageAndCheckTitle();
    await CommonUtilspage.SwitchToMapPage(page);
    const page1 = context.pages()[1];
    const Mappage = new PageObjects(page1).Mappage;
    await Mappage.awaitAlerts();
    await page1.waitForTimeout(2000);
    // GetRandomPostcode filters based on required DGroups (third parameter).  Can be missed off for no filtering.  Or provide an array of one or more strings, e.g.
    // ['SE', 'AS']
    // The array can be hardcoded, or created at runtime based on the user's assigned DGroups.
    let randomPostcode = await Mappage.GetRandomPostcode('../../testdata/', 'LondonPostCodesInnerLondonSouthEast.csv', ['SE']);
    await Mappage.MapSearchAddress(randomPostcode);
    //search by address - use result from postcode search
    const searchResult = await Mappage.MapSearchAddress(randomPostcode);
    await Mappage.MapSearchAddress(searchResult);
    //right click map
    await Mappage.map_container.click({ button: 'right' });
    await page1.locator(`//a[normalize-space()='Copy Coordinates to Clipboard']`).click();
    let LL = await Mappage.this.ll_text.innerText();
    let EN = await Mappage.this.en_text.innerText();
    await Mappage.MapSearchAddress(LL);
    await Mappage.MapSearchAddress(EN);
    /*
    const eastings = 530000 + Math.floor(Math.random() * 1000);
    const northings = 180000 + Math.floor(Math.random() * 1000);
    await Mappage.MapSearchAddress(`${eastings}, ${northings}`);
    //
    const latitude = 51.5 + (Math.random() * 0.1);
    const longitude = -0.1 + (Math.random() * 0.1);
    await Mappage.MapSearchAddress(`${latitude}, ${longitude}`);
    */
    console.log("Script completed successfully."); 
});