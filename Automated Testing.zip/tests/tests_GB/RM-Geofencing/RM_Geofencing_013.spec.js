const { test, expect } = require('@playwright/test');
const { PageObjects } = require('../../../pageobjects/PageObjects');
const { text } = require('stream/consumers');
const exp = require('constants');
const { map } = require('mssql');
const { log } = require('console');
const { login } = require('../../../pageobjects/General/login');
const{appendToLogFile}=require('../../testlogs');



test('RM_Geofencing_013', async ({ browser }) => {

    appendToLogFile(`\n=======================${__filename}==========================`)
    const context = await browser.newContext();
    const page = await context.newPage();
    const pages = new PageObjects(page);
    const loginpage = pages.loginpage;
    const CommonUtilspage = pages.CommonUtilspage;
    console.log("==RM_Geofencing_013 - Covert incident & Covert Geofence created triggering alert notification when a covert officer deviates from an agreed route==");
    await loginpage.goTO();
    await loginpage.validLogin("AU2", "Ingr.112233", "10101/FCO1");
    await loginpage.waitForNewPageAndCheckTitle();
    await CommonUtilspage.SwitchToMapPage(page);
    const page1 = context.pages()[1];
    const Mappage = new PageObjects(page1).Mappage;
    const Geofencepage = new PageObjects(page1).Geofencepage;
    await Mappage.awaitAlerts();
    await page1.waitForTimeout(2000);
    //Create and save Covert Polygon Geofence
    let randomPostcode = await Mappage.GetRandomPostcode('../../testdata/', 'LondonPostCodesInnerLondonSouthEast.csv');
    const address = await Mappage.MapSearchAddress(randomPostcode);
    await page1.waitForTimeout(2000);
    const uniqueGeofenceName = `GeoFence_${Date.now()}`;
    await Geofencepage.CreateGeoFenceStart(uniqueGeofenceName, "test Geofence Creation");
    await Geofencepage.SelectDropdown("Despatch Groups", "MPS-AS");
    await Geofencepage.CreatePolygonGeofence(context);
    await Geofencepage.SaveGeofence(context, uniqueGeofenceName);
    await Geofencepage.SearchGeofence(uniqueGeofenceName);
    await Geofencepage.GeofenceVisibleOnMap(uniqueGeofenceName);
    await Geofencepage.SearchGeofenceInEditor(uniqueGeofenceName);
    await Geofencepage.SetAllGeofenceNotifications(uniqueGeofenceName, "AS Supervisor");
    await Geofencepage.closeGeofenceEditorDialog_button();
    //need to make this covert incident
    await CreateIncidentMapPage.CreateInc("SE1 3XG", "Test Caller", "A01 - Anti Social Behaviour (ASB) - Personal");
    const incidentID = CreateIncidentMapPage.CreateInc.incidentID;
    await Geofencepage.CheckGeofenceNotification("Incident ID = " + incidentID);
    //Despatch Covert Unit to Geofence - verify notification received
    await DespatchUnitpage.DespatchUnit("XXX", incidentID);
    await DespatchUnitpage.ArriveUnit("XXX", incidentID);
    await Geofencepage.CheckGeofenceNotification("XXX entered geofence" + uniqueGeofenceName + " at ");
    await ChangeUnitLocationpage.changeUnitLocation("XXX", "SW1 4EL");
    await Geofencepage.CheckGeofenceNotification("XXX exited geofence" + uniqueGeofenceName + " at ");
    await ClearUnitpage.ClearUnit("XXX");    
    //Desptach BCU Unit to Geofence - verify notification NOT received
    //TODO - check notification NOT received
    await DespatchUnitpage.DespatchUnit("XXXX", incidentID);
    await DespatchUnitpage.ArriveUnit("XXX", incidentID);
    await Geofencepage.CheckGeofenceNotification("XXX entered geofence" + uniqueGeofenceName + " at ");
    await ChangeUnitLocationpage.changeUnitLocation("XXX", "SW1 4EL");
    await Geofencepage.CheckGeofenceNotification("XXX exited geofence" + uniqueGeofenceName + " at ");
    await ClearUnitpage.ClearUnit("XXX");    
    //Teardown / clean up
    //might be able to string both together
    await Geofencepage.DeleteGeofenceFromEditor(uniqueGeofenceName);
    await InvokeCommandpage.invokecommand(`CLOSE -e ${incidentID}`);
    console.log("Script completed successfully.");
    //Desptach BCU Unit to Geofence - verify notification NOT received
});