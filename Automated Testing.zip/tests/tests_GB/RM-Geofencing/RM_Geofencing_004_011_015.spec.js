const { test, expect } = require('@playwright/test');
const { PageObjects } = require('../../../pageobjects/PageObjects');
const { text } = require('stream/consumers');
const exp = require('constants');
const { map } = require('mssql');
const { log } = require('console');
const { login } = require('../../../pageobjects/General/login');
const { CreateIncidentMap } = require('../../../pageobjects/Map/CreateIncidentMap');
const { ChangeUnitLocation } = require('../../../pageobjects/Unit/ChangeUnitLocation');
const{appendToLogFile}=require('../../testlogs');




test('RM_Geofencing_004_011_015', async ({ browser }) => {
    appendToLogFile(`\n=======================${__filename}==========================`)
    const context = await browser.newContext();
    const page = await context.newPage();
    const pages = new PageObjects(page);
    const loginpage = pages.loginpage;
    const CommonUtilspage = pages.CommonUtilspage;
    //const CreateIncidentpage = pages.CreateIncidentpage;
    const DespatchUnitpage = pages.DespatchUnitpage;
    const ClearUnitpage = pages.ClearUnitpage;
    console.log("==RM_Geofencing_004 - Authorised user creates a circle Geofence via the Geofence Editor against a selected geographical area and assigns Geofence to agency & dispatch group and receives Geofence notifications (standard operational policing)==");
    console.log("==RM_Geofencing_011 - Create Geofence via circle shape and configure rule to alert control room of units entering  the Geofence==");
    console.log("==RM_Geofencing_015 - Create a Geofence and then make modifications to the Geofence and receive notifications when a new incident is created within Geofence==");
    await loginpage.goTO();
    await loginpage.validLogin("AU2", "Ingr.112233", "10101/FCO1");
    await loginpage.waitForNewPageAndCheckTitle();
    await CommonUtilspage.SwitchToMapPage(page);
    const page1 = context.pages()[1];
    const Mappage = new PageObjects(page1).Mappage;
    const Geofencepage = new PageObjects(page1).Geofencepage;
    const CreateIncidentMapPage = new PageObjects(page1).CreateIncidentMappage;
    const ChangeUnitLocationpage = new PageObjects(page1).ChangeUnitLocationpage;
    await Mappage.awaitAlerts();
    await page1.waitForTimeout(2000);
    let randomPostcode = await Mappage.GetRandomPostcode('../../testdata/', 'LondonPostCodesInnerLondonSouthEast.csv');
    const address = await Mappage.MapSearchAddress(randomPostcode);
    await page1.waitForTimeout(2000);
    const uniqueGeofenceName = `GeoFence_${Date.now()}`;
    await Geofencepage.CreateGeoFenceStart(uniqueGeofenceName, "test Geofence Creation");
    await Geofencepage.SelectDropdown("Despatch Groups", "MPS-AS");
    await Geofencepage.CreateCircleGeofence();
    await Geofencepage.SaveGeofence(context, uniqueGeofenceName);
    await Geofencepage.GeofenceVisibleOnMap(uniqueGeofenceName);
    await Geofencepage.SearchGeofenceInEditor(uniqueGeofenceName);
    await Geofencepage.SetAllGeofenceNotifications(uniqueGeofenceName, "AS Operator");
    await Geofencepage.closeGeofenceEditorDialog_button.click();
    //changed from postcode to searchResult
    await CreateIncidentMapPage.CreateInc(address, "Test Caller", "A01 - Anti Social Behaviour (ASB) - Personal");
    const incidentID = CreateIncidentMapPage.CreateInc.incidentID;
    await Geofencepage.CheckGeofenceNotification("Incident ID = " + incidentID);
    //TODO - randomise Unit ID for despatch
    await DespatchUnitpage.DespatchUnit("AD4", incidentID);
    await DespatchUnitpage.ArriveUnit("AD4", incidentID);
    await Geofencepage.CheckGeofenceNotification("AD4 entered geofence" + uniqueGeofenceName + " at ");
    await ChangeUnitLocationpage.changeUnitLocation("AD4", randomPostcode);
    await Geofencepage.CheckGeofenceNotification("AD4 exited geofence" + uniqueGeofenceName + " at ");
    await ClearUnitpage.ClearUnit("AD4");
    await Geofencepage.DeleteGeofenceFromEditor(uniqueGeofenceName);
    await InvokeCommandpage.invokecommand(`CLOSE -e ${incidentID}`);
    console.log("Script completed successfully.");

});