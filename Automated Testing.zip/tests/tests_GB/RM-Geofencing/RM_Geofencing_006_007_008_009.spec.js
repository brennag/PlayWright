const { test, expect } = require('@playwright/test');
const { PageObjects } = require('../../../pageobjects/PageObjects');
const { text } = require('stream/consumers');
const exp = require('constants');
const { map } = require('mssql');
const { log } = require('console');
const { login } = require('../../../pageobjects/General/login');
const { ChangeRole } = require('../../../pageobjects/General/ChangeRole');
const{appendToLogFile}=require('../../testlogs');




test('RM_Geofencing_006_007_008_009', async ({ browser }) => {

    appendToLogFile(`\n=======================${__filename}==========================`)
    const context = await browser.newContext();
    const page = await context.newPage();
    const pages = new PageObjects(page);
    const loginpage = pages.loginpage;
    const ChangeRole = pages.ChangeRolepage;
    const CommonUtilspage = pages.CommonUtilspage;
    console.log("==RM_Geofencing_006 - Unauthorised user is not able to create a Geofence==");
    console.log("==RM_Geofencing_007 - Unauthorised user is not able to edit a Geofence==");
    console.log("==RM_Geofencing_008 - Unauthorised user is not able to remove a Geofence==");
    console.log("==RM_Geofencing_009 - Unauthorised user is not able to receive Geofence notifications for an existing Geofence where the user does not have access to the Agency / Dispatcher==");
    await loginpage.goTO();
    await loginpage.validLogin("AU2", "Ingr.112233", "10101/FCO1");
    await ChangeRole.changerole("Admin (ICF) (BCU ALL (WRITE) - Administrator (ICF))", "Admin")
    await loginpage.GeofencePanelFail();
    await ChangeRole.changerole("First Contact Operator (First Contact OS - First Contact Operator)", "FCO 2 Screen")
    const page1 = context.pages()[1];
    const Mappage = new PageObjects(page1).Mappage;
    const Geofencepage = new PageObjects(page1).Geofencepage;
    await CommonUtilspage.SwitchToMapPage(page);
    await Geofencepage.GeofenceEditorFail();
    await ChangeRole.changerole("AS Operator (BCU - AS - Despatch Operator)", "DespASE")
    let randomPostcode = await Mappage.GetRandomPostcode('../../testdata/', 'LondonPostCodesInnerLondonSouthEast.csv');
    const address = await Mappage.MapSearchAddress(randomPostcode);
    await page1.waitForTimeout(2000);
    const uniqueGeofenceName = `GeoFence_${Date.now()}`;
    await Geofencepage.CreateGeoFenceStart(uniqueGeofenceName, "test Geofence Creation");
    await Geofencepage.SelectDropdown("Despatch Groups", "MPS-CE");
    await Geofencepage.CreateCircleGeofence();
    await Geofencepage.SaveGeofence(context, uniqueGeofenceName);
    await Geofencepage.SearchGeofence(uniqueGeofenceName);
    await Geofencepage.GeofenceVisibleOnMap(uniqueGeofenceName);
    await Geofencepage.SearchGeofenceInEditor(uniqueGeofenceName);
    await Geofencepage.SetAllGeofenceNotifications(uniqueGeofenceName, "AS Operator");
    await Geofencepage.closeGeofenceEditorDialog_button();
    await CreateIncidentMapPage.CreateInc(randomPostcode, "Test Caller", "A01 - Anti Social Behaviour (ASB) - Personal");
    const incidentID = CreateIncidentMapPage.CreateInc.incidentID;
    await Geofencepage.CheckGeofenceNotification("Incident ID = " + incidentID);
    //Teardown / clean up
    await Geofencepage.DeleteGeofenceFromEditor(uniqueGeofenceName);
    await InvokeCommandpage.invokecommand(`CLOSE -e ${incidentID}`);
    console.log("Script completed successfully.");


});