const { test, expect } = require('@playwright/test');
const { PageObjects } = require('../../../pageobjects/PageObjects');
const { text } = require('stream/consumers');
const exp = require('constants');
const { map } = require('mssql');
const { log } = require('console');
const { login } = require('../../../pageobjects/General/login');
const{appendToLogFile}=require('../../testlogs');



test('RM_Geofencing_012', async ({ browser }) => {

    appendToLogFile(`\n=======================${__filename}==========================`)
    const context = await browser.newContext();
    const page = await context.newPage();
    const pages = new PageObjects(page);
    const loginpage = pages.loginpage;
    const CommonUtilspage = pages.CommonUtilspage;
    //const CommonUtilsMappage = pages.CommonUtilsMappage;
    // Ensure PageObjects initializes all required properties
    console.log("==RM_Geofencing_012 - Create Geofence via rectangle and configure rule to alert the Supervisor of units leaving  the Geofence==");
    await loginpage.goTO();
    await loginpage.validLogin("AU2", "Ingr.112233", "10101/FCO1");
    await loginpage.waitForNewPageAndCheckTitle();
    await CommonUtilspage.SwitchToMapPage(page);
    const page1 = context.pages()[1];
    const Mappage = new PageObjects(page1).Mappage;
    const Geofencepage = new PageObjects(page1).Geofencepage;
    await Mappage.awaitAlerts();
    await page1.waitForTimeout(2000);
    let randomPostcode = await Mappage.GetRandomPostcode('../../testdata/', 'LondonPostCodesInnerLondonSouthEast.csv');
    const address = await Mappage.MapSearchAddress(randomPostcode);
    await page1.waitForTimeout(2000);
    const uniqueGeofenceName = `GeoFence_${Date.now()}`;
    await Geofencepage.CreateGeoFenceStart(uniqueGeofenceName, "test Geofence Creation");
    await Geofencepage.SelectDropdown("Despatch Groups", "MPS-AS");
    await Geofencepage.CreateCircleGeofence();
    await Geofencepage.SaveGeofence(context, uniqueGeofenceName);
    await Geofencepage.SearchGeofence(uniqueGeofenceName);
    await Geofencepage.GeofenceVisibleOnMap(uniqueGeofenceName);
    await Geofencepage.SearchGeofenceInEditor(uniqueGeofenceName);
    await Geofencepage.SetAllGeofenceNotifications(uniqueGeofenceName, "AS Supervisor");
    await Geofencepage.closeGeofenceEditorDialog_button();
    //Create Incident within Geofence area
    await CreateIncidentMapPage.CreateInc(randomPostcode, "Test Caller", "A01 - Anti Social Behaviour (ASB) - Personal");
    const incidentID = CreateIncidentMapPage.CreateInc.incidentID;
    await Geofencepage.CheckGeofenceNotification("Incident ID = " + incidentID);
    //TODO - randomise Unit ID for despatch
    await DespatchUnitpage.DespatchUnit("AD4", incidentID);
    await DespatchUnitpage.ArriveUnit("AD4", incidentID);
    await Geofencepage.CheckGeofenceNotification("AD4 entered geofence" + uniqueGeofenceName + " at ");
    let randomPostcode2 = await Mappage.GetRandomPostcode('../../testdata/', 'LondonPostCodesInnerLondonEast.csv');
    await ChangeUnitLocationpage.changeUnitLocation("AD4", randomPostcode2);
    await Geofencepage.CheckGeofenceNotification("AD4 exited geofence" + uniqueGeofenceName + " at ");
    await ClearUnitpage.ClearUnit("AD4");
    await Geofencepage.DeleteGeofenceFromEditor(uniqueGeofenceName);
    await InvokeCommandpage.invokecommand(`CLOSE -e ${incidentID}`);
    console.log("Script completed successfully.");
});