const { test, expect } = require('@playwright/test');
const { PageObjects } = require('../../../pageobjects/PageObjects');
const { text } = require('stream/consumers');
const exp = require('constants');
const { map } = require('mssql');
const { log } = require('console');
const { login } = require('../../../pageobjects/General/login');
const { CommonUtilsMap } = require('../../../pageobjects/CommonUtilsMap');
const{appendToLogFile}=require('../../testlogs');



test('RM_Geofencing_010', async ({ browser }) => {

    appendToLogFile(`\n=======================${__filename}==========================`)
    const context = await browser.newContext();
    const page = await context.newPage();
    const pages = new PageObjects(page);
    const loginpage = pages.loginpage;
    const CommonUtilspage = pages.CommonUtilspage;
    //const CommonUtilsMappage = pages.CommonUtilsMappage;
    // Ensure PageObjects initializes all required properties
    console.log("==RM_Geofencing_010 - User controls the display of the geofence on their map using the Geofence Management Panel==");
    await loginpage.goTO();
    await loginpage.validLogin("AU2", "Ingr.112233", "10101/FCO1");
    await loginpage.waitForNewPageAndCheckTitle();
    await CommonUtilspage.SwitchToMapPage(page);
    const page1 = context.pages()[1];
    const Mappage = new PageObjects(page1).Mappage;
    const Geofencepage = new PageObjects(page1).Geofencepage;
    const CommonUtilsMappage = new PageObjects(page1).CommonUtilsMappage;
    await Mappage.awaitAlerts();
    await page1.waitForTimeout(2000);
    const uniqueGeofenceName = `GeoFence_${Date.now()}`;
    await Geofencepage.CreateGeoFenceStart(uniqueGeofenceName, "test Geofence Creation");
    await Geofencepage.SelectDropdown("Despatch Groups", "MPS-AS");
    await Geofencepage.CreateCircleGeofence();
    await Geofencepage.SaveGeofence(context, uniqueGeofenceName);    
    await Geofencepage.SearchGeofenceInEditor(uniqueGeofenceName);
    await Geofencepage.GeofenceVisibleOnMap(uniqueGeofenceName);
    await Geofencepage.closeGeofenceEditorDialog_button.click();
    //Edit Existing Geofence
    await Geofencepage.SetOpacityLevelWithKeyboard(uniqueGeofenceName, "0");   
    await Geofencepage.SetOpacityLevelWithKeyboard(uniqueGeofenceName, "100");   
    await CommonUtilsMappage.ToggleButton("All Geofences", "Off");
    await CommonUtilsMappage.ToggleButton("All Geofences", "On");
    //Toggle Geofence visibility off
    await CommonUtilsMappage.ToggleButton(uniqueGeofenceName, "Off");
    //Toggle Geofence visibility on
    await CommonUtilsMappage.ToggleButton(uniqueGeofenceName, "On");
    //Toggle Geofence labels off
    await CommonUtilsMappage.ToggleButton("Geofence Labels", "Off");
    //Toggle Geofence labels on
    await CommonUtilsMappage.ToggleButton("Geofence Labels", "On");
    await Geofencepage.openGeofenceEditor_button.click();
    await Geofencepage.DeleteGeofenceFromEditor(uniqueGeofenceName);
    await context.close();
    console.log("Script completed successfully.");
});