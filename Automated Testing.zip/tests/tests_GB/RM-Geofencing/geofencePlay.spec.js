const { test, expect } = require('@playwright/test');
const { PageObjects } = require('../../../pageobjects/PageObjects');
const { text } = require('stream/consumers');
const exp = require('constants');
const { map } = require('mssql');
const { log } = require('console');
const { login } = require('../../../pageobjects/General/login');
const { CommonUtilsMap } = require('../../../pageobjects/CommonUtilsMap');



test('geofence_play', async ({ browser }) => {

    const context = await browser.newContext();
    const page = await context.newPage();
    const pages = new PageObjects(page);
    const loginpage = pages.loginpage;
    const CommonUtilspage = pages.CommonUtilspage;
    console.log("==RM_Geofencing_001 - Authorised user creates a polygon Geofence via the  Geofence Editor against a selected geographical area indicating a police cordon==");
    await loginpage.goTO();
    await loginpage.validLogin("AU2", "Ingr.112233", "10101/FCO1");
    await loginpage.waitForNewPageAndCheckTitle();
    await CommonUtilspage.SwitchToMapPage(page);
    const page1 = context.pages()[1];
    const Mappage = new PageObjects(page1).Mappage;
    const Geofencepage = new PageObjects(page1).Geofencepage;
    await Mappage.awaitAlerts();
    await page1.waitForTimeout(2000);
    //TODO pick address from Excel sheet
    await Mappage.MapSearchAddress('SE1 4LN');
    await page1.waitForTimeout(2000);
    const uniqueGeofenceName = `GeoFence_${Date.now()}`;
    await Geofencepage.CreateGeoFenceStart(uniqueGeofenceName, "test Geofence Creation");
    await Geofencepage.SelectDropdown("Despatch Groups", "MPS-AS");
    await Geofencepage.CreateCircleGeofence();
    await Geofencepage.SaveGeofence();
    await Geofencepage.CheckGeofenceNotification('Geofence created successfully');

    
    console.log("Script completed successfully.");
});