const { test, expect } = require('@playwright/test');
const { PageObjects } = require('../../../pageobjects/PageObjects');
const { text } = require('stream/consumers');
const exp = require('constants');
const { map } = require('mssql');
const { log } = require('console');
const { login } = require('../../../pageobjects/General/login');
const{appendToLogFile}=require('../../testlogs');



test('RM_Geofencing_003', async ({ browser }) => {
    
    appendToLogFile(`\n=======================${__filename}==========================`)
    const context = await browser.newContext();
    const page = await context.newPage();
    const pages = new PageObjects(page);
    const loginpage = pages.loginpage;
    const CommonUtilspage = pages.CommonUtilspage;
    console.log("==RM_Geofencing_003 - Authorised user is able to  remove a Geofence via Geofence Editor==");
    await loginpage.goTO();
    await loginpage.validLogin("AU2", "Ingr.112233", "10101/FCO1");
    await loginpage.waitForNewPageAndCheckTitle();
    await CommonUtilspage.SwitchToMapPage(page);
    const page1 = context.pages()[1];
    const Mappage = new PageObjects(page1).Mappage;
    const Geofencepage = new PageObjects(page1).Geofencepage;
    await Mappage.awaitAlerts();
    await page1.waitForTimeout(2000);
    let randomPostcode = await Mappage.GetRandomPostcode('../../testdata/', 'LondonPostCodesInnerLondonSouthEast.csv');
    const address = await Mappage.MapSearchAddress(randomPostcode);
    await page1.waitForTimeout(2000);
    const uniqueGeofenceName = `GeoFence_${Date.now()}`;
    await Geofencepage.CreateGeoFenceStart(uniqueGeofenceName, "test Geofence Creation");
    await Geofencepage.SelectDropdown("Despatch Groups", "MPS-AS");
    await Geofencepage.CreateCircleGeofence();
    await Geofencepage.SaveGeofence(context, uniqueGeofenceName);
    await Geofencepage.SearchGeofenceInEditor(uniqueGeofenceName);    
    await Geofencepage.GeofenceVisibleOnMap(uniqueGeofenceName);
    await Geofencepage.DeleteGeofenceFromEditor(uniqueGeofenceName);
    await context.close();
    console.log("Script completed successfully.");
    

});