const { test, expect } = require('@playwright/test');
const { PageObjects } = require('../../../pageobjects/PageObjects');
const { login } = require('../../../pageobjects/General/login');
const { config } = require('process');
const{appendToLogFile}=require('../../testlogs');



test('RM_Geofencing_001', async ({ browser }) => {

    appendToLogFile(`\n=======================${__filename}==========================`)
    const context = await browser.newContext();
    const page = await context.newPage();
    const pages = new PageObjects(page);
    const loginpage = pages.loginpage;
    const CommonUtilspage = pages.CommonUtilspage;
    console.log("==RM_Geofencing_001 - Authorised user creates a polygon Geofence via the  Geofence Editor against a selected geographical area indicating a police cordon==");
    await loginpage.goTO();
    //TODO - replace with login script
    await loginpage.validLogin("AU2", "Ingr.112233", "10101/FCO1");
    await loginpage.waitForNewPageAndCheckTitle();
    await CommonUtilspage.SwitchToMapPage(page);
    const page1 = context.pages()[1];
    const Mappage = new PageObjects(page1).Mappage;
    const Geofencepage = new PageObjects(page1).Geofencepage;
    await Mappage.awaitAlerts();
    await page1.waitForTimeout(2000);
    let randomPostcode = await Mappage.GetRandomPostcode('../../testdata/', 'LondonPostCodesInnerLondonSouthEast.csv');
    await Mappage.MapSearchAddress(randomPostcode);
    await page1.waitForTimeout(2000);
    const uniqueGeofenceName = `GeoFence_${Date.now()}`;
    await Geofencepage.CreateGeoFenceStart(uniqueGeofenceName, "test Geofence Creation");
    await Geofencepage.SelectDGs("Despatch Groups", "MPS-AS", "MPS-AW", "MPS-WA");
    //failing to draw polygon sometimes. maybe due to interaction with notifications?
    await Geofencepage.CreatePolygonGeofence(context);
    await Geofencepage.SaveGeofence(context, uniqueGeofenceName);
    await Geofencepage.SearchGeofenceInEditor(uniqueGeofenceName);
    await Geofencepage.GeofenceVisibleOnMap(uniqueGeofenceName);
    //Teardown / clean up
    await Geofencepage.DeleteGeofenceFromEditor(uniqueGeofenceName);
    await context.close();
    console.log("Script completed successfully.");
});