const { test, expect } = require('@playwright/test');
const { PageObjects } = require('../../../pageobjects/PageObjects');
const { text } = require('stream/consumers');
const exp = require('constants');
const { map } = require('mssql');
const { log } = require('console');
const { login } = require('../../../pageobjects/General/login');
const { CommonUtilsMap } = require('../../../pageobjects/CommonUtilsMap');



test('geofence_opacity', async ({ browser }) => {

    const context = await browser.newContext();
    const page = await context.newPage();
    const pages = new PageObjects(page);
    const loginpage = pages.loginpage;
    const CommonUtilspage = pages.CommonUtilspage;
    const CommonUtilsMappage = pages.CommonUtilsMappage;
    // Ensure PageObjects initializes all required properties
    console.log("==Geofence test==");
    await loginpage.goTO();
    await loginpage.validLogin("AU2", "Ingr.112233", "10101/FCO1");
    await loginpage.waitForNewPageAndCheckTitle();
    await CommonUtilspage.SwitchToMapPage(page);
    const page1 = context.pages()[1];
    const Mappage = new PageObjects(page1).Mappage;
    const Geofencepage = new PageObjects(page1).Geofencepage;
    await Mappage.awaitAlerts();
    await page1.waitForTimeout(2000);
    await Geofencepage.SetOpacityLevelWithKeyboard("RECT", "0");   
    console.log("Script completed successfully.");
});