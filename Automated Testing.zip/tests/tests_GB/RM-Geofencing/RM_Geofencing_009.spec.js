const { test, expect } = require('@playwright/test');
const { PageObjects } = require('../../../pageobjects/PageObjects');
const { text } = require('stream/consumers');
const exp = require('constants');
const { map } = require('mssql');
const { log } = require('console');
const { login } = require('../../../pageobjects/General/login');
const{appendToLogFile}=require('../../testlogs');



test('RM_Geofencing_009', async ({ browser }) => {

    appendToLogFile(`\n=======================${__filename}==========================`)
    const context = await browser.newContext();
    const page = await context.newPage();
    const pages = new PageObjects(page);
    const loginpage = pages.loginpage;
    const CommonUtilspage = pages.CommonUtilspage;

    console.log("==RM_Geofencing_009 - Unauthorised user is not able to receive Geofence notifications for an existing Geofence where the user does not have access to the Agency / Dispatcher==");
    await loginpage.goTO();
    //log in with user with no access to geofence
    await loginpage.validLogin("AU2", "Ingr.112233", "10101/FCO1");
    await loginpage.waitForNewPageAndCheckTitle();
    await CommonUtilspage.SwitchToMapPage(page);
    const page1 = context.pages()[1];
    const Mappage = new PageObjects(page1).Mappage;
    const Geofencepage = new PageObjects(page1).Geofencepage;
    await Mappage.awaitAlerts();
    await page1.waitForTimeout(2000);
    let randomPostcode = await Mappage.GetRandomPostcode('../../testdata/', 'LondonPostCodesInnerLondonSouthEast.csv');
    const address = await Mappage.MapSearchAddress(randomPostcode);
    await page1.waitForTimeout(2000);
    const uniqueGeofenceName = `GeoFence_${Date.now()}`;
    await Geofencepage.CreateGeoFenceStart(uniqueGeofenceName, "test Geofence Creation");
    await Geofencepage.SelectDropdown("Despatch Groups", "MPS-AS");
    await Geofencepage.CreateCircleGeofence();
    await Geofencepage.SaveGeofence(context, uniqueGeofenceName);
    await Geofencepage.GeofenceVisibleOnMap(uniqueGeofenceName);
    await Geofencepage.SearchGeofenceInEditor(uniqueGeofenceName);
    await Geofencepage.SearchGeofenceInEditor(uniqueGeofenceName);
    //Set notifications for area outside of responsibility
    await Geofencepage.SetAllGeofenceNotifications(uniqueGeofenceName, "NE Operator");
    await Geofencepage.closeGeofenceEditorDialog_button.click();
    await page1.waitForTimeout(2000);
    await CreateIncidentMapPage.CreateInc(randomPostcode, "Test Caller", "A01 - Anti Social Behaviour (ASB) - Personal");
    const incidentID = CreateIncidentMapPage.CreateInc.incidentID;
    await Geofencepage.CheckGeofenceNotification("Incident ID = " + incidentID);
    //TODO - randomise Unit ID for despatch
    await DespatchUnitpage.DespatchUnit("AD4", incidentID);
    await DespatchUnitpage.ArriveUnit("AD4", incidentID);
    //negative test - should not receive geofence notification as user does not have access to agency/dispatch group
    await Geofencepage.CheckGeofenceNotification("AD4 entered geofence" + uniqueGeofenceName + " at ");
    let randomPostcode2 = await Mappage.GetRandomPostcode('../../testdata/', 'LondonPostCodesInnerLondonEast.csv');
    await ChangeUnitLocationpage.changeUnitLocation("AD4", randomPostcode2);
    //negative test - should not receive geofence notification as user does not have access to agency/dispatch group
    await Geofencepage.CheckGeofenceNotification("AD4 exited geofence" + uniqueGeofenceName + " at ");
    await ClearUnitpage.ClearUnit("AD4");
    await InvokeCommandpage.invokecommand(`ASSIGN RESULT CODES -e ${incidentID}`);
    await CommonUtilspage.SelectARCDropdownValue("(LBL__AssignResultCode_ResultCode)",'P02 - Alarm - Central Station');
    await CommonUtilspage.SelectARCDropdownValue("(LBL__AssignResultCode_ResultClassification)",'No crime - No offences');
    await CommonUtilspage.SelectARCDropdownValue("(LBL__AssignResultCode_Qualifier)",'204 - Inconsiderate Behaviour - Squatting');
    await CommonUtilspage.SelectARCDropdownValue("(LBL__AssignResultCode_Resolution)",'505 - Cancel\/Error');
    await AssignResultCodepage.ARCTag_button("Supervisor - Ready to Close").click();
    await AssignResultCodepage.submit_button.click();
    console.log('Result Code Assigned to Incident');
    await Geofencepage.OpenGeofenceDialog();
    await Geofencepage.DeleteGeofenceFromEditor(uniqueGeofenceName);    
    await ChangeRolepage.changerole("AS Supervisor (BCU - AS - Despatch Enhanced)","SupASE");
    await CommonUtilspage.SwitchingTabs('Incidents').click();
    await CommonUtilspage.SwitchingTabButton('ASE Ready to Close').click();
    await IncidentBoardSearchpage.incidentboardsearch(incidentID);
    await InvokeCommandpage.invokecommand(`CLOSE -e ${incidentID}`);
    console.log("Script completed successfully.");
    
    

});