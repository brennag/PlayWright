const { test, expect } = require('@playwright/test');
const { PageObjects } = require('../../../pageobjects/PageObjects');
const { text } = require('stream/consumers');
const exp = require('constants');
const { map } = require('mssql');
const { log } = require('console');
const { login } = require('../../../pageobjects/General/login');
const{appendToLogFile}=require('../../testlogs');



test('RM_Geofencing_014', async ({ browser }) => {

    appendToLogFile(`\n=======================${__filename}==========================`)
    const context = await browser.newContext();
    const page = await context.newPage();
    const pages = new PageObjects(page);
    const loginpage = pages.loginpage;
    const CommonUtilspage = pages.CommonUtilspage;
    console.log("==RM_Geofencing_014 - Officer enters a geofence around an armed policing operation, verify they are not assigned to or a hazardous area and messages are triggered/sent and received via police issued mobile devices.==");
    await loginpage.goTO();
    await loginpage.validLogin("AU2", "Ingr.112233", "10101/FCO1");
    await loginpage.waitForNewPageAndCheckTitle();
    await CommonUtilspage.SwitchToMapPage(page);
    const page1 = context.pages()[1];
    const Mappage = new PageObjects(page1).Mappage;
    const Geofencepage = new PageObjects(page1).Geofencepage;
    await Mappage.awaitAlerts();
    await page1.waitForTimeout(2000);
    let randomPostcode = await Mappage.GetRandomPostcode('../../testdata/', 'LondonPostCodesInnerLondonSouthEast.csv');
    const address = await Mappage.MapSearchAddress(randomPostcode);
    await page1.waitForTimeout(2000);
    const uniqueGeofenceName = `GeoFence_${Date.now()}`;
    await Geofencepage.CreateGeoFenceStart(uniqueGeofenceName, "test Geofence Creation");
    await Geofencepage.SelectDropdown("Despatch Groups", "MPS-AS");
    await Geofencepage.CreatePolygonGeofence(context);
    await Geofencepage.SaveGeofence(context, uniqueGeofenceName);
    await Geofencepage.SearchGeofence(uniqueGeofenceName);
    await Geofencepage.GeofenceVisibleOnMap(uniqueGeofenceName);
    await Geofencepage.closeGeofenceEditorDialog_button();
    await CreateIncidentMapPage.CreateInc(randomPostcode, "Test Caller", "A01 - Anti Social Behaviour (ASB) - Personal");
    const incidentID = CreateIncidentMapPage.CreateInc.incidentID;
    await DespatchUnitpage.DespatchUnit("XXXX", incidentID);
    await Geofencepage.GeofenceVisibleOnMap(uniqueGeofenceName);
    await Geofencepage.RightClickOnGeofence(uniqueGeofenceName);
    await Geofencepage.SelectContextMenuOption('Send Message to Units');
    await Geofencepage.SendMessageToUnits(uniqueGeofenceName, "AD4", "test subject", "this is the body of the message", 'C:/PlayWright/Automated Testing/tests/tests_GB/starwars.txt', context);
    //Add attachment to message
    //Open Attachment from Geofence



});