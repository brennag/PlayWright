import { test, expect } from '@playwright/test';
//import { connection } from './database/databaseConnection/database';
import mssql from "mssql";
import * as sql from 'mssql';
import * as fs from 'fs';


async function dbQuery_AllInfoFromActiveUnit() {
    let pool = await sql.connect(config);
    let res = await pool.request().query("SELECT * FROM ActiveUnit");
    console.log(res);
    await sql.close();
}

const config = { // Configuration for DB connection
    user: 'metpsDbOwner',
    password: 'D2jwwhleaoxw32x!',
    server: 'metpsprd7777bzqaxfsjg.database.windows.net',
    database: 'sqldb-metpsprddispatch',
};

test('Unit_Availability', async () => {
    await dbQuery_AllInfoFromActiveUnit();
}); 