import { test, expect } from '@playwright/test';

test('Simplified Login', async ({ page }) => {
  
  //Log Console Errors
  page.on('console', msg => {
    console.log(msg)
    expect.soft(msg.type()).not.toEqual('error');
});

//Log Uncaught Errors
  page.on('pageerror', error => {
    console.log('Found an error: ${error.name}, ${error.message}');
    expect.soft(error.name).not.toEqual('Error');
  });


  await page.goto('https://metps-dispatch.hexagonsi.com/oncall');
  await page.locator('#username').click();
  await page.locator('#username').fill('AU2');
  await page.locator('#password').click();
  await page.locator('#password').fill('Ingr.112233');
  await page.getByRole('button', { name: 'Log In' }).click();
  await page.locator('#PositionSelector svg').click();
  await page.getByText('10101/FCO1', { exact: true }).click();
  await page.getByRole('button', { name: 'Continue' }).click();
  const page1Promise = page.waitForEvent('popup');
  await page.waitForLoadState("networkidle");
  const page1 = await page1Promise;
  await page.bringToFront();
  await page.locator("li[title='Create Contact'] ").click();
  await expect(page).toHaveTitle("Create Contact - HxGN OnCall® Despatch");
  console.log("Create Contact page opened");
});