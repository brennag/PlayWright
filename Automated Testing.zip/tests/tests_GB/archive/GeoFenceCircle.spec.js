import { test, expect } from '@playwright/test';

test('CreateGeoFenceCircle', async ({ page }) => {

  //TODO - replace login with auth state from global settings
  await page.goto('https://metps-dispatch.hexagonsi.com/oncall/');
  await page.locator('#username').click();
  await page.locator('#username').fill('AU2');
  await page.locator('#password').click();
  await page.locator('#password').fill('Ingr.112233');
  await page.getByRole('button', { name: 'Log In' }).click();
  await page.locator('.hxgn-inner-select__value-container').first().click();
  await page.getByText('100/ADTEST', { exact: true }).click();
  await page.getByRole('button', { name: 'Continue' }).click();
  const page1Promise = page.waitForEvent('popup');
  await page.goto('https://metps-dispatch.hexagonsi.com/oncall/#!/oncall/?tab=Create%20Contact');
  const page1 = await page1Promise;
  await page1.goto('https://metps-dispatch.hexagonsi.com/oncall/?workspace=b662b776-eca8-4f85-b9b1-ffee0d2fd77b&wsscreen=1&layout=e1203153-344a-4382-835e-067954e31482&tab=e2db2825-3df8-4c1c-b5bc-bd56e50ce812#!/oncall/?tab=Map&workspace=b662b776-eca8-4f85-b9b1-ffee0d2fd77b&layout=DispMap');
  //Dismiss notifications - need to ensure all notifications have stopped firing before continuing.
  // Shared Notifications are dismissed withing a few seconds left only with task alert recap
  await page1.waitForLoadState("networkidle");
  await page1.getByText("SHARED TASK ALERT").first();
  //wait 20 seconds
  await page.waitForTimeout(20000);
  // wait for shared tasks to disappear
  await expect(page1.getByText("SHARED TASK ALERT").first()).toBeHidden();
  await page1.getByText('Dismiss', { exact: true }).click();
  await page1.getByRole('button', { name: 'Dismiss All' }).click();
  //Navigate to pin on map
  await page1.getByTitle('Map Search').getByRole('img').click();
  //TODO - select address from correct coverage excel sheet to be used by script.
  await page1.getByRole('search', { name: 'Search...' }).fill('Aberdour Street, London, SE1 4SG');
  await page1.getByText('26A ABERDOUR STREET LONDON').click();
  await page1.getByTitle('Map Search').getByRole('img').click();
  //introding wait so that map can load
  await page.waitForTimeout(5000);
  //Begin GeoFence interaction
  await page1.getByRole('button', { name: 'Geofences' }).click();
  await page1.getByRole('button', { name: 'Open Editor' }).click();
  //check existing geofence names
  //await page1.locator('.fence-list-group-item-container', {hasText:'PWTest3'});
  await page1.getByText('Create Geofence').click();
  await page1.getByRole('textbox', { name: 'characters maximum' }).click();
  //TODO - make GeoFence name random and non-repeatable
  await page1.getByRole('textbox', { name: 'characters maximum' }).fill('PWTest3');
  await page1.locator('#fenceDescription').click();
  await page1.locator('#fenceDescription').fill('test Geofence Creation');
  await page1.locator('.flex-col > div > #HxgnSelector > .hxgn-inner-select__control > .hxgn-inner-select__value-container').first().click();
  await page1.getByText('MPS', { exact: true }).click();
  await page1.getByText('Select...').first().click();
  await page1.getByText('MPS-AS', { exact: true }).click();
  await page1.getByRole('button', { name: 'Circle' }).click();
  //need to identify XY position on map to start interacting
  const map = page1.locator('.map-container');
  await map.click();
  await map.dragTo(map, {
    force: true,
    sourcePosition: {x: 550, y: 300},
    targetPosition: {x: 650, y: 500},
  });
  //complete shape
  await page1.getByRole('button', { name: 'Save Geofence' }).click();
  //if geofence already exists, it should present this;
  // page1.getByText('Duplicate geofence ID found. Enter a different geofence ID Ok');
  await expect(page1.locator('#geofence_20310').getByText('PWTest3')).toBeVisible();
});