const { test, expect, context } = require('@playwright/test');
const { PageObjects } = require('../../../pageobjects/PageObjects');

test.describe('CreateGeoFenceWithPO', () => {
  test('should create a geofence with PO', async ({ browser }) => {
  const browserContext = await browser.newContext();
  const page = await browserContext.newPage();
  const pages = new PageObjects(page);
  const { loginpage, Mappage, Geofencepage } = pages;


  console.log("==TEST GEOFENCE==");
  await loginpage.goTO();
  await loginpage.validLogin("AU2", "Ingr.112233", "10101/FCO1");
  await Mappage.awaitAlerts();
  await Mappage.MapSearchAddress('26A ABERDOUR STREET LONDON');
  await page.waitForTimeout(5000);
  //Begin GeoFence interaction
  await Geofencepage.CreateGeoFenceStart('PWTest5', 'test Geofence Creation');
  await Geofencepage.CreateCircleGeofence();
  await Geofencepage.SaveGeofence();
  //complete shape
  });
});