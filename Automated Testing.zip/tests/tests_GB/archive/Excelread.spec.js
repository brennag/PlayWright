// const ExcelJS = require('exceljs')
// const{test,expect} = require('@playwright/test')
// const {login} = require('../pageobjects/login')
// // ****print values of Excel ****
// async function ReadWriteExcel() 
// {
// const workbook = new ExcelJS.Workbook()
// await workbook.xlsx.readFile("D:/MyData/ExcelPlaywright.xlsx")
// {
//     const worksheet = workbook.getWorksheet('Sheet1')
//     // ********To Print Each value of the cell***************
//     // worksheet.eachRow((row,rowNumber) =>
//     // {
//     //     row.eachCell((cell,colNumber) =>
//     //     {
//     //         console.log(cell.value)
//     //     })
       
//     // })

//     const url = String(worksheet.getCell('A2').value);
//     const UserName = String(worksheet.getCell('B2').value);
//     const Password =String(worksheet.getCell('C2').value);

//     //Writing data into Excel
//     worksheet.getCell('D2').value = 'the new value';
//     await workbook.xlsx.writeFile("D:/MyData/ExcelPlaywright.xlsx")

//     return {url, UserName, Password};    
    
// }
// } 

// test('LoginDetails', async({browser}) =>
// {
//     const{url, UserName, Password} = await ReadWriteExcel();
//     console.log('userName',UserName, Password, url)
//     const context = await browser.newContext();
//     const page = await context.newPage();
//     const loginpage = new login(page);
//     await page.goto(url);
//     await loginpage.validLogin(UserName,Password)
// }
// )







