const { test, expect, context } = require('@playwright/test');
const { PageObjects } = require('../../pageobjects/PageObjects');
const { CreateContactPage } = require('../../pageobjects/CreateContact/CreateContactpage');

test('testAttach', async ({ browser }) => {
    const context = await browser.newContext();
    const page = await context.newPage();
    const pages = new PageObjects(page);
    const { loginpage, Contactformpage, CreateContactPageobj } = pages;

    console.log("==Test Attach file to incident==");
    await loginpage.goTO();
    await loginpage.validLogin("AU2", "Ingr.112233", "10101/FCO1");
    const Mappage = await loginpage.waitForNewPageAndCheckTitle();
    await page.locator("li[title='Create Contact'] ").click();
    const Contact_ID = await Contactformpage.createcontact("33 ABERCORN WAY LONDON SE1 5HR", "A01 - Anti Social Behaviour (ASB) - Personal", "AQ03 - Inconsiderate Behaviour - Squatting");
    await CreateContactPageobj.AttachFile("C:/PlayWright/Automated Testing/tests/tests_GB/starwars.txt", context);
    /*
    const attachments = page.getByTitle('Attachments', { exact: true });
    await attachments.click({ force: true, noWaitAfter: true });
    const addAttachment = page.getByRole('button', { name: 'Add Attachment' });
    const page0 = context.pages()[0];
    const [fileChooser] = await Promise.all([
        page0.waitForEvent('filechooser'),
        await addAttachment.click({ force: true, noWaitAfter: true }),
    ]);
    await fileChooser.setFiles('C:/PlayWright/Automated Testing/tests/tests_GB/starwars.txt');
    //const fileChooserPromise = page.waitForEvent('filechooser');
    ////const fileChooser = await fileChooserPromise;
    //not selecting folder or file when file chooser is opened
    const attachButton = page0.getByRole('button', { name: 'Attach', exact: true });
    await attachButton.click({ force: true, noWaitAfter: true });
    */
    console.log("==SCRIPT PASSED==");
});