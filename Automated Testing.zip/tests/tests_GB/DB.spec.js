const { test, expect } = require('@playwright/test');
const mysql = require('mysql2/promise');

test('Connect to database', async ({ page }) => {
    // Connect to the database
    const connection = await mysql.createConnection({
        host: 'metpsprd7777bzqaxfsjg.database.windows.net',
        user: 'local\\metpsDbOwner',
        password: 'D2jwwhleaoxw32x!',
        database: 'sqldb-metpsprddispatch'
    });

    // Query the database
    const [rows] = await connection.execute('select AU.UnitId from activeunit AU where AU.Status = 0', [1]);

    // Close the database connection
    await connection.end();
});