const { test, expect, context } = require('@playwright/test');
const { PageObjects } = require('../../pageobjects/PageObjects');
const { text } = require('stream/consumers');
const { ContactSearchComments } = require('../../pageobjects/CreateContact/ContactSearchComments');
const { log } = require('console');
const { login } = require('../../../pageobjects/General/login');
const {appendToLogFile} = require('../../testlogs');

test('CrC-016a', async ({ browser }) => {

    appendToLogFile(`\n=======================${__filename}==========================`)
    const context = await browser.newContext();
    const page = await context.newPage();
    const pages=new PageObjects(page);
    const{ContactSearchCommentspage,CommonUtilspage,loginpage,CreateContactPageobj,Contactformpage,AddCommentspage,IncidentBoardSearchpage,AssignResultCodepage,Alarmspage,ChangeRolepage,InvokeCommandpage}=pages;

    console.log("==CrC-016a Create Contact - Alarm Receiving Centre (answer call, Response not Required)==");
    await loginpage.goTO();
    await loginpage.validLogin("AU2","Ingr.112233","10101/FCO1");
    const Mappage = await loginpage.waitForNewPageAndCheckTitle();
    await ChangeRolepage.changerole("AS Operator (BCU - AS - Despatch Operator)","DespASE");
    await Contactformpage.SaveCallerDetails('Gary', '1992-07-25', 'Third Party', 'Non Emergency 101', '9273739', null, 'ARCH 280 COLDHARBOUR LANE LONDON SW9 8SE');
    const Contact_ID = await Contactformpage.createcontact("33 ABERCORN WAY LONDON SE1 5HR", "A01 - Anti Social Behaviour (ASB) - Personal", "AQ03 - Inconsiderate Behaviour - Squatting");
    await Contactformpage.PressSendOrCreate();
    await Alarmspage.addAlarm('E000427');
    await CommonUtilspage.SelectDropdownValue('(LBL_URN_ALARM_TYPE)','CA');
    await Alarmspage.AMSDialogSubmit_button.click();
    console.log('Alam URN selected and applied to incident');
    await AddCommentspage.addcomments('Response is not needed as it is a dummy call');
    await ContactSearchCommentspage.searchComments('Response is not needed as it is a dummy call');
    console.log('comment added to incident');
    await CreateContactPageobj.PressUpdateIncButton();
    //TODO include verification that Contact Information form updates with the correct details for the URN - CURRENTLY FAILING IN THE APP
    await IncidentBoardSearchpage.incidentboardsearch(Contact_ID);
    // TODO - Need to check that incident exists in unassigned column - Awaiting improvedment to PO
    await InvokeCommandpage.invokecommand(`ASSIGN RESULT CODES -e ${Contact_ID}`);
    await CommonUtilspage.SelectARCDropdownValue("(LBL__AssignResultCode_ResultCode)",'P02 - Alarm - Central Station');
    await CommonUtilspage.SelectARCDropdownValue("(LBL__AssignResultCode_ResultClassification)",'No crime - No offences');
    await CommonUtilspage.SelectARCDropdownValue("(LBL__AssignResultCode_Qualifier)",'204 - Inconsiderate Behaviour - Squatting');
    await CommonUtilspage.SelectARCDropdownValue("(LBL__AssignResultCode_Resolution)",'505 - Cancel\/Error');
    await AssignResultCodepage.ARCTag_button("Supervisor - Ready to Close").click();
    await AssignResultCodepage.submit_button.click();
    console.log('Result Code Assigned to Incident');
    await ChangeRolepage.changerole("AS Supervisor (BCU - AS - Despatch Enhanced)","SupASE");
    await CommonUtilspage.SwitchingTabs('Incidents').click();
    await CommonUtilspage.SwitchingTabButton('ASE Ready to Close').click();
    await IncidentBoardSearchpage.incidentboardsearch(Contact_ID);
    //TODO search for incident and ensure it is in the awaiting review queue - Awaiting improvedment to PO
    await InvokeCommandpage.invokecommand(`CLOSE -e ${Contact_ID}`);
    // Ensure Incident is closed.
    await expect(IncidentBoardSearchpage.incidentboardsearch(Contact_ID)).toBeFalsy();
    console.log('Incident Closed');
    console.log("==SCRIPT PASSED==");
});