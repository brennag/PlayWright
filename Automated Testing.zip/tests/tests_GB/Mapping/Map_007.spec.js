const { test, expect } = require('@playwright/test');
const { PageObjects } = require('../../../pageobjects/PageObjects');
const { text } = require('stream/consumers');
const exp = require('constants');
const { map } = require('mssql');
const { log } = require('console');
const { login } = require('../../../pageobjects/General/login');
const { MapLayers } = require('../../../pageobjects/Map/Layers');
const{appendToLogFile}=require('../../testlogs');




test('Map_007', async ({ browser }) => {

    appendToLogFile(`\n=======================${__filename}==========================`)
    const context = await browser.newContext();
    const page = await context.newPage();
    const pages = new PageObjects(page);
    const loginpage = pages.loginpage;
    const CommonUtilspage = pages.CommonUtilspage;
    const ChangeRole = pages.ChangeRolepage;
    console.log("==MAP_ 007- User can view the point data as MapPins correctly==");
    await loginpage.goTO();
    await loginpage.validLogin("AU2", "Ingr.112233", "10101/FCO1");
    await loginpage.waitForNewPageAndCheckTitle();
    await CommonUtilspage.SwitchToMapPage(page);
    const page1 = context.pages()[1];
    const Mappage = new PageObjects(page1).Mappage;
    const MapLayersPage = new MapLayers(page1);
    await Mappage.awaitAlerts();
    await page1.waitForTimeout(2000);
    await MapLayersPage.switchLayer("Overlay Layers", "Points of Interest", "Police Stations", "On");
    await Mappage.MapSearchPin("RICHMOND PARK POLICE OFFICE");
    await Mappage.verifyPoliceStationIcon("RICHMOND PARK POLICE OFFICE");
    await MapLayersPage.switchLayer("Overlay Layers", "Points of Interest", "Police Stations", "Off");
    await MapLayersPage.switchLayer("Overlay Layers", "CCTV", "CCTV", "On");
    await Mappage.MapSearchAddress("prebend street/coleman fields");
    await Mappage.verifyCCTVIcon("CCTV");
    await MapLayersPage.switchLayer("Overlay Layers", "CCTV", "CCTV", "Off");
    console.log("Script completed successfully");
});