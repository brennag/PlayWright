const { test, expect } = require('@playwright/test');
const { PageObjects } = require('../../../pageobjects/PageObjects');
const { text } = require('stream/consumers');
const exp = require('constants');
const { map } = require('mssql');
const { log } = require('console');
const { login } = require('../../../pageobjects/General/login');
const{appendToLogFile}=require('../../testlogs');



test('Map_004', async ({ browser }) => {

    appendToLogFile(`\n=======================${__filename}==========================`)
    const context = await browser.newContext();
    const page = await context.newPage();
    const pages = new PageObjects(page);
    const loginpage = pages.loginpage;
    //const CommonUtilspage = pages.CommonUtilspage;
    console.log("==MAP_ 004 - User will be able to search for locations with various attributes==");
    await loginpage.goTO();
    await loginpage.validLogin("AU2", "Ingr.112233", "10101/FCO1");
    await loginpage.waitForNewPageAndCheckTitle();
    //await ChangeRole.changerole("AS Operator (BCU - AS - Despatch Operator)", "DespASE");
    const Contactformpage = pages.Contactformpage;
    const address = "EXCLUDING PART GROUND FLOOR 47 BERMONDSEY STREET LONDON SE1 3XT";
    const postcode = "SE1 3XT";
    //let randomPostcode = await Mappage.GetRandomPostcode('../../testdata/', 'LondonPostCodesInnerLondonSouthEast.csv');
    await Contactformpage.createcontact(address, "A01 - Anti Social Behaviour (ASB) - Personal", "AQ01 - Inconsiderate Behaviour - Illegal Encampments");
    console.log("Address Set");
    await Contactformpage.sendtodespatch.click();
    await Contactformpage.ChangeContactAddress(postcode);
    console.log("PostCode Set and searched");
    await page.mouse.move(1189, 428);
    await Contactformpage.map_container.click({ button: "right" });
    await page.locator(`//a[normalize-space()='Copy Coordinates to Clipboard']`).click();
    let LL = await Contactformpage.ll_text.innerText();
    let EN = await Contactformpage.en_text.innerText();
    await Contactformpage.ChangeContactAddress(LL);
    console.log("Longitude and Latitude Set and searched");
    await page.waitForTimeout(2000);
    await Contactformpage.ChangeContactAddress(EN);
    console.log("Eastings Northings Set and searched");
    await page.waitForTimeout(2000);
    console.log("Script completed successfully."); 
});