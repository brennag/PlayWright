const { test, expect } = require('@playwright/test');
const { PageObjects } = require('../../../pageobjects/PageObjects');
const { text } = require('stream/consumers');
const exp = require('constants');
const { map } = require('mssql');
const { log } = require('console');
const { login } = require('../../../pageobjects/General/login');
const{appendToLogFile}=require('../../testlogs');



test('Map_003', async ({ browser }) => {

    appendToLogFile(`\n=======================${__filename}==========================`)
    const context = await browser.newContext();
    const page = await context.newPage();
    const pages = new PageObjects(page);
    const loginpage = pages.loginpage;
    const CommonUtilspage = pages.CommonUtilspage;
    const ChangeRole = pages.ChangeRolepage;
    const Contactformpage = pages.Contactformpage;
    console.log("==MAP_ 003 - User verifies the caller location is linked to nearby incident and displays multiple caller location on the Map==");
    await loginpage.goTO();
    await loginpage.validLogin("AU2", "Ingr.112233", "10101/FCO1");
    await loginpage.waitForNewPageAndCheckTitle();
    await ChangeRole.changerole("AS Operator (BCU - AS - Despatch Operator)", "DespASE");
    const page1 = context.pages()[1];
    const Mappage = new PageObjects(page1).Mappage;
    const CreateIncidentMapPage = new PageObjects(page1).CreateIncidentMappage;
    //const randomPostcode = "SE1 5HR";
    //const randomPostcode2 = "SE1 7ET";
    let randomPostcode = await Mappage.GetRandomPostcode('../../testdata/', 'LondonPostCodesInnerLondonSouthEast.csv', "AS");
    let randomPostcode2 = await Mappage.GetRandomPostcode('../../testdata/', 'LondonPostCodesInnerLondonSouthEast.csv', "AS");
    const Contact_ID = await Contactformpage.createcontact(randomPostcode2, "A01 - Anti Social Behaviour (ASB) - Personal", "AQ01 - Inconsiderate Behaviour - Illegal Encampments");
    await Contactformpage.SaveCallerDetails('Bob', '2008-07-01', 'Third Party', 'Non Emergency 101', '9273739', null, randomPostcode);
    await Contactformpage.sendtodespatch.click()

    await page.waitForTimeout(2000)
    await CommonUtilspage.SwitchToMapPage(page);
    await Mappage.dismissSharedTasks_button.click();
    await Mappage.dismissAllTasks_button.click();
    /*
    if (Mappage.mapShowAllUnitsAndIncidents_button.isVisible()){
        Mappage.mapShowAllUnitsAndIncidents_button.click();
    }
    else{
        console.log("Incidents all shown")
    }
        */
    await page1.waitForTimeout(5000);
    await Mappage.MapSearchIncident(Contact_ID);
    const incidentIcon = page1.locator(`//div[@id=${Contact_ID}]//img[@class='icon-image-small']`);
    //Failing here
    await incidentIcon.click({ button: 'right' });
    //alternatively right click incident icon, select incident panel
    await Mappage.mapIncidentSelect_icon.click();
    const callerInfo = page1.locator(`//div[@id='EVENT_PANEL_CALLER_INFO']`);
    await callerInfo.click();
    const callerLocation = page1.locator(`//div[@title='View on Map']`);
    await callerLocation.click();
    const callerLocationPin = page1.locator(`//img[@src='https://metps-dispatch.hexagonsi.com/oncall/Images/MapIcons/pin/map_pin_phone.png']`);
    await callerLocationPin.isVisible();
    console.log("Script completed successfully");
});