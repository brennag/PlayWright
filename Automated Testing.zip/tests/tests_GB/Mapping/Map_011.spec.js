const { test, expect } = require('@playwright/test');
const { PageObjects } = require('../../../pageobjects/PageObjects');
const { text } = require('stream/consumers');
const exp = require('constants');
const { map } = require('mssql');
const { log } = require('console');
const { login } = require('../../../pageobjects/General/login');
const { MapLayers } = require('../../../pageobjects/Map/Layers');
const{appendToLogFile}=require('../../testlogs');




test('Map_011', async ({ browser }) => {

    appendToLogFile(`\n=======================${__filename}==========================`)
    const context = await browser.newContext();
    const page = await context.newPage();
    const pages = new PageObjects(page);
    const loginpage = pages.loginpage;
    const CommonUtilspage = pages.CommonUtilspage;
    const ChangeRole = pages.ChangeRolepage;
    console.log("==MAP_ 011 - User can view London Boroughs on the map==");
    await loginpage.goTO();
    await loginpage.validLogin("AU2", "Ingr.112233", "10101/FCO1");
    await loginpage.waitForNewPageAndCheckTitle();
    await CommonUtilspage.SwitchToMapPage(page);
    const page1 = context.pages()[1];
    const Mappage = new PageObjects(page1).Mappage;
    const MapLayersPage = new MapLayers(page1);
    await Mappage.awaitAlerts();
    await page1.waitForTimeout(2000);
    await MapLayersPage.SetLayerOpacityLevel("Overlay Layers", "Special Situations", "Special Situations", "On", "0");
    await page1.waitForTimeout(2000);
    await MapLayersPage.SetLayerOpacityLevel("Overlay Layers", "Special Situations", "Special Situations", "On", "100");
    await page1.waitForTimeout(2000);
    await MapLayersPage.switchLayer("Overlay Layers", "Special Situations", "Special Situations", "Off");
    console.log("Script completed successfully");
});