import {test, expect} from '@playwright/test';

test('Upload a File', async({page}) =>{
    await page.goto('URL');
    const uploadInput = page.locator('input[type="file"]');

    await uploadInput.setInputFiles('download/dummyfile.pdf');
    // for multiple files use (['file1', 'file2', 'file3'])

});