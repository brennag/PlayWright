// @ts-check
import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  testDir: './tests',
  timeout: 50 * 60 * 1000,
  expect: {

    timeout: 100000
  }, 
  fullyParallel: false,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 0 : 0,
  workers: 1 ,
  reporter: 'html',

  projects: [
    {
      name: 'chromium',
      use: 
      {
        viewport: null,
        headless: false,
        screenshot: 'only-on-failure',
        browserName : 'chromium',
        launchOptions: {
          args:["--start-maximized"],
          slowMo: 1000 }
       },      
    },

  ],

});
