const{InvokeCommand}= require('../General/InvokeCommand')
const{DialogOpen}=require('../General/DialogOpen')
const { expect} = require ('@playwright/test');
const{appendToLogFile}=require('../../tests/testlogs')
class CloseContact{
    constructor(page){
        this.page=page;
        this.contactselect =page.locator("div[name='(LBL_CANCELEVENT_EVENTID)']")
        this.remark =page.locator("input[name='(LBL_CANCELEVENT_RMRK)']")
        this.resolution =page.locator("div[name='(LBL_CANCELEVENT_QUAL2)'] input").first()
        this.resolutiondropdown =page.locator("//div[@class='dialog-body flex-col']//span[@class='k-select']")
        this.dialogtitle = page.locator(".dialog-header.flex-row.flex-justify-space-between.ng-scope span")
        this.submitbutton =page.locator(`//div[@class='dialog-body flex-col']//button[contains(@class,'btn btn-primary submit-btn')]`)

    }

    async closecontact(Contact_ID,Remark,Resolution)
    {
        const DialogOpenPage = new DialogOpen(this.page)
        await DialogOpenPage.DialogOpen('Close Contact',`CLOSE -e ${Contact_ID}`)
        // const DialogName ='Close Contact'
        // const validdialog = await DialogOpenPage.DialogOpen(DialogName)
        
        // if(validdialog==0){
        //     console.log(`${DialogName} dialog already exists`)
        // }
        // else
        // {
        //     const Invokecommandpage =new InvokeCommand(this.page);
        //     await Invokecommandpage.invokecommand(`CLOSE -e ${Contact_ID}`)
        // }
        await expect(this.dialogtitle).toContainText("Close Contact")
        await expect(this.contactselect).toContainText(Contact_ID)
        await this.remark.fill(Remark)
        await this.resolutiondropdown.click()
        await this.page.locator(`//li[starts-with(text(),'${Resolution}')]`).click()
        await this.submitbutton.click()
        // await this.resolution.fill(Resolution)
        // await this.page.keyboard.press("Enter")
        // await page.locator("//*[contains(@class,'btn btn-primary submit-btn')]").first().click()
        await expect(this.dialogtitle).toBeHidden() //checking whether close contact dialog closed
        appendToLogFile(`Pass:contact ${Contact_ID} closed successfully`)

    }
}

module.exports={CloseContact}