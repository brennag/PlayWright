//This class is to have all the locators from create contact page 

class CreateContactPage{
    constructor(page)
    {
        this.page=page;
        this.CreateContactTab=page.locator("//span[normalize-space()='Create Contact']")
        this.AttendanceLocation =page.locator("[ID='LOCATION-INPUT-FIELD'] input").first()
        this.IncidentLocation = page.locator("[ID='LOCATION-INPUT-FIELD'] input").nth(1)
        this.locationsearch =page.locator(".location-result")
        this.IncidentType=page.locator("angwrap-dialog-event-type-selector[name='(LBL_CALLTAKER_TYPE_SELECT)'] input").first()
        this.IncidentSubType=page.locator("angwrap-dialog-event-subtype-selector[name='(LBL_CALLTAKER_SUBTYPE_SELECT)'] input")
        this.Additionalinfo=page.locator("input[name='(LBL_CALLTAKER_additional_info)']")
        this.Incidenttitle =page.locator("input[name='(LBL_CALLTAKER_incident_title)']")
        this.SMFSelector=page.locator("button[title='SMF Selector']")
        this.CrimeAllegation=page.locator("button[title='Crime Allegation']")
        this.MissingPerson=page.locator("button[title='Missing Person']")
        this.HoaxCall=page.locator("button[title='Hoax Call']")
        this.SilentCall=page.locator("button[title='Silent Call']")
        this.AddRemark=page.locator("button[title='Add Remark']")
        this.RunThrive=page.locator("button[title='Run THRIVE+ assessment']")
        this.AMSURNSearch =page.locator("button[title='AMS URN Search']")
        this.CallerName =page.locator("input[name='(lbl_calltaker_caller_name)']")
        this.CallerDOB = page.locator("input[name='(lbl_calltaker_dob)']")
        this.CallerAnonymous = page.locator("dialog-pick-list[name='(lbl_calltaker_caller_anonymous)'] input")
        this.CallerSource = page.locator("dialog-pick-list[name='(lbl_calltaker_caller_source)'] input")
        this.CallerType =page.locator("dialog-pick-list[name='(lbl_calltaker_caller_type)'] input")
        this.CallerMobileNum=page.locator("input[name='(lbl_calltaker_caller_mobile_num)']")
        this.CallerWorkNum=page.locator("input[name='(lbl_calltaker_caller_work_num)']")
        this.CallerHomeNum =page.locator("input[name='(lbl_calltaker_caller_home_num)']")
        this.CallerOtherNum=page.locator("input[name='(lbl_calltaker_caller_other_num)']")
        this.CallerSocialMedia =page.locator("input[name='(lbl_calltaker_caller_sm_handle)']")
        this.CallerEmail=page.locator("input[name='(lbl_calltaker_caller_email)']")
        this.CallerPreferredContactdropdown=page.locator("dialog-pick-list[name='(lbl_calltaker_preferred_contact_method)'] svg")
        this.CallerAutomaticContactMethoddropdown =page.locator("dialog-pick-list[name='(lbl_calltaker_automatic_contact_method)'] svg")
        this.Callerloc = page.locator("angwrap-dialog-location[name='(lbl_calltaker_caller_location)'] input")
        this.CallerAddress = page.locator("angwrap-dialog-location[name='(lbl_calltaker_caller_address)'] input")
        this.cl_location_search = page.locator("#dialog-location-results")
        this.SaveCaller= page.locator("//button[normalize-space()='Save Caller']")
        this.CopyCallertoSuppinfo =page.locator("button[title='Copy Caller to Supp Info Person']")
        this.LocateMobile=page.locator("button[title='Locate Mobile']")
        this.EmailCaller=page.locator("button[title='Email Caller']")
        this.SMSCaller=page.locator("button[title='SMS']")
        this.CallPhoneNumber=page.locator("button[title='Call Phone Number']")
        this.Closebutton=page.locator("dialog-run-script-button[name='(Close_Dialog)'] button")
        this.IncidentRouting =page.locator("button[title='Incident Routing']")
        this.CreateContactBtn=page.locator("button[name='create-evt-btn']")
        this.sendtodespatch =page.locator("//button[normalize-space()='Send to Despatch']")
        this.ContactForm =page.locator("#CALLTAKER_2_EVENT_FORM")
        this.Comments =page.locator("#COMMAND_DIALOG_COMMENTS")
        //this.commenttext =page.locator(".remark-metadata")
        this.commenttext =page.locator("//span[contains(@class,'remark-text')]")
        this.commentstextbox = page.locator("//*[contains(@class,'divRemarkInputField')]")
        this.ClearFormWarning= page.locator(`//*[text()='Are you sure you want to clear the form?']`)
        this.attachments =page.locator("#COMMAND_DIALOG_ATTACHMENTS")
        this.suppinfo =page.locator("#EVENT_PANEL_SUPP_INFO")
        this.tags=page.locator("#EVENT_PANEL_TAGS")
        this.AssignedUnits =page.locator("#ASSIGNED_UNITS")
        this.RecommendedUnits =page.locator("#EVENT_PANEL_RECOMMEND_UNITS")
        this.SOPs=page.locator("#WEB_SOPS_TITLE")
        this.Locationinformation=page.locator("#EVENT_PANEL_LOI")
        this.RVPs=page.locator("#EVENT_PANEL_STAGING_AREAS")
        this.ClearFormBtn =page.locator("#clearForm")
        this.priority = page.locator("//td[@class='font-pr']")
        this.Clearformpopupclearbutton=page.locator("//div[contains(@class,'dispatch-confirm-dialog')]//span[text()='Clear']")
        this.Clearformpopupcancelbutton=page.locator("//div[contains(@class,'dispatch-confirm-dialog')]//span[text()='Cancel']")
        this.Clearformpopupstackbutton = page.locator("//div[contains(@class,'dispatch-confirm-dialog')]//span[text()='Stack']")
        this.AttachmentsSection = page.getByTitle('Attachments', { exact: true })
        this.AddAttachmentButton = page.getByRole('button', { name: 'Add Attachment' })
        this.verifyAddress_button = page.locator("//angwrap-dialog-location[@name='(LBL_CALLTAKER_ATTENDANCE_LOCATION)']//button[@id='verifyButton']")
        this.acceptVerifyAddress_button = page.locator("//button[normalize-space()='Accept']").nth(1);
        this.map_container = page.locator(`//div[contains(@class,'map-container flex-grow')]`)
        this.mapToolSearch_icon = page.getByTitle('Map Search').getByRole('img')
        this.mapSearch_textbox = page.getByRole('search', { name: 'Search...' })
        this.locationSearchResult_textbox = page.locator("//*[contains(@class,'result-address-row')]")
        this.ll_text = page.locator(`//input[@class='form-control cd-tabbable ng-pristine ng-valid ng-not-empty ng-valid-required ng-touched']`).nth(0);
        this.en_text = page.locator(`//input[@class='form-control cd-tabbable ng-pristine ng-valid ng-not-empty ng-valid-required ng-touched']`).nth(1);
        



    }
    async ValidateTitleofPage()
    {
        await this.CreateContactTab.click()
       const title = await this.page.title()
       console.log(title)
    }


}
module.exports ={CreateContactPage}