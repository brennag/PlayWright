const{expect} = require('@playwright/test')
const {appendToLogFile } = require('../../tests/testlogs');
class RecentlistContactSearch{
    constructor(page){
        this.page=page;
        this.tab = page.locator("div[title='Recent List']")
        this.searchbar =page.locator("input[placeholder='Search Incidents...']")
        this.searchresult = page.locator("//*[@class='results-title']")
    }
    
    async recentlistcontactsearch(Incident_ID)
    {
        await this.tab.click()
        await this.searchbar.fill(Incident_ID)
        await this.page.waitForTimeout(3000)
        const incidentsearch =await this.searchresult.textContent()
        if(incidentsearch.includes(`Showing 1 results for "${Incident_ID}"`))
        {
            appendToLogFile(`Pass: contact:${Incident_ID} appears on Recent list`)
            return true
        }
        else if(incidentsearch.includes(`Showing 0 results for "${Incident_ID}"`))
        {
            appendToLogFile(`Fail: contact:${Incident_ID} NOT Displayed in Recent list`)
            return false
        }
        

    }
}
module.exports ={RecentlistContactSearch}