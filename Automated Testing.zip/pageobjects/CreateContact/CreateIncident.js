class CreateIncident{

    constructor(page)
    {

        this.page=page;
        this.CommandLine =page.locator("[title='Command Line']");
        this.InputCommand =page.getByPlaceholder('Command Line...');
        this.AttendanceLocation =page.locator("[ID='LOCATION-INPUT-FIELD'] input").first()
        this.IncidentLocation = page.locator("[ID='LOCATION-INPUT-FIELD'] input").nth(1)
        this.locationsearch =page.locator(".location-result")
        this.CallerName= page.locator("[name='(LBL_Caller_Name)']");
        this.IncidentType =page.locator("angwrap-dialog-event-type-selector[name='(LBL_Incident_Type)'] input").first();
        this.SubmitBtn = page.locator(".btn.btn-primary.submit-btn.cd-tabbable.ng-binding")

    }


    async CreateInc()
    {
        await this.CommandLine.click();
        await this.InputCommand.fill('Create Incident');
        await this.page.keyboard.press('Enter')
        await this.AttendanceLocation.fill('FLAT 6 9 RYE HILL PARK LONDON SE15 3JN');
        await this.locationsearch.click();
        await this.IncidentLocation.fill('FLAT 6 9 RYE HILL PARK LONDON SE15 3JN');
        await this.locationsearch.click();
        await this.CallerName.fill("Michael");
        await this.IncidentType.fill("Violence")
        await this.page.waitForTimeout(2000);
        await this.page.keyboard.press("Enter");
        await this.SubmitBtn.click();
        
    }

}
module.exports={CreateIncident};
