class RecentlistContactContextMenu{
    constructor(page)
    {
        this.page =page;
        this.eventdetailspanel = page.locator("//div[contains(@class,'EventItem_eventDetailsPanel')]").first()
        this.incident =this.eventdetailspanel.locator("//span[starts-with(text(),'MPS')]")
        this.menubutton =page.locator("//button[contains(@class,'VerticalEllipsisButton')]").first()
        
    }

    async recentlistContactContextMenu(Incident_ID,menuoption)
    {
        await this.page.locator(`//div[@data-id='${Incident_ID}']//button[contains(@class,'VerticalEllipsisButton')]`).click()
        await this.page.waitForTimeout(1000)
        await this.page.getByRole('listitem', { name: menuoption }).click();
        console.log(`Pass: ${menuoption} selected from Context Menu  for incident :${Incident_ID}`)

        return Incident_ID
    }
}
module.exports={RecentlistContactContextMenu}