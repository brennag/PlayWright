const{appendToLogFile}=require('../../tests/testlogs')
class ContactformSOPSearch{
    constructor(page){
        this.page=page;
        this.SOPsIcon =page.locator("#WEB_SOPS_TITLE")
        this.SOPname =page.locator(".sop-tab-row-content.flex-align-center h4")

    }

    async ContactformSOPSearch(SOP_to_Search)
    {
        await this.SOPsIcon.click()
        if(SOP_to_Search==null)
        {
            appendToLogFile("Fail:Please provide an SOP to Search")
        }
        else
        {
            let elements=await this.page.$$(`//div[@class='sop-tab-row-content flex-align-center']//h4`)
            let AllSOPs=[]
            let sop;
            for(let element of elements){
                sop= await element.textContent()
                AllSOPs.push(sop)
            }
            // console.log(AllSOPs)
            
            // const SOPname =await this.SOPname.textContent()
            if(AllSOPs.includes(SOP_to_Search))
            {
                appendToLogFile(`Pass: SOP searched : '${SOP_to_Search}' is available in contact form`)
            }
            else
            {
                appendToLogFile(`Fail: SOP searched : '${SOP_to_Search}' is NOT available in contact form`)
            }
        
        }
    }
}
module.exports ={ContactformSOPSearch}