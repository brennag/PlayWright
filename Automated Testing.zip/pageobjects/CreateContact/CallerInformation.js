const {CreateContactPage}=require('./CreateContactpage')

class callerinformation extends CreateContactPage {
    constructor(page)
    {
        super(page)// to invoke parent class constructor
    }

    async SaveCallerdetails()
    {
        await this.CallerName.fill('steven')
        await this.CallerMobileNum.fill('08333444')
        await super.ValidateTitleofPage()
    }
}
module.exports ={callerinformation}