class SOPExecution{
    constructor(page){
        this.page=page;
        this.SOPbutton = page.locator("#WEB_SOPS_TITLE")
        this.toggle = page.locator("//div[contains(@class,'event-panel-sops')] //div[contains(@class,'inner-slider')]")
        this.tasktitle = ".sop-workflow-card-header-title"
        this.Acceptbutton =  page.locator(".accept-task-btn").first()
        this.expandbutton =page.locator("//button[@title='Expand' and @class='expander ']")
        this.TaskNotes =page.locator("textarea").first()
        this.Desicion_Yes =page.locator("//label[normalize-space()='Yes']")
        this.closetask =page.locator("//button[normalize-space()='Close Task']")
        this.taskprogress = page.locator("div[class='progress-ribbon'] progress").first()
    }

    async SOPExecution(SOPname)
    {
        await this.SOPbutton.click()
        if(SOPname){
            await this.page.locator(`//div[@class='sop-tab-row-content flex-align-center']//h4[text()='${SOPname}']`).click()
        }
        await this.toggle.click()

        const elements= await this.page.$$(this.tasktitle)

        if (elements.length === 0) {
            console.log("No Tasks found.");
        }  
        
        const All_Tasks =[];
        for(let element of elements){
            const task =await element.textContent()
            await All_Tasks.push(task)
        }

        console.log(All_Tasks)
        let taskprogressvalue;

        for(let task of All_Tasks)
        {
            let i =0;

            if(await this.Acceptbutton.isEnabled()){
                await this.Acceptbutton.click()
            }
            
            await this.expandbutton.nth(i)
            await this.TaskNotes.fill(`closing task ${task}`)
            if(task=='Decision Task'){
                await this.Desicion_Yes.click()
            }
            await this.closetask.click()
            console.log(`task: ${task} closed`)
            i++;
            await this.page.waitForTimeout(1000)
            taskprogressvalue = await this.taskprogress.getAttribute("value")
            console.log(`Task progress: ${taskprogressvalue}`)
        }
        return taskprogressvalue;

                
    }
}
module.exports ={SOPExecution}