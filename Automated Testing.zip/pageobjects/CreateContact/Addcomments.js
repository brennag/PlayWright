const{CreateContactPage}=require('./CreateContactpage')
const{appendToLogFile}=require('../../tests/testlogs')

class AddComments extends CreateContactPage{
    constructor(page)
    {
        super(page)

    }
    async addcomments(comments)
    {
        await this.Comments.click()
        await this.commentstextbox.last().fill(comments)
        await this.page.keyboard.press("Enter")
        await this.page.waitForTimeout(2000)
        appendToLogFile(`Pass:comments:${comments} added successfully`)
    }
}
module.exports ={AddComments}