const { error } = require("console");
const { test, expect } = require('@playwright/test')
const { CreateContactPage } = require('./CreateContactpage')
const { appendToLogFile } = require('../../tests/testlogs');
const { CommonUtils } = require(`../CommonUtils`)
const { DatabaseValidations } = require('../General/DatabaseValidations')

class Contactform extends CreateContactPage {
    constructor(page) {
        super(page)
        this.Commonutilspage = new CommonUtils(page)
        this.DatabaseValidationspage = new DatabaseValidations(page)
    }

    async ClearForm() {
        await this.ClearFormBtn.click();
        //await this.ClearForm.click()
        await this.page.waitForTimeout(2000)
        if (await this.ClearFormWarning.isVisible()) {
            await this.Clearformpopupclearbutton.click()
        }
        await this.page.waitForTimeout(2000)
    }
    async CreateInc(IncidentLocation, IncidentType, IncidentSubType) {
        await this.CreateContactTab.click();
        /*await this.ClearForm.click();
        await this.page.waitForTimeout(2000)
        if(await this.ClearFormWarning.isVisible())
        {
            await this.Clearformpopupclearbutton.click()
        }
        await this.page.waitForTimeout(5000);*/
        if (IncidentLocation) {
            await this.AttendanceLocation.fill(IncidentLocation);
            await this.locationsearch.first().click();
            await this.page.waitForTimeout(5000)
            const Attlocationverified = await this.page.locator("svg[data-icon='check-circle']").first().isVisible()//verifying the location

            if (!Attlocationverified) {
                console.log("Fail: Attendance location not verified")
            }
        }
        else {
            console.log("Incident location not provided.")
        }
        if (IncidentType) {
            await this.IncidentType.fill(IncidentType);
            await this.page.waitForTimeout(2000);
            await this.page.keyboard.press("Enter");
        }
        else {
            console.log("Incident type not provided")
        }
        if (IncidentSubType) {
            await this.IncidentSubType.fill(IncidentSubType)
            await this.page.waitForTimeout(2000);
            await this.page.keyboard.press("Enter");
        }
        else {
            console.log("Incident Sub-type not privided")
        }

        await this.sendtodespatch.click()
        await this.page.waitForTimeout(2000)
        const Incident_Info = await this.page.locator(".ct-event-header span").first().textContent()
        const Incident_ID = Incident_Info.slice(22)
        appendToLogFile(`Pass: Incident Created Successfully. Id: ${Incident_ID}`)//logging Incident Id

        //Database validation
        let [DB_location, DB_Incident_ID, DB_Incident_type, DB_IncidentSubtype] = await this.DatabaseValidationspage.IncidentvalidationDB(Incident_ID)
        if (IncidentLocation) {
            if (DB_location.includes(IncidentLocation)) { console.log(`Pass:Incident location matched in the DB`) }
            else { console.log(`Fail:Incident location Not Matched in the DB`) }
        }
        if (!IncidentLocation) {
            if (DB_location.includes('NOLOC')) { console.log(`Pass:Incident location matched in the DB`) }
            else { console.log(`Fail:Incident location Not Matched in the DB`) }
        }
        if (DB_Incident_ID == Incident_ID) { console.log(`Pass: Incident id Matched in the DB`) }
        else { console.log(`Fail: Incident id NOT Matched in the DB`) }
        if (IncidentType) {
            if (DB_Incident_type.includes(IncidentType)) { console.log(`Pass:Incident type matched in the DB`) }
            else { console.log(`Fail:Incident type NOT matched in the DB`) }
            if (DB_IncidentSubtype.includes(IncidentSubType)) { console.log(`Pass:Incident Subtype matched in the DB`) }
            else { console.log(`Fail:Incident subtype NOT matched in the DB`) }
        }
        if (!IncidentType) {
            if (DB_Incident_type.includes(`00 - Unclassified Contact`)) { console.log(`Pass:Incident type matched in the DB`) }
            else { console.log(`Fail:Incident type NOT matched in the DB`) }
            if (DB_IncidentSubtype.includes(`00 - Contact Record`)) { console.log(`Pass:Incident Subtype matched in the DB`) }
            else { console.log(`Fail:Incident subtype NOT matched in the DB`) }
        }

        return Incident_ID
    }

    //Create Contact Method
    async createcontact(IncidentLocation, IncidentType, IncidentSubType) {
        await this.CreateContactTab.click();
        /*await this.ClearForm.click();
        await this.page.waitForTimeout(2000)
        if(await this.ClearFormWarning.isVisible())
        {
            await this.Clearformpopupclearbutton.click()
        }
        await this.page.waitForTimeout(2000)*/
        if (IncidentLocation) {
            await this.AttendanceLocation.fill(IncidentLocation);
            await this.locationsearch.first().click();
            await this.page.waitForTimeout(5000)
            const Attlocationverified = await this.page.locator("svg[data-icon='check-circle']").first().isVisible()//verifying the location

            if (!Attlocationverified) {
                console.log("Fail : Attendance location not verified")
            } else {
                console.log('Pass:Attendance location verified ')
            }
        }
        else {
            console.log("Incident location not provided.")
        }
        if (IncidentType) {
            await this.IncidentType.fill(IncidentType);
            await this.page.waitForTimeout(2000);
            await this.page.keyboard.press("Enter");
        }
        else {
            console.log("Incident type not provided.")
        }
        if (IncidentSubType) {
            await this.IncidentSubType.fill(IncidentSubType)
            await this.page.waitForTimeout(2000);
            await this.page.keyboard.press("Enter");
        }
        else {
            console.log("Incident Sub Type Not Provided.")
        }
        // Click on create contact button
        await this.CreateContactBtn.click();
        await this.page.waitForTimeout(5000)
        const Contact_Info = await this.page.locator(".ct-event-header span").first().textContent()
        const Contact_ID = Contact_Info.slice(21)
        appendToLogFile(`Pass Contact Created Successfully. ID: ${Contact_ID}`)//logging Contact Id
        //Database validation
        let [DB_location, DB_Incident_ID, DB_Incident_type, DB_IncidentSubtype] = await this.DatabaseValidationspage.IncidentvalidationDB(Contact_ID)
        if (IncidentLocation) {
            if (DB_location.includes(IncidentLocation)) { console.log(`Pass:Incident location matched in the DB`) }
            else { console.log(`Fail:Incident location Not Matched in the DB`) }
        }
        if (!IncidentLocation) {
            if (DB_location.includes('NOLOCL')) { console.log(`Pass:Incident location matched in the DB`) }
            else { console.log(`Fail:Incident location Not Matched in the DB`) }
        }
        if (DB_Incident_ID == Contact_ID) { console.log(`Pass: Contact id Matched in the DB`) }
        else { console.log(`Fail: Contact id NOT Matched in the DB`) }
        if (IncidentType) {
            if (DB_Incident_type.includes(IncidentType)) { console.log(`Pass:Incident type matched in the DB`) }
            else { console.log(`Fail:Incident type NOT matched in the DB`) }
            if (DB_IncidentSubtype.includes(IncidentSubType)) { console.log(`Pass:Incident Subtype matched in the DB`) }
            else { console.log(`Fail:Incident subtype NOT matched in the DB`) }
        }
        if (!IncidentType) {
            if (DB_Incident_type.includes(`00 - Unclassified Contact`)) { console.log(`Pass:Incident type matched in the DB`) }
            else { console.log(`Fail:Incident type NOT matched in the DB`) }
            if (DB_IncidentSubtype.includes(`00 - Contact Record`)) { console.log(`Pass:Incident Subtype matched in the DB`) }
            else { console.log(`Fail:Incident subtype NOT matched in the DB`) }
        }
        return Contact_ID
    }


    async SaveCallerDetails(cl_name, cl_DOB, cl_type, cl_source, cl_mobile_num, cl_email, cl_location) {
        await this.CreateContactTab.click();
        // Check if caller name is provided and fill it, else log a message
        if (cl_name) {
            await this.CallerName.fill(cl_name);
            await this.CallerAnonymous.fill("No");
            await this.page.waitForTimeout(2000);
            await this.page.keyboard.press("Enter");
        } else {
            await this.CallerAnonymous.fill("Yes");
            await this.page.waitForTimeout(2000);
            await this.page.keyboard.press("Enter");
            console.log("Caller name not provided.So Details cannot be saved");
            throw new Error("Caller name not provided")
        }
        if (cl_DOB) {
            await this.CallerDOB.fill(cl_DOB)
        }
        else {
            console.log("caller DOB not provided")
        }
        // Check if caller type is provided and fill it, else log a message
        if (cl_type) {
            await this.Commonutilspage.SelectDropdownValue('(lbl_calltaker_caller_type)', cl_type)
        } else {
            console.log("Caller type not provided.");
        }

        // Check if caller source is provided and fill it, else log a message
        if (cl_source) {
            await this.Commonutilspage.SelectDropdownValue('(lbl_calltaker_caller_source)', cl_source)
        } else {
            console.log("Caller source not provided.");
        }

        // Check if mobile number is provided and fill it, else log a message
        if (cl_mobile_num) {
            await this.CallerMobileNum.fill(cl_mobile_num);
        } else {
            console.log("Mobile number not provided.");
        }
        //caller home number 
        await this.CallerHomeNum.fill('445566876')
        // Check if email is provided and fill it, else log a message
        if (cl_email) {
            await this.CallerEmail.fill(cl_email);
        } else {
            console.log("Email not provided.");
        }
        // Check if location is provided and fill it, else log a message
        if (cl_location) {
            await this.Callerloc.fill(cl_location);
            await this.page.waitForTimeout(2000);
            await this.locationsearch.first().click();
            await this.CallerAddress.fill(cl_location);
            await this.page.waitForTimeout(2000);
            await this.locationsearch.first().click();
        } else {
            console.log("Location not provided.");
        }
        await this.SaveCaller.click()//saving Caller details

        //To convert input DOB format to the format useful for validation
        let DOB;
        if (cl_DOB) {
            function formatDate(cl_DOB) {
                const date = new Date(cl_DOB);
                const day = String(date.getDate()).padStart(2, '0');
                const month = String(date.getMonth() + 1).padStart(2, '0'); // Months are zero-indexed
                const year = date.getFullYear()
                return `${day}/${month}/${year}`;
            }
            DOB = formatDate(cl_DOB)
        }

        //validating caller details
        if (cl_name) { await expect(this.page.locator(".ct-name")).toContainText(cl_name); }
        if (cl_DOB) { await expect(this.page.locator("//p[starts-with(text(), 'Date')]/parent::div")).toContainText(DOB) }
        if (cl_source) { await expect(this.page.locator(".ct-source")).toContainText(cl_source); }
        if (cl_location) { await expect(this.page.locator(".ct-coordenates.caller-location-address-item").first()).toContainText(cl_location); }
        if (cl_mobile_num) { await expect(this.page.locator(".ct-phone")).toContainText(cl_mobile_num); }
        if (cl_type) { await expect(this.page.locator("//p[starts-with(text(), 'Caller Type')]/parent::div")).toContainText(cl_type); }
        if (cl_email) { await expect(this.page.locator("//p[starts-with(text(), 'Caller Email')]/parent::div")).toContainText(cl_email); }
        appendToLogFile("Pass :Caller Details Saved Successfully")
    }
    //file path must be passed as parameter like this example;;
    //'C:/PlayWright/Automated Testing/tests/tests_GB/starwars.txt'
    async AttachFile(filePath, context) {
        await this.AttachmentsSection.click({ force: true, noWaitAfter: true });
        const page0 = context.pages()[0];
        const [fileChooser] = await Promise.all([
            page0.waitForEvent('filechooser'),
            await this.AddAttachmentButton.click({ force: true, noWaitAfter: true }),
        ]);
        await fileChooser.setFiles(filePath);
        const attachButton = page0.getByRole('button', { name: 'Attach', exact: true });
        await attachButton.click({ force: true, noWaitAfter: true });
    }

    async ChangeContactAddress(IncidentLocation) {
        await this.CreateContactTab.click();
        await this.AttendanceLocation.fill(IncidentLocation);
        await this.locationsearch.first().click();
        await this.page.waitForTimeout(5000)
        await this.verifyAddress_button.click();
        await this.page.waitForTimeout(5000)
        await this.acceptVerifyAddress_button.click();
    }

    async MapSearchAddress(address) {
        await this.mapToolSearch_icon.click();
        await this.mapSearch_textbox.click();
        await this.mapSearch_textbox.fill(address);
        const searchTextResult = await this.locationSearchResult_textbox.first();
        const searchLocator = await searchTextResult.locator("//*[contains(@class,'result-address')]");
        const searchResult = await searchLocator.innerText().toString();
        await searchTextResult.click();
        console.log(`Address: ${searchResult}`);
        await this.mapToolSearch_icon.click();
        return searchResult;
    }
}

module.exports = { Contactform }