class ContactformTags{
    constructor(page){
        this.page=page;
        this.tagsbutton=page.locator("#EVENT_PANEL_TAGS")
        this.showonlyselectedtoggle =page.locator("div[id='event-panel-tags'] button[class='toggle-button']")
    }


   //this method will return an array of selected tags 
    async contactformtags()
    {
      await this.tagsbutton.click();
      await this.showonlyselectedtoggle.click();
  
      // Get all elements with the class 'tag selected'
      const elements = await this.page.$$(".tag.selected");

      if (elements.length === 0) {
        console.log("No elements with class 'tag selected' found.");
        return [];  // Return an empty array if no elements are found
    }
  
      const textContents = [];
      for (let element of elements) {
          const text = await element.textContent();
          textContents.push(text);  // Push the text into the array
      }
      console.log(`Selected tags: ${textContents}`) 
      return textContents;  // Return the array of text contents
       
    }
}module.exports ={ContactformTags}