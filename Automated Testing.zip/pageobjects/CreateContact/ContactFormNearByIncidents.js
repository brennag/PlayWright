//This will check whether given incident id is present in nearby incidents.
const{appendToLogFile}=require('../../tests/testlogs')
class NearByIncidents{
    constructor(page)
    {
        this.page=page;
        this.incident="//h1[@class='ct-notification__title']"
    }

    async NearByIncidents(Incident_ID)
    {
        let Nearby_Incidents=[]
        let found=false;
        await this.page.locator("(//div[@class='ct-collapsible__tab__quantityItens-read'])[1]").waitFor()
        let totalincidents=Number(await this.page.locator("(//div[@class='ct-collapsible__tab__quantityItens-read'])[1]").textContent())
        //console.log(totalincidents)
        while (Nearby_Incidents.length < totalincidents) {
            await this.page.locator("(//h1[@class='ct-notification__title'])[1]").isVisible();
            let incidentid = (await this.page.locator("(//h1[@class='ct-notification__title'])[1]").textContent())
            if(Nearby_Incidents.includes(Incident_ID)){
                appendToLogFile(`Pass: Nearby incident ${Incident_ID} is available in the list`)
                found=true;
                break;
            }
            
            if (Nearby_Incidents.length === totalincidents - 3) 
            {
              
                for (let i = 2; i <= 4; i++)
                 {
                    let id = (await this.page.locator(`(//h1[@class='ct-notification__title'])[${i}]`).textContent())
                    if (!Nearby_Incidents.includes(id))
                    {
                        Nearby_Incidents.push(id);  
                    }          
                    if (id === Incident_ID) {
                        appendToLogFile(`Pass:Nearby incident ${Incident_ID} is available in the list`);
                        found = true;
                        break;
                    }

                }
                break; 
            }
        
            if (Nearby_Incidents.includes(incidentid)) {
                await this.page.locator(`//div[@class='ReactVirtualized__Grid ReactVirtualized__List']`).first().hover();
                await this.page.mouse.wheel(0, 3);
            } else {
                Nearby_Incidents.push(incidentid);
                
            }
        }
        
    if(!found){
        appendToLogFile(`Fail:Nearby incident ${Incident_ID} is NOT available in the list`)
    }


        // const elements = await this.page.$$(this.incident)
        // let Nearby_Incidents =[]
        // let Incident ;
        // let found=false;

        // for (let element of elements){
        //     Incident =await element.textContent()
        //     Nearby_Incidents.push(Incident)
        // }
        // console.log(Nearby_Incidents)
        // for(Incident of Nearby_Incidents){
        //     if(Incident==Incident_ID){
        //         console.log(`Pass:${Incident_ID} is available in the Nearby Incidents`)
        //         found=true;
        //     }
        // }
        // if(!found){
        //     console.log(`Fail:${Incident_ID} is NOT available in the Nearby Incidents`)
        // }
    }
}
module.exports ={NearByIncidents}