const{CreateContactPage}=require('./CreateContactpage')
const {appendToLogFile } = require('../../tests/testlogs');

class SearchComments extends CreateContactPage {
    constructor(page){
       super(page)
    }

    async searchcomments(comments)
    {
        
        await this.Comments.click()  
        const NumberofComments = Number(await this.Comments.textContent())
        console.log(`Total number of comments : ${NumberofComments}`)
        let found = false;
        let visiblecomments = await this.commenttext.count()
        if(comments)
        {
            for (let i = 0; i < NumberofComments; i++) {
                // Iterate through visible comments
                for (let j = 0; j < visiblecomments; j++) {
                    let resultcomment = await this.commenttext.nth(j).textContent();
                    
                    // Check if the result comment includes the Incidentcomments
                    if (resultcomment.includes(comments)) {
                        appendToLogFile(`Pass: '${resultcomment}' contains the following comments '${comments}'`);
                        found = true;
                        return(resultcomment)
                        break;  // Break the inner loop (when comment is found)
                    }
                    
                    // If the comment isn't found, scroll to next set of comments
                    await this.page.mouse.click(72, 533);  //click position
                    await this.page.mouse.wheel(0, 50);    // Scroll down
                }
            
                // Exit the outer loop if the comment was found
                if (found) {
                    return(resultcomment)
                    break;
                }
            }
            
            // If comments not found after scrolling and checking all comments
            if (!found) {   
                appendToLogFile(`Fail : Searched comments '${comments}' not found.`);
                return -1;
            }
        }
        else{
            console.log("commets not provided")
        }

        
    }
}
module.exports={SearchComments}