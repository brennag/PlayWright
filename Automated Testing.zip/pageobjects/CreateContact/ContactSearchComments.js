class ContactSearchComments{
    constructor(page){
        this.page=page;
        this.CommentsButton = page.locator("#COMMAND_DIALOG_COMMENTS")
        this.comment =page.locator(".remark-metadata")

    }
    async searchComments(comments)
    {
        await this.CommentsButton.click()
        await this.page.locator("div[title='Search for keywords']").click()

        if(comments)
        {
            await this.page.locator("input[placeholder='Remark Search']").fill(comments)
        
            let resultcomment =await this.comment.first().textContent()
    
            // const NumberofComments = Number(await this.CommentsButton.textContent())
            // console.log(`Total number of comments : ${NumberofComments}`)
            let found = false;
    
            // for(let i=0;i<NumberofComments;i++)
            // {
            //    let resultcomment = await this.comment.nth(i).textContent()
               if(resultcomment.includes(comments))
                {
                   console.log(`'${resultcomment}' contains the following comments '${comments}'`)   
                   found =true
                
               }
            // }
            //if comments not found
            if (!found) {
                console.log(`Searched comments '${comments}' not found.`);
            }
        }
        else{
            console.log("Comments not provided to search.")
        }

    }
}

module.exports ={ContactSearchComments}