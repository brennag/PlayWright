import { expect } from '@playwright/test';
import { SideMenu } from '../../pages/sidemenu'

class EditUnitProperties{
    constructor(page)
    {
        this.page=page;
        this.page = page;
        this.UnitProperties_dialog = page.getByRole('button', { name: unitID })
        this.minimisedialog_button = page.getByRole('button', { name: '–', exact: true })
        this.closeDialog_button = page.getByRole('button', { name: '×', exact: true })
        this.unitLocation_textbox = page.locator({class: "flex-row", id:"LOCATION-INPUT-FIELD" })
        this.cancel_button = page.locator('#command-dialog').getByRole('button', { name: 'Cancel' })
        this.submit_button = page.getByRole('button', { name: 'Submit', exact: true })

    }

    async VerifyUnitProperties(unitID)
    {
        const Sidemenu = Sidemenu

        await Sidemenu.EditUnitProperties(unitID);
        await expect(this.UnitProperties_dialog).toBeVisible();
        await this.unitLocation_textbox.click();

        
    }
}
module.exports = {EditUnitProperties}