class UnitProperties
{
    constructor(page)
    {
        this.page =page;
        this.UnitsTab = page.locator("li[title='Units']");
        this.SearchUnit =page.locator("input[placeholder='Search Units...']")
        this.selectUnit =page.locator(".grid-select-row-checkbox").nth(1)
        this.CommandLine =page.locator("[title='Command Line']");
        this.InputCommand =page.getByPlaceholder('Command Line...');
    }

    async unitproperties(UnitId)
    {
        await this.UnitsTab.click()
        await this.SearchUnit.fill(UnitId)
        await this.page.waitForTimeout(2000)
        await this.selectUnit.click()
        await this.CommandLine.click()
        await this.InputCommand.fill("Unit Properties")
        await this.page.keyboard.press('Enter');
    }
}
module.exports= {UnitProperties}