class LogoffUnit{
    constructor(page)
    {
        this.page=page;
        this.page = page;
        this.CommandLine =page.locator("[title='Command Line']");
        this.InputCommand =page.getByPlaceholder('Command Line...');
        this.UnitSelect=page.locator("div[name='(LBL_LogoffUnit_UnitID)'] input").first();
        this.SubmitBtn = page.locator("//button[@class='btn btn-primary submit-btn cd-tabbable ng-binding']")
    }

    async LogoffUnit(UnitId)
    {
        await this.CommandLine.click();
        await this.InputCommand.fill('LOGOFF UNIT');
        await this.page.keyboard.press('Enter')
        await this.UnitSelect.fill(UnitId);
        await this.page.waitForTimeout(2000);
        await this.page.keyboard.press('Enter');
        await this.SubmitBtn.click();

    }
}
module.exports = {LogoffUnit}