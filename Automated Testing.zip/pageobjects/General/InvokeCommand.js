class InvokeCommand{
    constructor(page)
    {
        this.page = page;
        this.CommandLine =page.locator("[title='Command Line']");
        this.InputCommand =page.getByPlaceholder('Command Line...');
        this.commandlineselect = page.locator("[title='Command Line']")
    }
    async invokecommand(Command)
    {
        //this step is for when commandline not visible in tabs like scheduled incident
        if(!await this.commandlineselect.isVisible()){
            await this.page.locator(`//li[@title='Create Contact']`).click()
        }
        const buttonclicked = await this.commandlineselect.getAttribute("class")
        if(Command==null)
        {
            console.log("Command is not provided. Please enter a command!")
        }
        else
        {
            if(buttonclicked =='docked-view-toggle tab-container-view ng-scope tab-header-selected active')
            {
                await this.InputCommand.fill(Command);
                await this.page.keyboard.press('Enter')
                console.log(`"${Command} command is executed"`)
                await this.CommandLine.click();
            }
            else{
                await this.CommandLine.click();
                await this.InputCommand.fill(Command);
                await this.page.keyboard.press('Enter')
                console.log(`"${Command} command is executed"`)
                await this.CommandLine.click();
                await this.page.waitForTimeout(2000)
            }

           
        }
        
    }
}
module.exports ={InvokeCommand}