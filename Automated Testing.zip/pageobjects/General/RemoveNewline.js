class RemoveNewline{
    constructor(page){
        this.page =page;
    }

    async removenewline(inputstring)
    {
        let outputtsring =inputstring.replace(/[\n\r]+/g, ' ');

        //console.log(`Text after removing new line characters : ${outputtsring}`)

        return outputtsring;
    }
}

module.exports ={RemoveNewline}