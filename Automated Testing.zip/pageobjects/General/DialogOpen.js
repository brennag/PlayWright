// This is to check whether a dialog has opened or not. it will return true if dialog correctly opened, false if not opened.
const{InvokeCommand}= require('../General/InvokeCommand')
const{appendToLogFile}=require('../../tests/testlogs')

class DialogOpen{
        constructor(page)
        {
            this.page=page;
            
        }
        
        async DialogOpen(Dialogname,Command)
        {
        const Invokecommandpage =new InvokeCommand(this.page);
        //function to convert only first letter of word to uppercase 
        // function capitalizeFirstLetter(str) {
        //     return str
        //         .split(' ') // Split the string into words
        //         .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()) // Capitalize first letter and lowercase the rest
        //         .join(' '); // Join the words back together
        // }
        // let Dialognametemp =await capitalizeFirstLetter(Dialogname) 
        await this.page.waitForTimeout(2000) 
        
        if (await this.page.locator(`//*[contains(@class,'dialog-header')]//*[contains(text(),'${Dialogname}')]`).isVisible()) {
            appendToLogFile(`Pass : Dialog : ${Dialogname} displayed`);
            return true;
        } else {
            if(Command){
            console.log(`Dialog : ${Dialogname} NOT displayed. Invoke the dialog using command.`);
            await Invokecommandpage.invokecommand(Command);
        
            // Wait for the dialog to be visible after invoking the command
            await this.page.waitForTimeout(2000)
            const dialogLocator = this.page.locator(`//*[contains(@class,'dialog-header')]//*[contains(text(),'${Dialogname}')]`);
            const isDialogVisible = await dialogLocator.isVisible();
        
            if (isDialogVisible) {
               appendToLogFile(`Pass : Dialog : ${Dialogname} displayed after invoking the command`);
                return true;
            } else {
                appendToLogFile(`Fail: Dialog : ${Dialogname} STILL NOT displayed after invoking the command`);
                return false; 
            }
        }
        }
        
           
        } 

    }
    module.exports={DialogOpen}