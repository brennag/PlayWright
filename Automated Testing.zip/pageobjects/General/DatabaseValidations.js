const db=require('./Database')

class DatabaseValidations {
    constructor(page){
        this.page=page
    }
    async IncidentvalidationDB(Incident_ID)
    {
        await db.connectDB()
        let query =`select case when 
        charindex(':', cel.Location) > 0 then left(cel.Location, charindex(':', cel.Location) - 1) 
        else cel.Location end as loc,
        ae.AgencyEventId, 
        ae.AgencyEventTypeCode + ' - ' + ae.AgencyEventTypeCodeDesc agencyeventtype,
        ae.AgencyEventSubtypeCode + ' - ' + ae.AgencyEventSubtypeCodeDesc AgencyEventSubtype, 
        ae.SubstatusCode
        from agencyevent ae,commonevent ce, commoneventlocation cel
        where ae.agencyeventid = '${Incident_ID}'and cel.CommonEventLocationId = ce.EventLocationId and ae.CommonEventId = ce.commoneventid`

        let result = await db.runQuery(query)
        await db.disconnectDB()
        let DB_location=await result[0].loc;
        let DB_Incident_ID= await result[0].AgencyEventId;
        let DB_Incident_type = await result[0].agencyeventtype;
        let DB_IncidentSubtype = await result[0].AgencyEventSubtype;
        
        return [DB_location,DB_Incident_ID,DB_Incident_type,DB_IncidentSubtype]
    }

}
module.exports={DatabaseValidations}