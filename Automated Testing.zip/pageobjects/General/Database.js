const testdata =JSON.parse(JSON.stringify(require('../../testdata/data.json')));
// db.js
const sql = require('mssql');

const config = {
  server: testdata.DBServername,
  database: testdata.DBname,
  user: testdata.DBusername,
  password: testdata.DBpassword,
  options: {
    encrypt: true,
    trustServerCertificate: true,
  },
};

let pool;

async function connectDB() {
  pool = await sql.connect(config);
}

async function disconnectDB() {
  await pool.close();
}

//this will return an array of rows of the result 
async function runQuery(query) {
    const result = await pool.request().query(query);
    return result.recordset;
  }

module.exports = {
  connectDB,
  disconnectDB,
  runQuery,
};

