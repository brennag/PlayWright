const{expect}=require('@playwright/test')
const{appendToLogFile}=require('../../tests/testlogs')
class logout{
    constructor(page)
    {
        this.page=page;
        this.menubutton = page.locator("//button[@class='oc-navbar-toggle']")
        this.logoutbutton =page.locator("button[title='Log Out']")
        this.logoutpopup  = page.locator("//button[normalize-space()='Yes']")
        this.logoutconfirmation=page.locator("//div[@class='logout-message']")
    }
    async logout()
    {   
        await this.menubutton.click()
        await this.logoutbutton.click()
        await this.logoutpopup.click()
        await expect(this.logoutconfirmation).toContainText("you have been logged out.")
        const logoutmessage =await this.logoutconfirmation.textContent()
        if(logoutmessage.includes(`you have been logged out.`)){
            console.log(`Pass:Logout is successful`)
        }
        else{
            console.log(`Fail:Logout is unsuccessful`)
        }
    }
}
module.exports ={logout}