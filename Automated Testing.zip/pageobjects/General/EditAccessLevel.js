import { expect } from '@playwright/test';
import { SideMenu } from '../../pages/sidemenu'

class EditAccessLevel{
    constructor(page)
    {
        this.page=page;
        this.page = page;
        this.accessLevel_dialog = page.getByRole('button', { name: 'Edit Access Levels – × Select' })
        this.minimisedialog_button = page.getByRole('button', { name: '–', exact: true })
        this.closeDialog_button = page.getByRole('button', { name: '×', exact: true })
        this.accessLevel_searchbox = page.getByRole('searchbox', { name: 'Access Levels Search...' })
        this.cancel_button = page.locator('#command-dialog').getByRole('button', { name: 'Cancel' })
        this.submit_button = page.getByRole('button', { name: 'Submit', exact: true })
        this.accessVisible_toggle = page.getByRole('row', { name: role }).getByRole('button')
        //react component - slider 3 x points
        //this.accessLevel_slider = page.locator('_react=rc-slider-handle rc-slider-handle-click-focused', {level : level})
                 


    }

    async ChangeAccessLevel(role, level)
    {
        const Sidemenu = Sidemenu

        await Sidemenu.ChangeAccessLevel();
        await expect(this.accessLevel_dialog).toBeVisible();
// is slider visible, if it is, then the accessVisible toggle button is set to on (visible), if not, then the toggle is off (not visible)

    }
}
module.exports = {EditAccessLevel}