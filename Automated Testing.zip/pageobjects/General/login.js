const testdata =JSON.parse(JSON.stringify(require('../../testdata/data.json')));
const { expect } = require('@playwright/test');
class login{
    constructor(page)
    {
        this.page=page; // creating local class variable
        
        //Store locators in variable
        this.userName= page.locator('#username');
        this.Password= page.locator("[name='password']");
        this.loginbutton= page.getByRole('button', { name: 'Log In' });
        this.Positiondropdown = page.locator('.hxgn-inner-select__value-container').first();
        this.languagedropdown = page.locator('.hxgn-inner-select__value-container').nth(1)
        this.language = page.getByText(testdata.language, { exact: true }).last();
        this.continuebutton= page.getByRole('button', { name: 'Continue' });
        this.multipletabsSelector = page.locator("button[class='ui-button primary-button']");
        this.workspaceScreensText=page.locator(`//*[text()="The workspace you are opening contains 1 other screens. Would you like to open these screens in new tabs?"]`);
        this.YesButtonInWorkspaceScreensDialog = this.page.getByText(`Yes`);
        this.NoButtonInWorkspaceScreensDialog = this.page.getByRole('button', {name: 'No' ,disabled: false});
        this.menuButton = this.page.locator(`//*[@class="oc-navbar-toggle"]`);
        this.commandLineButton = this.page.locator(`//*[@title="Command Line"]`);
    }

    async goTO()
    {
        await this.page.goto(testdata.URL);
    }

    async validLogin(username, password, PositionValue)
    {
        await this.userName.fill(username);
        await this.Password.fill(password);
        await this.loginbutton.click(); //login
        await this.Positiondropdown.click();
        await this.page.getByText(PositionValue, { exact: true }).click();
        await this.languagedropdown.click();
        await this.language.click();
        await this.continuebutton.click();  //continue
 
    }


    async waitForNewPageAndCheckTitle() {
 
        let openTabs, totalTabs;
        let context = this.page.context();
        let MapPage;
        let actions='yes'
        // await this.page.pause();
       
        while(true){
            context = this.page.context();
            openTabs = context.pages();
            totalTabs = openTabs.length;
 
            if(await this.workspaceScreensText.isVisible()){
                await expect(this.workspaceScreensText).toBeVisible({timeout:200000});
                await this.workspaceScreensText.waitFor({state:'visible'});
                if(actions == "yes"){
                    try {
                        [ MapPage ] = await Promise.all([ this.page.waitForEvent('popup', { timeout: 60000 }), this.YesButtonInWorkspaceScreensDialog.click() ]);
                        await MapPage.waitForLoadState('domcontentloaded', { timeout: 120000 });
                        break;
                      
                      } catch (error) {
                          console.error(`Error clicking on ${this.YesButtonInWorkspaceScreensDialog} and opening new tab :`, error);
                          throw error;
                      }
                    }
                else if(actions == "no"){
                    await this.workspaceScreensText.waitFor({state:'visible'});
                    await this.NoButtonInWorkspaceScreensDialog.click();
                    break;
                }
            }
            else if(totalTabs === 2){
                MapPage = openTabs[1]; //await context.waitForEvent('page');
                await MapPage.waitForLoadState();
                break;
           
            }
 
            // else if(await this.menuButton.isVisible() && !(await this.workspaceScreensText.isVisible()) && totalTabs == 1 && this.page.url() === this.pageurl&&await this.commandLineButton.isVisible()){
            //     console.log(`No new page`);
            //     break;
            // }
        
        }
    

    await expect(MapPage).toHaveTitle("Map - HxGN OnCall® Despatch");
    await this.page.bringToFront();
    await this.page.locator("li[title='Create Contact'] ").click();
    await expect(this.page).toHaveTitle("Create Contact - HxGN OnCall® Despatch");
    console.log("Create Contact page opened");
    return MapPage; 
}


    // async waitForNewPageAndCheckTitle() {

    //     // await this.page.getByRole('button', { name: 'SOPs' }).waitFor();
    //     // Wait for the 'Menu' icon to appear, indicating that the page is loaded
    //     await this.page.locator("//button[@title='About']").waitFor()
    
    //     const context = this.page.context();  // Get the browser context
    //     let pages = await context.pages();  // Get all pages in the context
    //     console.log(`Number of pages open: ${pages.length}`);
    
    //     let MapPage;
    
      
    //     // else 
    //     // {
    //         // If there's only one page open (else condition)
    //         const popup = await this.multipletabsSelector.isVisible();
    
    //         if (popup) {
    //             // Set up the event listener for the new page before clicking the button
    //             [MapPage] = await Promise.all([
    //                 this.page.context().waitForEvent('page'),  // Listen for any new page opened
    //                 this.multipletabsSelector.click(),  // Click the button to open the new page
    //             ]);
    //         } 
    //         else 
    //         {
    //             for(let i=0;i<20;i++)
    //                 {
    //                     await this.page.waitForTimeout(2000)
    //                     pages = await context.pages();
    //                     if (pages.length === 2) {
    //                         MapPage = pages[1];
    //                         break;
    //                     }
    
    //                 }
    //         }
    //     //}
    
    //     await expect(MapPage).toHaveTitle("Map - HxGN OnCall® Despatch");
    //     await this.page.bringToFront();
    //     await this.page.locator("li[title='Create Contact'] ").click();
    //     await expect(this.page).toHaveTitle("Create Contact - HxGN OnCall® Despatch");
    //     console.log("Create Contact page opened");
    //     return MapPage; 
    // }
      
}
module.exports = {login};


