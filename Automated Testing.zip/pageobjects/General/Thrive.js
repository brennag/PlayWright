//const{InvokeCommand}= require('../General/InvokeCommand');
//const{DialogOpen}=require('../General/DialogOpen');
//const {Contactform}=require('../../pageobjects/CreateContact/Contactform')
//const{CreateContactPage}=require('./CreateContactpage')
const {test,expect} = require ('@playwright/test')

class thrive{
    //clickingOnDropdowns = (value) => this.page.locator(`//*[@label="(${value})"]//*[contains(@class,"select__dropdown")]`)
    constructor(page)
    {
        this.page=page;
        this.thrivePlusTitle = page.locator(`//*[text()="THRIVE+"]`);
        this.thrivePlusDocumentLink = page.locator(`//*[@title="Full THRIVE guidance document"]`);
        this.submitButtonInThrivePlusDialog = page.locator(`//*[text()="Submit"]`);
        
    }
    clickingOnDropdowns = (value) => this.page.locator(`//*[@label="(${value})"]//*[contains(@class,"select__dropdown")]`)

    async documentLink(appbutton){
        const [newPage] = await Promise.all([ this.page.waitForEvent('popup', { timeout: 60000 }), appbutton.click() ]);
                    await newPage.waitForLoadState('domcontentloaded', { timeout: 120000 });
                    const newPageUrl = newPage.url();
                    console.log(`New page URL : `, newPageUrl)
                    return { newPage, newPageUrl };
    }
    
    async thrive(values){
        
    //await this.thrivePlusDocumentLink.click();
    const { newPage: newPage } = await this.documentLink(this.thrivePlusDocumentLink);
    console.log(await newPage.url());
    await this.page.bringToFront();
        const dropdownsAndInputFields = [[`lbl_thrive_who_what`,`lbl_thrive_type_of_threat`, `lbl_thrive_threat_comment`], [`lbl_thrive_likely_level_of_harm`, `lbl_thrive_type_of_harm`, `lbl_thrive_harm_comment`], [`lbl_thrive_risk_level`, `lbl_thrive_risk_comment`], [`lbl_thrive_investigation`, `lbl_thrive_investigation_rationale`, `lbl_thrive_investigation_comment`], [`lbl_thrive_vulnerability`, `lbl_thrive_vulnerability_reason`, `lbl_thrive_vulnerability_comment`], [`lbl_thrive_engagement`, `lbl_thrive_type_of_engagement`, `lbl_thrive_engagement_comment`], [`lbl_thrive_prevention_comment`], [`lbl_thrive_intervention`, `lbl_thrive_intervention_partner_agency`, `lbl_thrive_intervention_comment`]];
        const assessmentText = [`Threat Assessment:`, `Harm Assessment:`, `Risk Assessment:`, `Investigation Assessment:`, `Vulnerability Assessment:`, `Engagement Assessment:`, `Prevention Assessment:`, `Intervention Assessment:`]            
        for(let i=0; i<dropdownsAndInputFields.length; i++){
            if(await this.page.locator(`//*[text()="${assessmentText[i]}"]`).isVisible()){
                for(let j=0; j< dropdownsAndInputFields[i].length; j++){
                    if(await this.clickingOnDropdowns(dropdownsAndInputFields[i][j]).isVisible()){
                        await this.clickingOnDropdowns(dropdownsAndInputFields[i][j]);
                        await this.clickingOnDropdowns(dropdownsAndInputFields[i][j]).scrollIntoViewIfNeeded();
                        await this.clickingOnDropdowns(dropdownsAndInputFields[i][j]).click();
                        await this.page.locator(`//*[text()="${values[i][j]}"]`).last().click();
                        await this.page.waitForTimeout(500);
                    }
                    else if(dropdownsAndInputFields[i][j].includes(`comment`)){
                        await this.page.locator(`//*[@label="(${dropdownsAndInputFields[i][j]})"]`).fill(values[i][j]);
                        await this.page.waitForTimeout(500);  
                    }
                }
            }
            
            while(i+1 < dropdownsAndInputFields.length){
                if(await this.page.locator(`//*[text()="${assessmentText[i+1]}"]`).isVisible()){
                    break;
                }
                else{
                    await this.page.locator(`//*[@class="command-dialog-element-container"]`).hover();
                    await this.page.mouse.wheel(0, 50);
                    await this.page.locator(`//*[text()="${assessmentText[i+1]}"]`).scrollIntoViewIfNeeded();
                    await this.page.waitForTimeout(500);
                    await this.page.waitForLoadState('domcontentloaded', { timeout: 350000 });
                }
            }}
        
        
        await this.submitButtonInThrivePlusDialog.click();
    }
}
module.exports={thrive}