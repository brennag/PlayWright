const { error } = require("console");
const { test, expect, context } = require('@playwright/test');
//const { PageObjects } = require('../../pageobjects/PageObjects');
const { CreateContactPage } = require('../../pageobjects/CreateContact/CreateContactpage');

class Alarms extends CreateContactPage {
    constructor(page) {
        super(page)
        this.addAlarmURN_button = page.getByRole('button', { name: 'AMS URN Search' })
        this.alarmDetails_dialog = page.getByRole('button', { name: 'AMS Matched URN Details – ×' })
        this.minimiseAlarmDialog_button = page.getByRole('button', { name: '–', exact: true })
        this.closeAlarmsAlarmDialog_button = page.getByRole('button', { name: '×', exact: true })
        this.URNSearch_textbox = page.locator('input[name="\\(LBL_URN_SEARCH_ID\\)"]')
        this.URNSearch_button = page.getByRole('button', { name: 'Search', exact: true })
        this.URNEmpty_dialog = page.getByRole('button', { name: 'URN Not Provided – ×' })
        this.URNEmptyOK_button = page.getByRole('button', { name: 'OK', exact: true })
        this.mismatchedAddress_button = page.getByRole('button', { name: 'Mismatched Address', exact: true })
        this.unknownURN_button = page.getByRole('button', { name: 'Unknown URN', exact: true })
        this.URNID_textbox = page.locator('input[name="\\(LBL_URN_ID\\)"]')
        this.alarmType_textbox = page.locator('input[name="\\(LBL_URN_ALARM_TYPE\\)"]')
        this.alarmStatus_textbox = page.locator('input[name="\\(LBL_URN_ALARM_STATUS\\)"]')
        this.alarmAddress_textbox = page.locator('input[name="\\(LBL_URN_ALARM_ADDRESS\\)"]')
        this.ARCSuppliedAlarmType_dropdown = page.locator("(//div[contains(@class,'hxgn-inner-select__value-container css-1hwfws3')])[2]")
        this.ARCSuppliedAlarmType_selection1 = page.locator("//div[@id='react-select-28-option-0']")
        //TODO - Option 0 - 6 to be parameterised
        this.companyName_textbox = page.locator('input[name="\\(LBL_URN_CONTACT_COMPANY\\)"]')
        this.mobile_textbox = page.locator('input[name="\\(LBL_URN_CONTACT_MOB\\)"]')
        this.number_textbox = page.locator('input[name="\\(LBL_URN_CONTACT_NO\\)"]')
        this.telephone_textbox = page.locator('input[name="\\(LBL_URN_CONTACT_TELEPHONE\\)"]')
        this.email_textbox = page.locator('input[name="\\(LBL_URN_CONTACT_EMAIL\\)"]')
        this.fax_textbox = page.locator('input[name="\\(LBL_URN_CONTACT_FAX\\)"]')
        this.AMSDialogCancel_button = page.getByRole('button', { name: 'Cancel', exact: true })
        this.AMSDialogSubmit_button = page.getByRole('button', { name: 'Submit', exact: true })
        //
        this.AMSCombinedAlarm_dialog = page.getByRole('button', { name: 'AMS Combined Alarm Dialog' })
        this.minimiseAMSCombinedAlarmDialog_button = page.getByRole('button', { name: '–', exact: true })
        this.closeAMSCombinedAlarmDialog_button = page.getByRole('button', { name: '×', exact: true })
        this.combinedAlarmTypeCA_button = page.getByRole('button', { name: 'CA', exact: true })
        this.combinedAlarmTypeCS_button = page.getByRole('button', { name: 'CS', exact: true })
        this.combinedAlarmBack_button = page.getByRole('button', { name: 'Back', exact: true })
    }

    async addAlarm(alarmURN) {
        //const context = await browser.newContext();
        //const page = await context.newPage();
        //const pages = new PageObjects(page);
        //const { CommonUtilspage } = pages;

        await this.addAlarmURN_button.click();
        await expect(this.alarmDetails_dialog).toBeVisible();
        console.log("AMS Matched URN Details Dialog presented");
        await this.URNSearch_textbox.fill(alarmURN);
        await this.URNSearch_button.click();
        /*Scenario where URN is empty before clicking on AMS Search button
        if (await expect(this.URNEmpty_dialog).toBeVisible())
        {
            await URNEmptyOK_button.click();
            await closeAlarmsAlarmDialog_button.click();
            console.log("No Alarm URN Provided");
        }
        else 
        {
            console.log("Alarm URN Provided");
            await expect(this.AMSCombinedAlarm_dialog).toBeVisible();
            await this.combinedAlarmTypeCA_button.click();
        };
        */
        await expect(this.AMSCombinedAlarm_dialog).toBeVisible();
        await this.combinedAlarmTypeCA_button.click();
        //TODO incorporate common use dropdown
        //await CommonUtilspage.SelectDropdownValue('(LBL_URN_ALARM_TYPE)', 'CA');
        //await Alarmspage.AMSDialogSubmit_button.click();

    }



    clickingOnDropdowns = (value) => this.page.locator(`//*[@label="(${value})"]//*[contains(@class,"select__dropdown")]`);
    async clickingOnAMSType() {
        const page = await context.newPage();
        const pages = new PageObjects(page);
        const { CommonUtilspage } = pages;

        await this.clickingOnDropdowns('LBL_URN_ALARM_TYPE').isVisible()
        await CommonUtilspage.SelectDropdownValue('(LBL_URN_ALARM_TYPE)', 'CA');
        await this.AMSDialogSubmit_button.click();

    }
}
module.exports = { Alarms }