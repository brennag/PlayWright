const{expect} =require('@playwright/test')
class NotificationSearch{
    constructor(page)
    {
        this.page=page;
    }

    async notificationSearch(tab, message){
        let tabPanel = false;
        // Clicking on the notification icon in the tab
        await this.page.locator(`//*[contains(@title,"Notifications ")]`).click();
        if(await this.page.locator(`//*[@id="menu-notifications-area"]`).isVisible()){
            console.log(`The Nofication panel is opened`);
        }
        else{
            await this.page.locator(`//*[contains(@title,"Notifications ")]`).click();
            await expect(this.page.locator(`//*[@id="menu-notifications-area"]`)).toBeVisible();
        }
        await this.page.waitForTimeout(2000);
        // Selecting the Filter options
        await this.page.locator(`//*[text()="Filter Options"]/following-sibling::*//*[contains(@class,"select__dropdown")]`).click();
        await this.page.waitForTimeout(500);
        await this.clickingOnCheckbox('check', 'Show All');
        await this.clickingOnCheckbox('uncheck', 'Show All');
        await this.clickingOnCheckbox('check', tab);
        await this.page.locator(`//*[text()="Filter Options"]/following-sibling::*//*[contains(@class,"select__dropdown")]`).click();
        await this.page.waitForTimeout(500);
        await this.page.locator(`//*[text()="Sort Options"]/following-sibling::*//*[contains(@class,"select__dropdown")]`).click();
        await this.page.locator(`//*[text()="Newest on Top"]`).click();
        await this.page.waitForTimeout(2000);
        // Clicking on menu notification tab
        if(await this.page.locator(`//*[contains(text(),"${tab}")]/ancestor::*[@class="Collapsible__trigger is-open"]`).isVisible()){
            console.log(`The ${tab} tab is already opened in Notification panel`);
            tabPanel = true;
        }
        else if(await this.page.locator(`//*[contains(text(),"${tab}")]/ancestor::*[@class="Collapsible__trigger is-closed"]`).isVisible()){
            await this.page.locator(`//*[contains(text(),"${tab}")]`).click();
            await expect(this.page.locator(`//*[contains(text(),"${tab}")]/ancestor::*[@class="Collapsible__trigger is-open"]`)).toBeVisible();
            console.log(`The ${tab} tab is now opened in Notification panel`);
            tabPanel = true;
        }
        let temp;
        while(true){
            var text = await this.page.locator(`//*[contains(text(),"${tab}")]`).textContent();
            var matchtext = text.match(/\((\d+)\)/);
            var noOfNotifications = matchtext ? parseInt(matchtext[1]) : null;
           
            if(temp === noOfNotifications && temp != null && noOfNotifications > 0){
                // console.log(temp, typeof(temp), noOfNotifications, typeof(noOfNotifications))
                break;
            }
            else{
                // console.log(temp, typeof(temp), noOfNotifications, typeof(noOfNotifications))
                temp = noOfNotifications
                await this.page.waitForTimeout(1000);
            }
        }
        const  str = await this.page.locator(`//*[contains(text(),"${tab}")]`).textContent();
        const match = str.match(/\((\d+)\)/);
        const noOfRows = match ? parseInt(match[1]) : null;
        console.log(`Total no of notifications: ${noOfRows}`);
        let messageFound = false;
        if(tabPanel && noOfRows > 0){
            let pagination = 10
            let notification = await this.page.locator(`//*[contains(text(),"${tab}")]/ancestor::*[@role="button"]/following-sibling::*//*[contains(@class,"notification-content-column")]`)
            const rounded = Math.ceil(noOfRows / 10);
            for(let p=1; p<= rounded;p++){
                for(let i=0;i<await notification.count();i++){
                    await notification.nth(i).scrollIntoViewIfNeeded();
                    let text = await notification.nth(i).textContent();
                    if(text.includes(message)){
                        messageFound = true;
                    }
                    if(messageFound){
                        console.log(`The Message Found at the page ${p} ${i}`);
                        break;
                    }
                    if( i+1 == pagination){
                        await this.page.locator(`(//*[@class="last-triangle"]/parent::button)[1]`).click();
                        await this.page.waitForTimeout(1000);
                        // pagination += 10;
                    }
                }
                if(messageFound){
                    break;
                }
            }
        }
        if(noOfRows == 0){
            console.log(`No notifications are available`);
        }
        if( messageFound == false){
            console.log(`The message is not found`);
        }

        if(await this.page.locator(`//*[contains(text(),"${tab}")]/ancestor::*[@class="Collapsible__trigger is-open"]`).isVisible()){
            await this.page.locator(`//*[contains(text(),"${tab}")]`).click();
            await expect(this.page.locator(`//*[contains(text(),"${tab}")]/ancestor::*[@class="Collapsible__trigger is-closed"]`)).toBeVisible();
            console.log(`The ${tab} tab is now closed in Notification panel`);
            tabPanel = true;
        }
        else if(await this.page.locator(`//*[contains(text(),"${tab}")]/ancestor::*[@class="Collapsible__trigger is-closed"]`).isVisible()){
            console.log(`The ${tab} tab is already closed in Notification panel`);
            tabPanel = true;
        }
        await this.page.locator(`//*[contains(@class,"close-btn")]//*[contains(@class,"close-icon")]`).click();
    }


    async clickingOnCheckbox(action, name){
        action = action.toLowerCase();
        const checkbox = await this.page.locator(`//*[text()="${name}"]/preceding-sibling::*[@type="checkbox"]`)//*[contains(@id,"SHOW_ALL")]
        if(action == 'check' && await checkbox.isChecked()){
            console.log(`${name} is already checked`);
        }
        else if(action == 'check' && !(await checkbox.isChecked())){
            await checkbox.click({timeout:10000, force: true});
            await this.page.waitForTimeout(500);
            if(action == 'check' && await checkbox.isChecked()){
                console.log(`${name} is checked`);
            }
        }
        else if(action == 'uncheck' && await checkbox.isChecked()){
            await checkbox.click({force: true});
            await this.page.waitForTimeout(500);
            if(action == 'uncheck' && !(await checkbox.isChecked())){
                console.log(`${name} is unchecked`);
            }
        }
        else if(action =='uncheck' && !await checkbox.isChecked()){
            console.log(`${name} is already unchecked`)
        }
    }
}

module.exports ={NotificationSearch}

