const { DialogOpen } = require('./DialogOpen')
const { expect } = require('@playwright/test')
class ChangeRole {
    constructor(page) {
        this.page = page;
        this.changeWorkspaceField = page.locator(`//*[@name='(lbl_change_role_workspace)']//div[contains(@class, 'hxgn-inner-select__value-container')]`);
        this.changeRoleField = page.locator(`//*[@name="(lbl_change_role_rolename)"]//input[@role="combobox"]`);
        this.changeWorkspaceDropdown = page.locator(`//*[@label="(lbl_change_role_workspace)"]//*[contains(@class,"select__dropdown")]`);
        this.changeRoledropdown = page.locator(`//*[@name="(lbl_change_role_rolename)"]//*[@role="button"]`);
        this.multipletabsSelector = page.locator("button[class='ui-button primary-button']");
        this.cancelButton = page.locator(`//button[@class='btn btn-default cd-tabbable cancel-button']`);
        this.submitButton = page.locator(`//button[@class='btn btn-primary submit-btn cd-tabbable ng-binding']`);
    }


    async changerole(Role, Workspace) {
        const DialogOpenPage = new DialogOpen(this.page)
        await DialogOpenPage.DialogOpen('Change Role', 'CHANGE ROLE')
        await this.page.locator(`//*[text()="Change Role"]`).nth(-1).waitFor({ state: 'visible' });
        const role_after = await this.changeRoleField.inputValue()
        const workspace_after = await this.changeWorkspaceField.textContent()
        console.log(`role: ${role_after}\n workspace:${workspace_after}`)
        if (role_after == Role && workspace_after == Workspace) {
            console.log(`Pass:Role :${Role} and  Workspace: ${Workspace} already selected, no change required`)
            await this.cancelButton.click();
        }
        else {
            console.log(`Role Change is Required`)
            await this.changeRoledropdown.click();
            await this.page.locator(`//*[text()="${Role}"]`).nth(-1).click();
            await this.changeWorkspaceDropdown.click();
            await this.page.locator(`//*[text()="${Workspace}"]`).nth(-1).click();
            await this.page.locator(`//*[text()="Submit"]`).click();
            await this.page.waitForTimeout(60000)
            const context = this.page.context();  // Get the browser context
        const pages = await context.pages();
        let MapPage;
        if (pages.length === 2) {
            MapPage = pages[1];  // Assign the second page to MapPage
        }
        else {
            // If there's only one page open (else condition)
            const popup = await this.multipletabsSelector.isVisible();

            if (popup) {
                // Set up the event listener for the new page before clicking the button
                [MapPage] = await Promise.all([
                    this.page.context().waitForEvent('page'),  // Listen for any new page opened
                    this.multipletabsSelector.click(),  // Click the button to open the new page
                ]);
            }
            else {
                [MapPage] = await Promise.all([
                    this.page.context().waitForEvent('page'),  // Listen for the new page event
                ]);
            }
        }

        await expect(MapPage).toHaveTitle("Map - HxGN OnCall® Despatch");
        await this.page.bringToFront();
        await DialogOpenPage.DialogOpen('Change Role', 'CHANGE ROLE')
        console.log(`role: ${role_after}\n workspace:${workspace_after}`)
        if (role_after == Role && workspace_after == Workspace) {
            console.log(`Pass:Role :${Role} and  Workspace: ${Workspace} has been changed successfully`)
        }
        else {
            console.log(`Fail:Role Change is Unsuccessful`)
        }
        }
    }
}
module.exports = { ChangeRole }

