const{appendToLogFile}=require('../../tests/testlogs')
class SOPPanelSOPSearch{
    constructor(page){
        this.page=page;
        this.SOPsbutton =page.locator("button[title='SOPs']")
        this.yourSOPs =page.locator("//*[contains(text(),'Your SOP Tasks')]")
        this.ALLSOPs =page.locator(".div-onetab-all_sops.tab-container-tab")
        this.Filter=page.locator("input[placeholder='Filter']")
        this.expandbutton =page.locator("//*[contains(@class,'expander-wrapper')]//button").first()
        this.SOPname =page.locator("div[class='flex-row flex-align-center sop-workflow-card-header sop-instance-card-header'] h4")
    }

    async SOPPanelSOPSearch(Incident_ID, SOP_to_Search) {
        if (!SOP_to_Search) {
            appendToLogFile("Fail: Please provide an SOP to Search");
            return; // Exit early if no SOP to search
        }
    
        await this.SOPsbutton.click();
        await this.ALLSOPs.click();
        await this.Filter.fill(Incident_ID);
        await this.page.waitForTimeout(2000);
    
        // Expand if needed
        const expander = await this.expandbutton.getAttribute('title');
        if (expander === 'Expand') {
            await this.expandbutton.click();
        }
        await this.checkSOPMatch(SOP_to_Search);
    }
    

    async checkSOPMatch(SOP_to_Search) {
        let elements=await this.page.$$(`//div[@class='flex-row flex-align-center sop-workflow-card-header sop-instance-card-header']//h4`)
        let AllSOPs=[]
        let sop;
        for(let element of elements){
            sop= await element.textContent()
            AllSOPs.push(sop)
        }
        
        if(AllSOPs.includes(SOP_to_Search))
            {
                appendToLogFile(`Pass: SOP searched : '${SOP_to_Search}' is available in SOP Panel`)
            }
            else
            {
                appendToLogFile(`Fail: SOP searched : '${SOP_to_Search}' is not available in SOP Panel `)
            }
    }

    async yourSOPtasksvalidation(SOPname)
    {
        await this.yourSOPs.click()
       if(await this.Filter.isVisible()){
        await this.Filter.fill(SOPname)
        const expander = await this.expandbutton.getAttribute('title');
        if (expander === 'Expand') {
            await this.expandbutton.click();
        }
       }
        if(await this.page.locator(`//*[@class="sop-list showing-sort-controls"]//*[@class="sop-workflow-card-title"]`).first().isVisible())
        {
            const sopfound=await this.page.locator(`//*[@class="sop-list showing-sort-controls"]//*[@class="sop-workflow-card-title"]`).first().textContent()
            console.log(`SOP found: ${SOPname}`)
            if(sopfound==SOPname){
                console.log(`sop provided matched under your SOPs section`)
                return true
            }
            else{
                console.log(`sop provided NOT matched under your SOPs section`) 
            }
            
        }
        else{
            console.log(`SOP not available`)
            return false
        }
        
   
    
    }
}
module.exports={SOPPanelSOPSearch}