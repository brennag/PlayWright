class SideMenu {
    constructor(page) {
        //Locators within the page
        //TODO - Would like to make use of generic menu items if possible
        //this.menu1 = page.getByText('#menu')
        /*
        this.menuSelection = page.locator(
        {
            "className": "cd-tabbable",
            "tabIndex": 1000,
            "children": menuOption
        })
        */
        textContent:
        //this.menu2 = page.getByText('#menu')
        //this.menu3 = page.getByText('#menu')
        //this.menuoption = page.locator('span').filter({ hasText: '#menuoption' })

        //== USAGE of Comment separators == //
        // ================================ //
        // Every use of 
        // |
        // ==> 
        // Denotes a level down on the menu
        //
        // Every use of 
        // ^
        // Denotes a level up on the menu
        // ================================ //

        this.page = page
        //Toggle Side Menu in / out
        this.toggleSideMenu_button = page.locator('.oc-navbar-toggle').first()
        //
        //Logout button
        this.logout_button = page.getByRole('button', { name: 'Log Out' })
        this.confirmLogOut_button = page.getByRole('button', { name: 'Yes' })
        this.cancelLogOut_button = page.getByRole('button', { name: 'No' })
        this.loggedOut_dialog = page.getByText('Thank you for using OnCall!')
        //== menu options ==

        // == Top Level Menu ==
        // change workspace settings menu options
        this.workspaceSettings = page.locator('span').filter({ hasText: 'Workspace Settings' })
        //|
        //==>
        //Change Workspace
        this.workspaceChangeWorkspace_dropdown = page.locator('.hxgn-inner-select__indicators').first()
        this.workspaceChangeWorkspaceValue_dropdownValue = page.getByText('#workspace', { exact: true })
        this.confirmWorkspaceChange_button = page.getByRole('button', { name: 'Yes' })
        this.disregardWorkspaceChange_button = page.getByRole('button', { name: 'No' })
        //Change Layout
        //TODO add change layout options
        this.changeLayout_dropdown = page.locator('.layout-selector > div > #HxgnSelector > .hxgn-inner-select__control > .hxgn-inner-select__indicators > .hxgn-inner-select__indicator')
        this.changeLayoutValue_button = page.locator('#react-select-4-option-0')
        this.openWorkspaceNewTabs_toggle = page.locator('#menu-body').getByRole('button').filter({ hasText: /^$/ })
        // ^
        // == Top Level Menu ==
        //coverage menu option
        this.changeCoverage_dropdown = page.locator('span').filter({ hasText: 'Coverage' })
        //|
        //==>
        this.changeCoverage_button = page.getByRole('button', { name: 'Edit My Coverage' })
        // ^
        // == Top Level Menu ==
        //Preference / Settings menu options
        this.preferences_dropdown = page.getByRole('button', { name: 'Edit My Coverage' })
        //|
        //==>
        this.UISettings_dropdown = page.locator('span').filter({ hasText: 'UI Settings' })
        //TODO replace with x-path or different locator to make unique.
        this.nightMode_toggle = page.locator('.flex-row > .outer-slider')
        //Command Line Preferences menu options
        this.commandLinePrefs_dropdown = page.locator('span').filter({ hasText: 'Command Line Preferences' })
        //|
        //==>
        this.showRecentCommands_toggle = page.locator('.commandline-preferences > div > .flex-row > .outer-slider').first()
        this.showSuggestedCommands_toggle = page.locator('div:nth-child(2) > .flex-row > .outer-slider')
        this.showAssistiveColours_toggle = page.locator('div:nth-child(3) > .flex-row > .outer-slider')
        this.showCommandArguments_toggle = page.locator('div:nth-child(4) > .flex-row > .outer-slider')
        this.showHelperRow_toggle = page.locator('div:nth-child(5) > .flex-row > .outer-slider')
        // ^
        // ^
        // == Top Level Menu ==
        //Actions menu options
        this.actions_dropdown = page.locator('span').filter({ hasText: 'Actions' })
        //|
        //==>
        // == Second Level Menu ==
        // session menu options
        this.session_dropdown = page.locator('span').filter({ hasText: 'Session' })
        //|
        //==>
        this.about_dropdown = page.getByText('About...')
        this.logout_dropdown = page.locator('div').filter({ hasText: /^Log Out$/ })
        this.changePassword_dropdown = page.getByText('Change Password')
        this.changeRole_dropdown = page.getByText('Change Role')
        this.setPositionID_dropdown = page.getByText('Set Position ID')
        // ^
        // == Second Level Menu ==    
        // unit menu options
        this.unit_dropdown = page.locator('span').filter({ hasText: /^Unit$/ })
        //|
        //==>
        this.unitProperties_dropdown = page.getByText('Unit Properties')
        this.addUnitHistoryComment_dropdown = page.getByText('Add Unit History Comment')
        this.createAdHocUnitTimer_dropdown = page.getByText('Create Ad-Hoc Unit Timer')
        this.manualTimes_dropdown = page.getByText('Manual Times')
        this.transferEmployee_dropdown = page.getByText('Transfer Employee')
        this.onOff_dropdown = page.locator('span').filter({ hasText: 'On/Off' })
        // |
        // ==>
        this.logOnUnit_dropdown = page.getByText('Logon Unit')
        this.logOnGroup_dropdown = page.getByText('Logon Group')
        this.logOffUnit_dropdown = page.getByText('Logoff Unit')
        // ^
        this.assignment_dropdown = page.locator('span').filter({ hasText: 'Assignment' })
        // |
        // ==>
        this.despatchUnit_dropdown = page.getByText('Despatch Unit')
        this.despatchRVP_dropdown = page.getByText('Despatch RVP')
        this.queue_dropdown = page.locator('span').filter({ hasText: 'Queue' })
        // |
        // ==>
        this.queueIncident_dropdown = page.getByText('Queue Incident')
        this.moveToTopOfUnitsQueue_dropdown = page.getByText('Move to top of unit\'s queue')
        this.moveUpInUnitsQueue_dropdown = page.getByText('Move up in unit\'s queue')
        this.moveDownInUnitsQueue_dropdown = page.getByText('Move down in unit\'s queue')
        this.removeFromQueue_dropdown = page.getByText('Remove from Queue')
        // ^
        // status menu options
        this.status_dropdown = page.locator('span').filter({ hasText: /^Status$/ })
        // |
        // ==>
        this.acknowledge_dropdown = page.getByText('Acknowledge', { exact: true })
        this.enroute_dropdown = page.getByText('Enroute', { exact: true })
        this.atIncident_dropdown = page.getByText('At Incident')
        this.contacted_dropdown = page.locator('#menu-body').getByText('Contacted')
        this.acknowledgeRVP_dropdown = page.getByText('Acknowledge RVP')
        this.outOfService_dropdown = page.getByText('Out-of-Service')
        this.atRVP_dropdown = page.getByText('At RVP')
        this.enrouteRVP_dropdown = page.getByText('Enroute RVP')
        this.intoService_dropdown = page.getByText('Into Service')
        this.transfer_dropdown = page.getByText('Transfer', { exact: true })
        this.deassign_dropdown = page.getByText('Deassign')
        this.changeUnitStatus_dropdown = page.getByText('Change Unit Status')
        this.changeLocation_dropdown = page.getByText('Change Location')
        this.clear_dropdown = page.locator('#menu-body').getByText('Clear')
        this.fieldIncident_dropdown = page.getByText('Field Incident')
        // ^
        this.autoDespatchConfiguration_dropdown = page.getByText('Auto Despatch Configuration')
        // |
        // ==>
        this.despatchGroup_dropdown = page.locator('#menu-body').getByText('Despatch Group')
        this.incidentType_dropdown = page.getByText('Incident Type')
        this.priority_dropdown = page.locator('#menu-body').getByText('Priority')
        this.autoDespatchStatus_dropdown = page.locator('span').filter({ hasText: 'AutoDespatch Status' })
        // ^
        // ^
        // ^        
        // == Second Level Menu ==
        //Incident menu options
        this.incident_dropdown = page.locator('span').filter({ hasText: /^Incident$/ })
        // |
        // ==>
        this.SMFSelector_dropdown = page.getByText('SMF Selector')
        this.MAIT_dropdown = page.getByText('MAIT')
        this.LASRequest_dropdown = page.getByText('LAS Request')
        //Create menu options
        this.create_dropdown = page.locator('span').filter({ hasText: /^Create$/ })
        // |
        // ==>
        this.createIncident_dropdown = page.getByText('Create Incident')
        this.createfieldIncident_dropdown = page.getByText('Field Incident').nth(1)
        this.createAssociated_dropdown = page.getByText('Create Associated')
        this.createAdvised_dropdown = page.getByText('Create Advised Incident')
        this.createScheduledIncident_dropdown = page.getByText('Create Scheduled Incident')
        this.createFollowUpIncident_dropdown = page.getByText('Create Follow-Up Incident')
        this.createRVP_dropdown = page.getByText('Create RVP')
        this.copyIncident_dropdown = page.getByText('Copy Incident')
        this.createAdHocIncidentTimer_dropdown = page.getByText('Create Ad-Hoc Incident Timer')
        this.createMAIT_dropdown = page.getByText('MAIT').nth(1)
        // ^
        //modify incident menu options
        this.modify_dropdown = page.locator('span').filter({ hasText: 'Modify' })
        // |
        // ==>
        this.addRemarkToIncident_dropdown = page.getByText('Add Remark', { exact: true })
        this.addRemarkToMultipleIncidents_dropdown = page.getByText('Add Remarks To Multiple')
        this.assignResultCode_dropdown = page.getByText('Assign Result Code')
        this.changeDispositionCode_dropdown = page.getByText('Change Disposition Code')
        this.createCrossReference_dropdown = page.getByText('Create Cross Reference')
        this.crimeAllegation_dropdown = page.getByText('Crime Allegation')
        this.duplicateAndCancel_dropdown = page.getByText('Duplicate and Cancel')
        this.editScheduledIncident_dropdown = page.getByText('Edit Scheduled Incident')
        this.hold_dropdown = page.getByText('Hold')
        this.incidentRestriction_dropdown = page.getByText('Incident Restriction')
        this.incidentRouting_dropdown = page.getByText('Incident Routing')
        this.moveToUnassigned_dropdown = page.getByText('Move to Unassigned')
        this.missingPersons_dropdown = page.getByText('Missing Persons')
        this.primaryUnit_dropdown = page.getByText('Primary Unit')
        this.reopenIncident_dropdown = page.getByText('Reopen Incident')
        this.requestCADUpdate_dropdown = page.getByText('Request CAD Update')
        this.THRIVEAssessment_dropdown = page.getByText('THRIVE+ Assessment')
        this.TransfetrIncident_dropdown = page.getByText('Transfer').nth(2)
        // ^
        // Close submenu options
        this.close_dropdown = page.locator('span').filter({ hasText: /^Close$/ })
        //|
        //==>
        this.closeIncident_dropdown = page.getByText('Close').nth(1)
        this.clearIncident_dropdown = page.getByText('Clear').nth(1)
        // ^
        this.automatedWelfareChecks_dropdown = page.locator('span').filter({ hasText: 'Automated Welfare Checks' })
        //|
        //==>
        this.configureWelfareChecksUnitIncident_dropdown = page.getByText('Configure Welfare Checks (Incident/Unit)')
        this.configureWelfareChecksIncidentTypeSubType = page.getByText('Configure Welfare Checks (Incident Type/SubType)')
        // ^
        // ^    
        // ^
        // == Second Level Menu ==
        //Facility menu options
        this.facility_dropdown = page.locator('span').filter({ hasText: 'Facility' })
        //|
        //==>
        this.transportUnit_dropdown = page.getByText('Transport Unit')
        this.editTransport_dropdown = page.getByText('Edit Transport')
        // ^
        // == Second Level Menu ==
        //Inquiry menu options
        this.inquiry_dropdown = page.locator('span').filter({ hasText: 'Inquiry' })
        //|
        //==>
        this.who_dropdown = page.getByText('Who')
        this.selectIncident_dropdown = page.getByText('Select Incident', { exact: true })
        this.incidentSearch_dropdown = page.getByText('Incident Search')
        this.scheduledIncidentChronology_dropdown = page.getByText('Scheduled Incident Chronology')
        this.chronology_dropdown = page.getByText('Chronology', { exact: true })
        this.unitHistory_dropdown = page.getByText('Unit History', { exact: true })
        this.supplementalInformationSearch_dropdown = page.getByText('Supplemental Information Search')
        // ^
        // == Second Level Menu ==
        //Communications menu options
        this.communications_dropdown = page.locator('span').filter({ hasText: 'Communications' })
        //|
        //==>
        this.sendSMS_dropdown = page.getByText('Send SMS')
        this.sendEmail_dropdown = page.getByText('Send Email')
        this.majorIncidentMessaging_dropdown = page.getByText('Major Incident Messaging')
        this.externalWebsites_dropdown = page.getByText('External WebSites')
        this.lifeXCall_dropdown = page.getByText('LifeX Call Intercom')
        // ^
        // == Second Level Menu ==
        //Display menu options
        this.display_dropdown = page.locator('span').filter({ hasText: /^Display$/ })
        //|
        //==>
        this.resetMapPositionToDefault_dropdown = page.getByText('Reset Map Position to Default')
        this.resetMapViewToSaved_dropdown = page.getByText('Reset Map View to Saved')
        this.followUnit_dropdown = page.getByText('Follow Unit')
        this.generateRoute_dropdown = page.getByText('Generate Route')
        this.clearRouts_dropdown = page.getByText('Clear Routes')
        this.editUserPin_dropdown = page.getByText('Edit User Pin')
        this.deleteUserPin_dropdown = page.getByText('Delete User Pin')
        this.zoomIn_dropdown = page.getByText('Zoom In')
        this.zoomOut_dropdown = page.getByText('Zoom Out')
        // ^
        // == Second Level Menu ==
        // General Ad-Hoc Timer Menu Options
        this.generalAdHocTimer_dropdown = page.locator('span').filter({ hasText: 'General Ad-Hoc Timer' })
        //|
        //==>
        this.createGeneralAdHocTimer_dropdown = page.getByText('Create Ad-Hoc Timer')
        this.manageGeneralAdHocTimer_dropdown = page.getByText('Create Ad-Hoc Timer')
    }

    async TopLevelMenu(menu1) {
        await this.menu1.click();
    }

    async TwoLevelMenu(menu1, menu2) {
        await this.menu1.click();
        await this.menu2.click();

    }

    async ThreeLevelMenu(menu1, menu2, menu3) {
        await this.menu1.click();
        await this.menu2.click();
        await this.menu3.click();

    }

    async LogOutUser() {

        await this.toggleSideMenu_button.click();
        await this.logout_button.click();
        await this.confirmLogOut_button.click();
    }

    async ChangeWorkspace() {

        await this.workspaceChangeWorkspace_dropdown.click();
        await this.workspaceChangeWorkspaceValue_dropdownValue.click('DespASW');
        await this.confirmWorkspaceChange_button.click();
    }

    async ChangeAccessLevel() {
        await this.toggleSideMenu_button.click();
        await this.changeCoverage_dropdown.click();
        await this.changeCoverage_button.click();

    }

    async ChangePassword() {
        await this.toggleSideMenu_button.click();
        await this.actions_dropdown.click();
        await this.session_dropdown.click();
        await this.changePassword_dropdown.click();
    }

    async SetPosition(position) {
        await this.toggleSideMenu_button.click();
        await this.actions_dropdown.click();
        await this.session_dropdown.click();
        await this.changePassword_dropdown.click();
    }

    async EditUnitProperties(unitID) {
        await map.MapSearchUnit(unitID);
        await this.toggleSideMenu_button.click();
        await this.actions_dropdown.click();
        await this.unit_dropdown.click();
        await this.unitProperties_dropdown.click();


    }

    async AssignResultCode() {
        await this.toggleSideMenu_button.click();
        await this.actions_dropdown.click();
        await this.incident_dropdown.click();
        await this.modify_dropdown.click();
        await this.assignResultCode_dropdown.click();
    }
}
module.exports = { SideMenu }