import { expect } from '@playwright/test';
import { SideMenu } from '../../pages/sidemenu'

class ChangePassword{
    constructor(page)
    {
        this.page=page;
        this.page = page;
        this.changePassword_dialog = page.getByRole('button', { name: 'Change Password – × Old' })
        this.minimisedialog_button = page.getByRole('button', { name: '–', exact: true })
        this.closeDialog_button = page.getByRole('button', { name: '×', exact: true })
        this.oldPassword_textbox = page.locator('input[type="password"]').first()
        this.newPassword_textbox = page.locator('input[type="password"]').nth(1)
        this.cancel_button = page.locator('#command-dialog').getByRole('button', { name: 'Cancel' })
        this.submit_button = page.getByRole('button', { name: 'Submit', exact: true })

    }

    async ChangePassword(oldPassword, newPassword)
    {
        const Sidemenu = Sidemenu

        await Sidemenu.ChangePassword();
        await expect(this.changePassword_dialog).toBeVisible();
        await this.oldPassword_textbox.fill(oldPassword);
        await this.newPassword_textbox.fill(newPassword);
        await this.submit_button.click();

        
    }
}
module.exports = {EditAccessLevel}