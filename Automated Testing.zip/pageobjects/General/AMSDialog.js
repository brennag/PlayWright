const {test,expect} = require ('@playwright/test')
const {CommonUtils}=require('../../pageobjects/CommonUtils')
const { DialogOpen } = require('../General/DialogOpen')
const { Contactform } = require('../CreateContact/Contactform')

class AMSDialog{
    constructor(page)
    {
        this.page=page;
         this.Contactformpage = new Contactform(page);
        this.DialogOpenpage = new DialogOpen(page);
        this.CommonUtilspage= new CommonUtils(page);

        this.SearchButton = page.locator('//button[@title="Search"]');
        this.SubmitButton = page.locator('//*[text()="Submit"]');
        this.minimiseAlarmDialog_button = page.getByRole('button', { name: '–', exact: true })
        this.closeAlarmsAlarmDialog_button = page.getByRole('button', { name: '×', exact: true })
        this.URNEmpty_dialog = page.getByRole('button', { name: 'URN Not Provided – ×' })//If DialogOpen can handle this dialog, this may not be needed, need to check
        this.URNEmptyOK_button = page.getByRole('button', { name: 'OK', exact: true })
        //Need to parameterize Searchbutton, so this also can be identified.
        this.mismatchedAddress_button = page.getByRole('button', { name: 'Mismatched Address', exact: true })
        this.unknownURN_button = page.getByRole('button', { name: 'Unknown URN', exact: true })
        this.URNID_textbox = page.locator('input[name="\\(LBL_URN_ID\\)"]')
        this.alarmType_textbox = page.locator('input[name="\\(LBL_URN_ALARM_TYPE\\)"]')
        this.alarmStatus_textbox = page.locator('input[name="\\(LBL_URN_ALARM_STATUS\\)"]')
        this.alarmAddress_textbox = page.locator('input[name="\\(LBL_URN_ALARM_ADDRESS\\)"]')
        this.ARCSuppliedAlarmType_dropdown = page.locator("(//div[contains(@class,'hxgn-inner-select__value-container css-1hwfws3')])[2]")
        //this locator needs to be looked at.
        this.ARCSuppliedAlarmType_selection1 = page.locator("//div[@id='react-select-28-option-0']")
        //TODO - Option 0 - 6 to be parameterised
        this.companyName_textbox = page.locator('input[name="\\(LBL_URN_CONTACT_COMPANY\\)"]')
        this.mobile_textbox = page.locator('input[name="\\(LBL_URN_CONTACT_MOB\\)"]')
        this.number_textbox = page.locator('input[name="\\(LBL_URN_CONTACT_NO\\)"]')
        this.telephone_textbox = page.locator('input[name="\\(LBL_URN_CONTACT_TELEPHONE\\)"]')
        this.email_textbox = page.locator('input[name="\\(LBL_URN_CONTACT_EMAIL\\)"]')
        this.fax_textbox = page.locator('input[name="\\(LBL_URN_CONTACT_FAX\\)"]')
        this.AMSDialogCancel_button = page.getByRole('button', { name: 'Cancel', exact: true })
        this.AMSDialogSubmit_button = page.getByRole('button', { name: 'Submit', exact: true })
        //
    }

    URNButton = (value) => this.page.locator(`//button[@title='Select if provided Alarm Type is ${value}']`)

     
    async SelectAlarm(AlarmID, AlarmType) {
        await this.Contactformpage.AMSURNSearch.click();
        await this.page.waitForTimeout(1000);
        const isdialogopen = await this.DialogOpenpage.DialogOpen('AMS Matched URN Details', null);
        console.log(isdialogopen);
        if (isdialogopen) {
            await this.CommonUtilspage.EnterText("LBL_URN_SEARCH_ID", AlarmID);
            await this.SearchButton.click();
            await this.URNButton(AlarmType).click();
            await this.CommonUtilspage.SelectDropdownValue('(LBL_URN_ALARM_TYPE)', AlarmType);
            await this.SubmitButton.click();
            //console.log("clicked on AMS Dialog");
            await this.page.waitForTimeout(1000);
            //await expect(this.dialogtitle).toBeHidden() //checking whether URN dialog is closed
            console.log("clicked on AMS Dialog");
        }

        else {
            console.log("AMS dialog not opened");
        }
    }
}
module.exports = { AMSDialog }

