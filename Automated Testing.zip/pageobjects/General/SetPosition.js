import { expect } from '@playwright/test';
import { SideMenu } from '../../pages/sidemenu'

class SetPosition{
    constructor(page)
    {
        this.page=page;
        this.page = page;
        this.setPosition_dialog = page.getByRole('button', { name: 'Set Position ID – × Position' })
        this.minimisedialog_button = page.getByRole('button', { name: '–', exact: true })
        this.closeDialog_button = page.getByRole('button', { name: '×', exact: true })
        this.positionSelection_textbox = page.locator({className: "hxgn-inner-select__single-value"})
        this.positionSelector_dropdown = page.locator({className: "hxgn-inner-select__indicator hxgn-inner-select__dropdown-indicator"})
        //this.positionDropdown_selection = page.locator
        //({className: "hxgn-inner-select__option hxgn-inner-select__option--is-focused"})
        //this.positionSelection = page.getByRole('div', {})
        //textContent / innertext = value
        this.showAll_Checkbox = page.locator({className: "hxgn-checkbox"})
        this.cancel_button = page.locator('#command-dialog').getByRole('button', { name: 'Cancel' })
        this.submit_button = page.getByRole('button', { name: 'Submit', exact: true })

    }

    async SetPosition (position)
    {
        const Sidemenu = Sidemenu
        await Sidemenu.SetPosition();
        await expect(this.setPosition_dialog).toBeVisible();
        await 
        await this.submit_button.click();

        
    }
}
module.exports = {EditAccessLevel}