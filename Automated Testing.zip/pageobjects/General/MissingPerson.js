const { expect } = require('@playwright/test');
const { Contactform } = require('../CreateContact/Contactform')
const { DialogOpen } = require('../General/DialogOpen')

class MissingPerson{
    constructor(page)
    {
        this.page=page;
        this.Contactformpage = new Contactform(page);
        this.DialogOpenpage = new DialogOpen(page);
   // Missing Person 
    //this.missingPersonButton = this.page.locator(`(//*[@title="Missing Person"])[1]`);
    this.sexDropdowninMissingPersonDialog = this.page.locator(`//*[@list="'sex'"]//*[contains(@class,"select__dropdown")]`);
    this.useCallerAddressButton = this.page.locator(`//*[@title="Use Caller Address"]`); // Use nth() function to get the specified button while using
    this.circumstancesInputField = this.page.locator(`//*[@label="'Circumstances'"]/parent::*/parent::*/parent::*/following-sibling::*//input`);
    this.useCallerDetails = this.page.locator(`//*[@title="Use Caller Details"]`);
    this.checkboxInMissingPersonDialog = this.page.locator(`//*[text()="Initial risk identification"]/parent::*/following-sibling::*//input[@type="checkbox"]`); // Use nth() function to get the specified checkbox while using
    this.submitButton = this.page.locator(`//*[text()="Submit"]`);
    }

    inputFieldsInMissingPersonDialog = (name) => this.page.locator(`//*[@label="${name}"]/parent::*/parent::*/parent::*/following-sibling::*//input`)
    dropdownInMissingPersonDialog = (name) => this.page.locator(`//*[@label="${name}"]/parent::*/parent::*/parent::*/following-sibling::*//*[contains(@class,"select__dropdown")]`)
//common functions
clickingOnDropdowns = (value) => this.page.locator(`//*[@label="(${value})"]//*[contains(@class,"select__dropdown")]`);
validatingDialogTitle = (title) => this.page.locator(`//*[@id="command-dialog"]//*[text()="${title}"]`);
clickingOnFooterButtonInDialog = () => this.page.locator(`//*[@id="command-dialog"]//*[text()="Change Role"]/ancestor::*//*[@id="command-dialog"]//*[contains(text(),"Back")]`);
selectingText = (value) => this.page.locator(`//*[text()="${value}"]`);
clickingonDropdownUsingID = (value) => this.page.locator(`//*[@id="${value}"]//*[contains(@class,"dropdown")]`);// to use this nth(i)i.e., i= 0,1,2,3... etc should be used 
pointingInputFieldsUsingID = (value) => this.page.locator(`//*[@id="${value}"]//input`); // to use this nth(i)i.e., i= 0,1,2,3... etc should be used 
usingOnlyLabelForInput = (label) => this.page.locator(`//*[@label="${label}"]`);
selectinglocationFromDropdown = (value) => this.page.locator(`//*[@id="dialog-location-results"]//*[text()="${value}"]`)
verifyingWithTitleAttribute = (value) =>  this.page.locator(`//*[@title="${value}"]`);
    async addingTags(tags){
        await this.Contactformpage.IncidentRouting.click()
        await this.page.waitForTimeout(1000);
        const isdialogopen = await this.DialogOpenpage.DialogOpen("Incident Routing",null)
        //await this.incidentRotingButton.click();
        //await expect(this.validatingDialogTitle(`Incident Routing`)).toBeVisible();

        for(let i=0; i<tags.length;i++){
            await this.inputFieldsInMissingPersonDialog(`${tags[i]}`).nth(0).click({force: true});// The function name starts with input but here I used it for clicking checkbox
        }

        await this.submitButton.click();
        // await this.page.waitForTimeout(15000);
        // await this.incidentTagsButton.click();

        // if(await this.page.locator(`//*[contains(text(),"Show only selected")]/following-sibling::*[1]//*[@class="outer-slider active"]`).isVisible()){
        //     await this.page.locator(`//*[contains(text(),"Show only selected")]/following-sibling::*[1]//*[@class="outer-slider active"]`).click();
        //     await this.page.waitForTimeout(3000);
        //     await this.page.locator(`//*[contains(text(),"Show only selected")]/following-sibling::*[1]//*[@class="outer-slider"]`).waitFor();
        //     await this.page.locator(`//*[contains(text(),"Show only selected")]/following-sibling::*[1]//*[@class="outer-slider"]`).click();
        //     await this.page.waitForTimeout(3000);
        //     // await this.page.locator(`//*[contains(text(),"Show only selected")]/following-sibling::*[1]//*[@class="outer-slider active"]`).waitFor();
        //     // await this.page.locator(`//*[contains(text(),"Show only selected")]/following-sibling::*[1]//*[@class="outer-slider active"]`).click();
        // }
        // else if(await this.page.locator(`//*[contains(text(),"Show only selected")]/following-sibling::*[1]//*[@class="outer-slider"]`).isVisible()){
        //     await this.page.locator(`//*[contains(text(),"Show only selected")]/following-sibling::*[1]//*[@class="outer-slider"]`).click();
        //     // await this.page.waitForTimeout(3000);
        //     // await this.page.locator(`//*[contains(text(),"Show only selected")]/following-sibling::*[1]//*[@class="outer-slider active"]`).waitFor();
        //     // await this.page.locator(`//*[contains(text(),"Show only selected")]/following-sibling::*[1]//*[@class="outer-slider active"]`).click();
        // }

        // for(let i=0; i<tags.length;i++){
        //     await this.verifyingTheTags(`${tags[i]}`).nth(0).waitFor({state: 'visible', timeout: 120000});
        // }
        
    }}
    module.exports={MissingPerson}
