class GetUnitStatus{

    constructor(page)
    {
        this.page=page;
        this.UnitsTab = page.locator("li[title='Units']");
        this.SearchUnit = page.locator("input[placeholder='Search Units...']")
        this.status =page.locator("div[data-automation='header=Status']")
    }

    async getunitstatus(UnitId)
    {
        await this.UnitsTab.click()
        await this.SearchUnit.fill(UnitId)
        await this.page.waitForTimeout(2000);
        const UnitStatus = await this.status.textContent();
        console.log(UnitStatus)

        return UnitStatus;
    }
}
module.exports={GetUnitStatus}