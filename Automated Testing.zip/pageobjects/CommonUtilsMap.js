const { test, expect, mouse } = require('@playwright/test');
const { time } = require('console');


class CommonUtilsMap{
    constructor(page1) 
    {
        this.page1 = page1;
    }
    //To click on dropdowns and select a value from the list where label is the label name of dropdown and value is the value to be selected
    async SelectDropdownValue(label, Value) {
        let clickingOnDropdowns = this.page1.locator(`//*[@label="${label}"]//*[contains(@class,"select__dropdown")]`);
        await clickingOnDropdowns.click();
        await this.page1.waitForTimeout(1000);
        await this.page1.locator(`//*[starts-with(text(),'${Value}')]`).first().click();
        await this.page1.waitForTimeout(1000);
    }

    async SelectDropdownNotificationRecipient(label, value) {
        let clickingOnDropdowns = this.page1.locator(`//*[text()="${label}"]/following-sibling::*//*[contains(@class,"hxgn-inner-select__indicators")]`);
        await clickingOnDropdowns.scrollIntoViewIfNeeded();
        await this.page1.waitForTimeout(1000);
        await clickingOnDropdowns.click();
        await this.page1.waitForTimeout(1000);
        await this.page1.locator(`//*[starts-with(text(),'${value}')]`).first().click();
        await this.page1.waitForTimeout(1000);
        //TODO - validate dropdown value is populated 
    }

    async SelectDropdownGeofence(label, value) {
        let clickingOnDropdowns = this.page1.locator(`//*[text()="${label}"]/following-sibling::*//*[contains(@class,"hxgn-inner-select__indicators")]`);
        let clickonDropdownOption = this.page1.locator(`//div[@class='flex-row' and contains(., '${value}')]`).first();
        await clickingOnDropdowns.scrollIntoViewIfNeeded();
        await this.page1.waitForTimeout(1000);
        await clickingOnDropdowns.click();
        await clickonDropdownOption.click();
        await this.page1.waitForTimeout(1000);
        //TODO - validate dropdown value is populated 
    }

    async SelectDropdownGeofence2(label, value) {
        let clickingOnDropdowns = this.page1.locator(`//*[text()="${label}"]/following-sibling::*//*[contains(@class,"hxgn-inner-select__options")]`);
        let clickonDropdownOption = this.page1.locator(`//div[@class='flex-row' and contains(., '${value}')]`).first();
        await clickingOnDropdowns.scrollIntoViewIfNeeded();
        await this.page1.waitForTimeout(1000);
        await clickingOnDropdowns.click();
        await clickonDropdownOption.click();
        await this.page1.waitForTimeout(1000);
        //TODO - validate dropdown value is populated 
    }

    async SelectDropdownGeofence3(label, value) {
        let clickingOnDropdowns = this.page1.locator(`//*[text()="${label}"]/following-sibling::*//*[contains(@class,"hxgn-inner-select__indicators")]`);
        let clickonDropdownOption = this.page1.locator(`//span[normalize-space()='${value}']`);
        //let clickonDropdownOption = this.page1.locator(`span[normalize-space()='Pattern']`);
        await clickingOnDropdowns.scrollIntoViewIfNeeded();
        await this.page1.waitForTimeout(1000);
        await clickingOnDropdowns.click();
        await clickonDropdownOption.click();
        await this.page1.waitForTimeout(1000);
        //TODO - validate dropdown value is populated 
    }

    async ToggleButton(value, onOrOff) {
        
        //if on is required and on is already on, then do nothing
        if (onOrOff == "On" && await this.page1.locator(`//*[contains(text(),"${value}")]/following-sibling::*[1]//*[@class="outer-slider active"]`).isVisible()) {
            console.log(`${value} is already enabled`);
            await this.writingConsoleLogsIntoTextFile(`${value} is already enabled`)
        }
        //if off is required and off is already off, then do nothing
        else if (onOrOff == "Off" && await this.page1.locator(`//*[contains(text(),"${value}")]/following-sibling::*[1]//*[@class="outer-slider active"]`).isnotVisible()) {
            console.log(`${value} is already disabled`);
            await this.writingConsoleLogsIntoTextFile(`${value} is already disabled`)
        }
        //if on is required and is currently off, then click on it to turn it on
        else if (onOrOff == "On" && await this.page1.locator(`//*[contains(text(),"${value}")]/following-sibling::*[1]//*[@class="outer-slider"]`).isnotVisible()) {
            await this.page1.locator(`//*[contains(text(),"${value}")]/following-sibling::*[1]//*[@class="outer-slider"]`).click();
            console.log(`Enabled the ${value} toggle button`);
        }
        //if off is required and on is already on, then click on it to turn it off
        else if (onOrOff == "Off" && await this.page1.locator(`//*[contains(text(),"${value}")]/following-sibling::*[1]//*[@class="outer-slider active"]`).isVisible()) {
            await this.page1.locator(`//*[contains(text(),"${value}")]/following-sibling::*[1]//*[@class="outer-slider active"]`).click();
            console.log(`Disabled the ${value} toggle button`);
        }
    }


    //To enter text into a specific text field: label is the internal label name of text box and Value is the value to be putin the textbox
    async EnterText(label, value) {
        let inputlocator = this.page1.locator(`//input[@name="(${label})"]`);
        await inputlocator.fill(value);
    }

    async layers(layer, value1, value2, onOrOff) { // layer = Base Layers or Overlay Layers, value = Incidents, Units etc, onOrOff = On or Off
        let value;
        //await this.mapLayerButton.click();
        await this.page1.locator(`//*[text()="Layers"]`).waitFor({ state: 'visible' });
        await this.page1.locator(`//*[text()="Base Layers"]`).waitFor({ state: 'visible' });
        await this.page1.locator(`//*[text()="Overlay Layers"]`).waitFor({ state: 'visible' });

        const selectingTabLayer = (layer == 'Overlay Layers') ? 'overlay_layers' : 'base_layers'
        if (await this.page1.locator(`//*[@class="div-onetab-menu_map_${selectingTabLayer} tab-container-tab "]`).isVisible()) {
            await this.page1.locator(`//*[text()="${layer}"]`).click();
        }
        else if (await this.page1.locator(`//*[@class="div-onetab-menu_map_${selectingTabLayer} tab-container-tab tab-header-selected"]`).isVisible()) {
            await this.page1.waitForTimeout(500);
        }

        // For Clicking on dropdown button, and checking whether the dropdown is opened or not, if opened, no operation is performed, and if closed, opening the dropdown
        if (value2 != null) {
            if (await this.page1.locator(`//*[text()="${value1}"]/preceding-sibling::*[@class="ss-expander"]`).isVisible()) {
                await this.page1.locator(`//*[text()="${value1}"]/preceding-sibling::*[@class="ss-expander"]`).click();
                // TODO - reintroduce this code.
                // await expect.soft(this.page1.locator(`//*[text()="Map Utilities"]/preceding-sibling::*[@class="ss-expander ss-rotate"]`)).toBeVisible();
            }
            else if (await this.page1.locator(`//*[text()="${value1}"]/preceding-sibling::*[@class="ss-expander ss-rotate"]`).isVisible()) {
                await expect(this.page1.locator(`//*[text()="Map Utilities"]/preceding-sibling::*[@class="ss-expander ss-rotate"]`)).toBeVisible();
            }
            value = value2
        }
        else if (value2 == null) {
            value = value1
        }
        //TODO - validate the layer is present in the list
        
        // Clicking on toggle button
        if (onOrOff == "On" && await this.page1.locator(`//*[contains(text(),"${value}")]/following-sibling::*[1]//*[@class="outer-slider"]`).isVisible()) {
            await this.page1.locator(`//*[contains(text(),"${value}")]/following-sibling::*[1]//*[@class="outer-slider"]`).click();
            console.log(`Enabled the ${value} in the Map Layers`);
            //await this.writingConsoleLogsIntoTextFile(`Enabled the ${value} in the Map Layers`, null)
        }
        else if (onOrOff == "Off" && await this.page1.locator(`//*[contains(text(),"${value}")]/following-sibling::*[1]//*[@class="outer-slider active"]`).isVisible()) {
            await this.page1.locator(`//*[contains(text(),"${value}")]/following-sibling::*[1]//*[@class="outer-slider active"]`).click();
            console.log(`Disabled the ${value} in the Map Layers`);
            //await this.writingConsoleLogsIntoTextFile(`Disabled the ${value} in the Map Layers`, null)
        }
        else if (onOrOff == "On" && await this.page1.locator(`//*[contains(text(),"${value}")]/following-sibling::*[1]//*[@class="outer-slider active"]`).isVisible()) {
            console.log(`${value} is already enabled in the Map Layers`);
            //await this.writingConsoleLogsIntoTextFile(`${value} is already enabled in the Map Layers`, null)
        }
        else if (onOrOff == "Off" && await this.page1.locator(`//*[contains(text(),"${value}")]/following-sibling::*[1]//*[@class="outer-slider"]`).isVisible()) {
            console.log(`${value} is already disabled in the Map Layers`);
            //await this.writingConsoleLogsIntoTextFile(`${value} is already disabled in the Map Layers`, null)
        }
        await this.page1.waitForTimeout(10000);
        //await this.page1.waitForLoadState('networkidle', { timeout: 200000 });
        await this.validatingTheImagesForTheLayers(value1, value2);
    }

    async validatingTheImagesForTheLayers(value1, value2) {
        let value = value2 != null ? value2 : value1;
        await this.page1.waitForLoadState('networkidle', { timeout: 200000 });
        if (value == 'Incidents' || value == 'Units') {
            let count = 0
            const valueImg = value == 'Incidents' ? 'events' : 'units'
            const url = value1 == "Special Situations" ? `//*[@class="leaflet-marker-icon ss-map-icon leaflet-zoom-animated leaflet-interactive"]` : `//*[contains(@src,"https://metps-dispatch.hexagonsi.com/oncall/Images/${valueImg}/")]`
            const similarTexts = await this.page1.$$(url)
            await this.page1.waitForLoadState('networkidle', { timeout: 200000 });
            if (similarTexts.length == 0) {
                console.log(`The ${value.toLowerCase()} are not present on the map`);
            }
            else if (similarTexts.length > 0) {
                for (let i = 0; i < similarTexts.length; i++) {
                    let image = await this.page1.locator(url).nth(i);
                    if (image.isVisible()) {
                        await expect.soft(image).toBeAttached();
                        await image.waitFor({ state: 'visible' });
                        await image.waitFor({ state: 'visible' });
                        count += 1;
                    }
                }
                console.log(`${count} are the ${value.toLowerCase()} are attached & visible`)
            }
        }
        else if (value == "Map Utilities") {
            await this.page1.locator(`//*[@class="leaflet-pane leaflet-overlay-pane"]/child::*[1]//*[@class="leaflet-interactive"]`).nth(0).waitFor({ state: 'visible' });
            await this.page1.locator(`//*[@class="leaflet-pane leaflet-overlay-pane"]/child::*[1]//*[@class="leaflet-interactive"]`).nth(1).waitFor({ state: 'visible' });
            await this.page1.locator(`//*[@title="Turn on Measuring Tool"]`).waitFor({ state: 'visible' });
            await this.page1.locator(`//*[@title="Clear Measurements"]`).waitFor({ state: 'visible' });
        }
    }


    //To navigate between tabs (i.e. Incidents, Units)
    SwitchingTabs = (value) => this.page1.locator(`//*[@title="${value}"]`);

    //To navigate between tab buttons (saved filter columns)
    SwitchingTabButton = (value) => this.page1.locator(`//*[@data-testid="tab-button" and @title="${value}"]`);

}
module.exports = { CommonUtilsMap }