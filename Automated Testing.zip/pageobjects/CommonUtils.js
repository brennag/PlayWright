class CommonUtils{
    constructor(page)
    {
        this.page=page;
    }
    //To click on dropdowns and select a value from the list where label is the label name of dropdown and value is the value to be selected
    async SelectDropdownValue(label,Value)
    {
        let clickingOnDropdowns = this.page.locator(`//*[@label="${label}"]//*[contains(@class,"select__dropdown")]`);
        await clickingOnDropdowns.click();
        await this.page.waitForTimeout(1000);
        await this.page.locator(`//*[starts-with(text(),'${Value}')]`).first().click();
        await this.page.waitForTimeout(1000);
    }
    //Function to be used on ARC dialog ONLY
    async SelectARCDropdownValue(label,Value)
    {
        let clickingOnDropdowns = this.page.locator(`//*[@label="${label}"]//*[contains(@class,"k-select")]`);
        await clickingOnDropdowns.click();
        await this.page.waitForTimeout(1000);
        await this.page.locator(`//*[starts-with(text(),'${Value}')]`).first().click();
        await this.page.waitForTimeout(1000);
    }
    
    //To enter text into a specific text field: label is the internal label name of text box and Value is the value to be putin the textbox
    async EnterText(label,value){
        let inputlocator = this.page.locator (`//input[@name="(${label})"]`);
        //await expect(inputlocator).tobevisible();
        await inputlocator.fill(value);
    }

    async SwitchToMapPage(){
        const context = this.page.context();
        const pages = context.pages();
        console.log("Total Pages: ", pages.length);
        // Get the second page (the map page)
        const page1 = context.pages()[1]; 
        await page1.bringToFront(); // Bring the map page to the front 
        // Reinitialize Mappage with the new page
        
    }


    //To navigate between tabs (i.e. Incidents, Units)
    SwitchingTabs = (value) => this.page.locator(`//*[@title="${value}"]`);

    //To navigate between tab buttons (saved filter columns)
    SwitchingTabButton = (value) => this.page.locator(`//*[@data-testid="tab-button" and @title="${value}"]`);

    //To Handle new page opening
    async documentLink(appbutton){
        const [newPage] = await Promise.all([ this.page.waitForEvent('popup', { timeout: 60000 }), appbutton.click() ]);
                    await newPage.waitForLoadState('domcontentloaded', { timeout: 120000 });
                    const newPageUrl = newPage.url();
                    console.log(`New page URL : `, newPageUrl)
                    return { newPage, newPageUrl };
    }
    async DatePickerCalendar(year,Month,Date)// year in 'YYYY', Month in 'M' format, Date in 'D' format :: like (2025,7,4)
    {
        // await this.page.locator("//select[@class='react-datepicker__year-select']").click()
        // await this.page.locator(`//option[text()='${year}']`).click()
        // await this.page.locator("//select[@class='react-datepicker__month-select']").click()
        // await this.page.locator(`//option[text()='${Month}']`).click()
        await this.page.selectOption(`//select[@class='react-datepicker__year-select']`, { value: `${year}`});
        await this.page.selectOption(`//select[@class='react-datepicker__month-select']`, { value: `${Number(Month)-1}` });
        await this.page.locator(`//*[contains(@class, 'react-datepicker__day') and text()='${Date}']`).first().click()
    }
    async offsetDateTime( { years = 0, months = 0, days = 0, hours = 0, minutes = 0, seconds = 0 }={}) 
    {
        const currentDate = new Date();  // Create a copy of the input date to avoid mutating the original one
    
        // Apply the offsets
        currentDate.setFullYear(currentDate.getFullYear() + years);
        currentDate.setMonth(currentDate.getMonth() + months);
        currentDate.setDate(currentDate.getDate() + days);
        currentDate.setHours(currentDate.getHours() + hours);
        currentDate.setMinutes(currentDate.getMinutes() + minutes);
        currentDate.setSeconds(currentDate.getSeconds() + seconds);
    
        
        const offsetyear =currentDate.getFullYear()
        const offsetmonth = currentDate.getMonth()+1
        const offsetday = currentDate.getDate()
        const offsetHrs = currentDate.getHours().toString().padStart(2, '0');
        const offsetmin= currentDate.getMinutes().toString().padStart(2, '0');
        const offsetsec = currentDate.getSeconds().toString().padStart(2, '0');
        return {currentDate,offsetyear,offsetmonth,offsetday,offsetHrs,offsetmin,offsetsec};
    }

    async DismissAllNotifications(Mappage)
    {
        //Dismiss all notifications
        if(await Mappage.locator(`//*[@id="ui-notifications-area"]`).isVisible())
        {

            await Mappage.getByRole('button', { name: 'Dismiss All' }).click();
            await Mappage.evaluate(() => {
            const notifications = document.querySelectorAll('.ui-notification-wrapper');
            notifications.forEach(notification => notification.remove());
            });
         }
}}
module.exports ={CommonUtils}