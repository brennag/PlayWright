const { error, time } = require("console");
const { test, expect, mouse, keyboard } = require('@playwright/test');
const { Map } = require('./Map');
const { CommonUtilsMap } = require('../CommonUtilsMap');
const exp = require("constants");


class GeoFence extends Map {
    constructor(page1) {
        super(page1)
        this.page1 = page1;
        this.CommonUtilsMappage = new CommonUtilsMap(page1);
        //TODO - generalise buttons, checkboxes, dropdowns, etc. to use common utils functions
        this.button = page1.getByRole('button', { name: "${buttonName}" }, { exact: true })
        this.checkbox = page1.getByRole('checkbox', { name: "${checkboxName}" }, { exact: true })

        this.mapToolGeofences_button = page1.locator("//button[contains(@title,'Geofences')]")
        this.geofence_dialog = page1.locator("//div[@class='geofence-popover shift-right-with-normal-map-icon map-left-popover-panel cd-tabbable-panel']")
        this.geofenceEditor_dialog = page1.locator("//div[@class='geofence-editor-panel cd-tabbable-panel']")
        this.openGeofenceEditor_button = page1.getByRole('button', { name: 'Open Editor' })
        this.closeGeofenceEditorDialog_button = page1.getByText('X', { exact: true })
        this.geofenceSettings_button = page1.locator('div').filter({ hasText: /^Geofence EditorX$/ }).locator('div').nth(3)
        //||
        //==>
        this.showlabelsOfShapes_toggle = page1.locator('div').filter({ hasText: /^Show Labels of Shapes$/ }).getByRole('button')
        this.showAllGeofences_toggle = page1.locator('div').filter({ hasText: /^Show All Geofences$/ }).getByRole('button')
        this.opacityGeofences_slider = page1.locator("//div[@class='rc-slider opacity-slider']")
        this.opacitySliderBoundary_rail = page1.locator("//div[contains(@class,'rc-slider-rail')]")
        this.opacityGeofence_sliderhandle = page1.locator("//div[@class='rc-slider-handle']")
        this.opacityGeofence_sliderhandleFocus = page1.locator("//div[@class='rc-slider-handle rc-slider-handle-click-focused']")
        this.opacityValue_text = page1.locator("//output[normalize-space()]")
        this.showActiveGeofences_toggle = page1.locator('div').filter({ hasText: /^Show Only Active Geofences$/ }).getByRole('button')
        this.groupByGraphicsTemplate_toggle = page1.locator('div').filter({ hasText: /^Group By Graphic Template$/ }).getByRole('button')
        //^
        this.searchGeofence_textbox = page1.locator("(//input[@placeholder='Search Geofence...'])[1]")
        this.geofence_list = page1.locator('.geofence-search')
        this.searchGeofence_icon = page1.locator('.search-bar-search-icon')
        this.geofenceList_button = page1.locator("//span[@class='geofence-label']")
        this.createGeofence_button = page1.getByText('Create Geofence')
        this.updatedGeofence_burgermenu = page1.locator("(//div[@class='hamburger-slider cd-tabbable '])")
        this.editGeofence_button = page1.getByText('Edit', { exact: true })
        this.notificationSettings_button = page1.getByText('Notification Settings', { exact: true })
        //||
        //==>
        //Notification dialog settings    
        this.incidentCreation_checkbox = page1.locator("(//div[@class='hxgn-checkbox cd-tabbable'])[1]")
        this.unitEnter_checkbox = page1.locator("(//div[@class='hxgn-checkbox cd-tabbable'])[2]")
        this.unitExit_checkbox = page1.locator("(//div[@class='hxgn-checkbox cd-tabbable'])[3]")
        this.submit_button = page1.getByRole('button', { name: 'Submit', exact: true })
        this.genericGeofence_notification = page1.locator("(//div[@class='ui-notification-content flex-col flex-grow'])")
        this.geofence_notification = page1.locator('#ui-notifications-area div').filter({ hasText: 'SHARED TASK ALERT Geofence' }).first()
        this.geofenceIncidentInside_notification = page1.locator("(//div[@class='ui-notification-content flex-col flex-grow'])").filter({ hasText: 'Incident ID = MPS' }).first()
        this.geofenceUnitEntered_notification = page1.locator("(//div[@class='ui-notification-content flex-col flex-grow'])").filter({ hasText: 'entered geofence' }).first()
        this.geofenceUnitExited_notification = page1.locator("(//div[@class='ui-notification-content flex-col flex-grow'])").filter({ hasText: 'exited geofence' }).first()
        //^    
        this.deleteGeofence_button = page1.getByText('Delete', { exact: true })
        this.confirmDeleteGeofence_dialog = page1.getByText('Do you want to delete Geofence?OkCancel')
        this.ok_button = page1.getByRole('button', { name: 'OK' })

        //||
        //==>
        this.geofenceName_textbox = page1.locator("//input[@id='fenceName']")
        this.geofenceDescription_textbox = page1.locator("//input[@id='fenceDescription']")
        this.geofenceAgencies_dropdown = page1.locator("(//*[name()='path'])[23]")
        this.geogenceAgencyValue_textbox = page1.locator('.flex-col > div > #HxgnSelector > .hxgn-inner-select__control > .hxgn-inner-select__value-container').first()
        this.geofenceAgenciesdropdown_selection = page1.getByText('MPS', { exact: true })
        this.geofenceDespatchGroup_textbox = page1.locator(`//*[text()="Despatch Groups"]/following-sibling::*//*[contains(@class,"hxgn-inner-select__value-container")]`)
        //||
        //==>
        //Generic button for shape, save and cancel
        //this.geofenceOperation_button = page1.locator(`//button[@id="${label}"]`) //'label_polygon', 'label_circle', 'label_rectangle', 'fence_cancel', 'fence_save'
        this.geofenceShapeCircle_button = page1.getByRole('button', { name: 'Circle' })
        this.geofenceShapePolygon_button = page1.getByRole('button', { name: 'Polygon' })
        this.geofenceShapeRectangle_button = page1.getByRole('button', { name: 'Rectangle' })

        this.saveGeofence_button = page1.getByRole('button', { name: 'Save Geofence' })
        this.cancelGeofence_button = page1.getByRole('button', { name: 'Cancel' })
        this.geofenceDuplicateID_dialog = page1.getByRole('heading', { name: 'Duplicate geofence ID found.' })
        //send message to units dialog
        this.sendMessageToUnits_dialog = page1.locator("//div[@class='send-message-dialog react-dragable-dialog flex-col cd-tabbable-dialog react-draggable react-draggable-dragged']//div[@class='dialog-header flex-row flex-justify-space-between']")

        this.sendMessageToUnits_button = page1.getByText('Send Message to Units', { exact: true })
        this.recipients_list = page1.locator("//div[@class='selected-recipients-list flex-row']")
        this.subject_textbox = page1.locator("//input[@id='msg-subject']")
        this.messageBody_textbox = page1.locator("//textarea[@id='msg-text']")
        this.attachMedia_button = page1.locator("//img[@class='add-icon cd-tabbable']")
        this.sendMessage_button = page1.getByRole('button', { name: 'Send Message' })


    }

    async OpenGeofenceDialog() {
        await this.mapToolGeofences_button.click();
        await expect(this.geofence_dialog).toBeVisible();
        console.log("Geofences panel is visible");
    }

    //Geofence Dialog functions
    //TODO change showhide to toggle active / inactive
    //fence-name = 
    //check class = active - <div class="outer-slider active" xpath="1">
    async ToggleAllGeofences(state) {
        await this.CommonUtilsMappage.ToggleButton("Show All Geofences", state);
        await this.page1.waitForTimeout(2000);
    }

    async ToggleGeofenceLabels(state) {
        await this.CommonUtilsMappage.ToggleButton("Show Labels of Shapes", state);
        await this.page1.waitForTimeout(2000);
    }

    async ToggleGeofenceStrokes(state) {
        await this.CommonUtilsMappage.ToggleButton("Show Strokes of Shapes", state);
        await this.page1.waitForTimeout(2000);
    }

    async ToggleGeofenceState(state) {
        await this.CommonUtilsMappage.ToggleButton("Geofencename", state);
        await this.page1.waitForTimeout(2000);
    }

    async ChangeOpacityGeofence(geofence, opacity) {
        await this.mapToolGeofences_button.click();
        await expect(this.geofence_dialog).toBeVisible();
        console.log("Geofences panel is visible");
        await this.searchGeofence_textbox.click();
        await this.searchGeofence_textbox.fill(geofence);
        await this.searchGeofence_textbox.press('Enter');
        //check if geofence is visible in the list
        await this.page1.waitForTimeout(2000);
        await this.opacityGeofences_slider.click();
        await this.page1.waitForTimeout(2000);
        //set opacity to 0%
        await this.opacityGeofence_sliderhandle.dragTo(this.opacityGeofence_sliderhandle, { force: true, targetPosition: { x: 0, y: 0 } });
        //move opacity slider to user defined value
        await this.opacityGeofence_sliderhandle.dragTo(this.opacityGeofence_sliderhandle, { force: true, targetPosition: { x: 0, y: opacity } });
        await this.page1.waitForTimeout(2000);
        console.log("Geofence opacity changed to: " + opacity + "%");
    }



    async SetOpacityLevelWithKeyboard(geofence, desiredOpacity) {

        await this.mapToolGeofences_button.click();
        await expect(this.geofence_dialog).toBeVisible();
        console.log("Geofences panel is visible");
        // Search for geofence in the list
        await this.searchGeofence_textbox.click();
        await this.searchGeofence_textbox.fill(geofence);
        await this.searchGeofence_textbox.press('Enter');
        await this.page1.waitForTimeout(2000);
        const currentOpacity = await this.opacityValue_text.innerText();
        const currentOpacityNum = parseInt(currentOpacity.replace("%", ""));
        console.log("Current opacity is: " + currentOpacity);
        // check if current percentage meets expected
        if (currentOpacityNum == desiredOpacity) {
            console.log("Current opacity is equal to desired opacity. No need to change.");
            return;
        }
        // else, begin loop
        else {
            console.log("Current opacity is not equal to desired opacity. Need to change.");
            // move slider to the far left (using keyboard) until the percentage meets 0% (maximum 10 times)
            for (let i = 0; i < 10; i++) {
                // select slider
                await this.opacityGeofence_sliderhandle.focus();
                await this.opacityGeofence_sliderhandle.press('ArrowLeft')
                const newOpacity = await this.opacityValue_text.innerText();
                const newOpacityNum = parseInt(newOpacity.replace("%", ""));
                console.log("New opacity is: " + newOpacity);
                if (newOpacityNum == 0) {
                    break;
                }
            }
            // move slider to the right (using keyboard) until the percentage meets % (again max 10 times)
            for (let i = 0; i < 10; i++) {
                // select slider
                const newOpacity = await this.opacityValue_text.innerText();
                const newOpacityNum = parseInt(newOpacity.replace("%", ""));
                if (newOpacityNum == desiredOpacity) {
                    break;
                }
                await this.opacityGeofence_sliderhandle.focus();
                await this.opacityGeofence_sliderhandle.press('ArrowRight')
                console.log("New opacity is: " + newOpacity);
            }
        }
    }

    async SetOpacityLevelWithMouse(geofence, desiredOpacity) {
        // Open correct pop up - Geofence
        //const mousemoves = desiredOpacity / 10;
        await this.mapToolGeofences_button.click();
        await expect(this.geofence_dialog).toBeVisible();
        console.log("Geofences panel is visible");
        // Search for geofence in the list
        await this.searchGeofence_textbox.click();
        await this.searchGeofence_textbox.fill(geofence);
        await this.searchGeofence_textbox.press('Enter');
        // Check if geofence is visible in the list
        await this.page1.waitForTimeout(2000);
        //TODO convert currentopcaity to number, do the same for target
        const currentOpacity = await this.opacityValue_text.innerText();
        //curently failing here - reports null value.
        console.log("Current opacity is: " + currentOpacity + "%");
        const boundingBox = opacitySliderBoundary_rail.boundingBox();

        // check if current percentage meets expected
        if (currentOpacity == desiredOpacity) {
            console.log("Current opacity is equal to desired opacity. No need to change.");
            return;
        }
        // else, begin loop
        else {
            console.log("Current opacity is not equal to desired opacity. Need to change.");
            // move slider (using mouse) until the percentage meets target 
            await this.opacityGeofence_sliderhandle.click();
            //drag and drop function
            /*
            await page.mouse.move(dragBoundingBox.x + dragBoundingBox.width / 2, dragBoundingBox.y + dragBoundingBox.height / 2);
            await page.mouse.down();
            const targetX = targetPosition?.x || dropBoundingBox.x + dropBoundingBox.width / 2;
            const targetY = targetPosition?.y || dropBoundingBox.y + dropBoundingBox.height / 2;
            await page.mouse.move(targetX, targetY);
            await page.mouse.up();
            await dragAndDrop(this.opacityGeofence_sliderhandle, { x: sliderBoundingBox.width * desiredOpacity, y: 0 });
            //end of drag and drop function
            */

            const newOpacity = await this.opacityValue_text.innerText();
            console.log("New opacity is: " + newOpacity + "%");
        }

    }





    //TODO include common utils to confirm dialogs are open
    async OpenGeofenceEditor() {
        if (this.geofence_dialog.isVisible()) {
            await this.openGeofenceEditor_button.click();
            await expect(this.geogenceEditor_dialog).toBeVisible();
            console.log("Geofence Editor is visible");
        }
        else {
            await this.mapToolGeofences_button.click();
            await expect(this.geofence_dialog).toBeVisible();
            console.log("Geofences panel is visible");
            await this.openGeofenceEditor_button.click();
            await expect(this.geogenceEditor_dialog).toBeVisible();
            console.log("Geofence Editor is visible");
        }

    }


    //Geofence Editor functions

    async UpdateGeofenceDescription(description) {
        await this.updatedGeofence_burgermenu.click();
        await this.editGeofence_button.click();
        await this.geofenceDescription_textbox.fill(description);
        console.log("Geofence description updated to: " + description);
        await this.saveGeofence_button.click();
        await expect(this.genericGeofence_notification.filter({ hasText: 'Geofence updated successfully' }).first()).toBeVisible();
    }

    async UpdateGeofenceStyle(style, value) {
        //For use with Line Type, Fill Type, Line Weight.
        await this.updatedGeofence_burgermenu.click();
        await this.editGeofence_button.click();
        await this.CommonUtilsMappage.SelectDropdownGeofence(style, value);
        console.log("Geofence " + style + " updated to: " + value);
        await this.saveGeofence_button.click();
        await expect(this.genericGeofence_notification.filter({ hasText: 'Geofence updated successfully' }).first()).toBeVisible();
    }

    async UpdateGeofenceStyle2(style, value) {
        //For use with Fill Pattern, Line Colour, Fill Colour.
        await this.updatedGeofence_burgermenu.click();
        await this.editGeofence_button.click();
        let clickingOnDropdowns = this.page1.locator(`//*[text()="${style}"]/following-sibling::*//*[contains(@class,"graphic--arrow--zone")]`);
        await clickingOnDropdowns.click();
        await this.page1.locator(`//div[@title='${value}']`).first().click();
        console.log("Geofence " + style + " updated to: " + value);
        await this.saveGeofence_button.click();
        await expect(this.genericGeofence_notification.filter({ hasText: 'Geofence updated successfully' }).first()).toBeVisible();
    }

    async UpdateGeofenceStyle3(style, value) {
        //For use with Fill Type.
        await this.updatedGeofence_burgermenu.click();
        await this.editGeofence_button.click();
        await this.CommonUtilsMappage.SelectDropdownGeofence3(style, value);
        console.log("Geofence " + style + " updated to: " + value);
        await this.saveGeofence_button.click();
        await expect(this.genericGeofence_notification.filter({ hasText: 'Geofence updated successfully' }).first()).toBeVisible();
    }

    async UpdateGeofenceStyle4(style, value) {
        //For use with Fill Pattern style.
        await this.updatedGeofence_burgermenu.click();
        await this.editGeofence_button.click();
        let clickingOnDropdowns = this.page1.locator(`//*[text()="${style}"]/following-sibling::*//*[contains(@class,"graphic--arrow--zone")]`);
        await clickingOnDropdowns.click();
        await this.page1.locator(`//td[@title="${value}"]//div[@class='flex-row ']//*[name()='svg']//*[contains(@class,'hbar thing')]`).first().click();
        console.log("Geofence " + style + " updated to: " + value);
        await this.saveGeofence_button.click();
        await expect(this.genericGeofence_notification.filter({ hasText: 'Geofence updated successfully' }).first()).toBeVisible();
    }

    async DeleteGeofenceFromEditor(uniqueGeofenceName) {
        //search for geofence in the list
        await this.searchGeofence_textbox.click();
        await this.searchGeofence_textbox.fill(uniqueGeofenceName);
        await this.searchGeofence_textbox.press('Enter');
        //check if geofence is visible in the list
        await this.page1.waitForTimeout(2000);
        await expect(this.geofenceList_button).toBeVisible();
        await expect(this.geofenceList_button).toHaveText(uniqueGeofenceName);
        //click on the geofence in the list
        await this.geofenceList_button.click()
        //Update and Delete geofence from editor
        await this.updatedGeofence_burgermenu.click();
        await this.deleteGeofence_button.click();
        await this.confirmDeleteGeofence_dialog.click();
        await this.ok_button.click();
        await expect(this.genericGeofence_notification.filter({ hasText: 'Geofence deleted successfully' }).first()).toBeVisible();
        await expect(this.geofenceList_button).not.toBeVisible();
        console.log("Geofence " + uniqueGeofenceName + " deleted successfully from editor");
    }

    async OpenGeofenceEditor() {
        await this.mapToolGeofences_button.click();
        await expect(this.geofence_dialog).toBeVisible();
        console.log("Geofences panel is visible");
        await this.openGeofenceEditor_button.click();
        await expect(this.geofenceEditor_dialog).toBeVisible();
        console.log("Geofence Editor is visible");
    }

    //END OF EDIT GEFENCE FUNCTIONS


    async CreateGeoFenceStart(gefenceID, description) {
        await this.mapToolGeofences_button.click();
        await expect(this.geofence_dialog).toBeVisible();
        console.log("Geofences panel is visible");
        await this.openGeofenceEditor_button.click();
        await expect(this.geofenceEditor_dialog).toBeVisible();
        console.log("Geofence Editor is visible");
        await this.createGeofence_button.click();
        await this.geofenceName_textbox.fill(gefenceID);
        await this.geofenceDescription_textbox.fill(description);
        await this.geogenceAgencyValue_textbox.click();
        await this.geofenceAgenciesdropdown_selection.click();
    }

    async GeofencePanelFail() {
        await expect(this.mapToolGeofences_button).toHaveCount(0);
        console.log("Geofence map button is NOT visible");

    }

    async GeofenceEditorFail() {
        await this.mapToolGeofences_button.click();
        await expect(this.geofence_dialog).toBeVisible();
        console.log("Geofences panel is visible");
        await this.openGeofenceEditor_button.toHaveCount(0);
        console.log("Geofence Editor button is NOT visible");
    }

    async SelectDropdown(label, value) {
        let clickingOnDropdowns = this.page1.locator(`//*[text()="${label}"]/following-sibling::*//*[contains(@class,"hxgn-inner-select__indicators")]`);
        await clickingOnDropdowns.click();
        await this.page1.waitForTimeout(1000);
        await this.page1.locator(`//*[starts-with(text(),'${value}')]`).first().click();
        await this.page1.waitForTimeout(1000);
    }

    async SelectDGs(label, value1, value2, value3) {
        let clickingOnDropdowns = this.page1.locator(`//*[text()="${label}"]/following-sibling::*//*[contains(@class,"hxgn-inner-select__value-container hxgn-inner-select__value-container--is-multi")]`);
        await clickingOnDropdowns.click();
        await this.page1.waitForTimeout(1000);
        await this.page1.locator(`//*[starts-with(text(),'${value1}')]`).first().click();
        await this.page1.waitForTimeout(1000);
        await clickingOnDropdowns.click();
        await this.page1.waitForTimeout(1000);
        await this.page1.locator(`//*[starts-with(text(),'${value2}')]`).first().click();
        await this.page1.waitForTimeout(1000);
        await clickingOnDropdowns.click();
        await this.page1.waitForTimeout(1000);
        await this.page1.locator(`//*[starts-with(text(),'${value3}')]`).first().click();
        await this.page1.waitForTimeout(1000);
        console.log("Despatch groups selected: " + value1 + ", " + value2 + ", " + value3);
    }

    async SelectDownArrow(style, value) {
        let clickingOnDropdowns = this.page1.locator(`//*[text()="${style}"]/following-sibling::*//*[contains(@class,"graphic--arrow--zone")]`);
        await clickingOnDropdowns.click();
        await this.page1.waitForTimeout(1000);
        await this.page1.locator(`//div[@title='${value}']`).first().click();
        await this.page1.waitForTimeout(1000);

    }


    async CreatePolygonGeofence(context) {
        const { PageObjects } = require('../../pageobjects/PageObjects');
        const page1 = context.pages()[1];
        const Mappage = new PageObjects(page1).Mappage;
        for (let i = 0; i < 10; i++) {
            const alertCount = await Mappage.sharedTask_alert.count();
            if (alertCount === 0) {
                break;
            }
            await Mappage.dismissSharedTasks_button.click();
            console.log("No Alerts Present");
        }
        await this.geofenceShapePolygon_button.click();
        await this.page1.mouse.click(550, 300);
        await this.page1.mouse.click(650, 300);
        await this.page1.mouse.click(650, 500);
        await this.page1.mouse.click(500, 500);
        await this.page1.mouse.click(550, 300);
        await this.page1.mouse.click(650, 300);
        console.log("Polygon geofence created successfully");
    }

    async CreateCircleGeofence() {
        /*
        const { PageObjects } = require('../../pageobjects/PageObjects');
        const page1 = context.pages()[1];
        const Mappage = new PageObjects(page1).Mappage;

        for (let i = 0; i < 10; i++) {
            const alertCount = await Mappage.sharedTask_alert.count();
            if (alertCount === 0) {
                break;
            }
            await Mappage.dismissSharedTasks_button.click();
            console.log("No Alerts Present");
        }
            */
        await this.geofenceShapeCircle_button.click();
        //cursor changes to crosshair, but does not draw circle when above code is included to look for alerts
        //TODO - await crosshair to appear before clicking
        await this.page1.waitForTimeout(2000);
        await this.map_container.click();
        await this.map_container.dragTo(this.map_container, {
            force: true,
            sourcePosition: { x: 550, y: 300 },
            targetPosition: { x: 650, y: 500 },
        });

        console.log("Circle geofence created successfully");
    }


    async CreateRectangleGeofence() {
        /*
        const { PageObjects } = require('../../pageobjects/PageObjects');
        const page1 = context.pages()[1];
        const Mappage = new PageObjects(page1).Mappage;

        for (let i = 0; i < 10; i++) {
            const alertCount = await Mappage.sharedTask_alert.count();
            if (alertCount === 0) {
                break;
            }
            await Mappage.dismissSharedTasks_button.click();
            console.log("No Alerts Present");
        }
        */
       await this.page1.waitForTimeout(2000);
        await this.geofenceShapeRectangle_button.click();
        await this.map_container.click();
        await this.map_container.dragTo(this.map_container, {
            force: true,
            sourcePosition: { x: 550, y: 300 },
            targetPosition: { x: 650, y: 500 },
        });
        console.log("Rectangle geofence created successfully");
    }

    async SaveGeofence(context, uniqueGeofenceName) {
        const { PageObjects } = require('../../pageobjects/PageObjects');
        const page1 = context.pages()[1];
        const Mappage = new PageObjects(page1).Mappage;

        for (let i = 0; i < 10; i++) {
            const alertCount = await Mappage.sharedTask_alert.count();
            if (alertCount === 0) {
                break;
            }
            await Mappage.dismissSharedTasks_button.click();
            console.log("No Alerts Present");
        }

        //included check for task alert recap notifications.
        for (let i = 0; i < 10; i++) {
            const alertCount = await Mappage.taskAlertRecap_alert.count();
            if (alertCount === 0) {
                break;
            }
            await Mappage.dismissAllTasks_button.click();
            console.log("No Alerts Present");
        }

        await expect(this.saveGeofence_button).toBeVisible();
        await this.saveGeofence_button.waitFor({ state: 'visible', timeout: 20000 });
        await this.saveGeofence_button.click();
        await expect(this.genericGeofence_notification.filter({ hasText: 'Geofence created successfully' }).first()).toBeVisible();
        console.log("Geofence " + uniqueGeofenceName + " saved successfully");
    }

    //Search for Geofence in Geofence popup
    async SearchGeofence(genfenceID) {
        // Open correct pop up - Geofence
        await this.mapToolGeofences_button.click();
        await expect(this.geofence_dialog).toBeVisible();
        console.log("Geofences panel is visible");
        // Search for geofence in the list
        await this.searchGeofence_textbox.click();
        await this.searchGeofence_textbox.fill(genfenceID);
        await this.searchGeofence_textbox.press('Enter');
        // Check if geofence is visible in the list
        await this.page1.waitForTimeout(2000);
        console.log("Geofence searched successfully with name: " + genfenceID);
    }
    //Search for Geofence in Geofence editor popup
    async SearchGeofenceInEditor(genfenceID) {
        await this.searchGeofence_textbox.click();
        await this.searchGeofence_textbox.fill(genfenceID);
        await this.searchGeofence_textbox.press('Enter');
        //check if geofence is visible in the list
        await this.page1.waitForTimeout(2000);
        await expect(this.geofenceList_button).toBeVisible();
        await expect(this.geofenceList_button).toHaveText(genfenceID);
        //click on the geofence in the list
        await this.geofenceList_button.click();
        await this.page1.waitForTimeout(2000);
        console.log("Geofence searched successfully with name: " + genfenceID);
    }

    async GeofenceVisibleOnMap(uniqueGeofenceName) {
        const geofenceOnMap_img = this.page1.locator(`//*[local-name() = 'div'][starts-with(@class,'leaflet-tooltip') and contains(@class,'leaflet-zoom-animated leaflet-tooltip') and contains(normalize-space(.), ${uniqueGeofenceName})]`);
        expect(geofenceOnMap_img.getByText(uniqueGeofenceName)).toBeVisible();
        console.log("Geofence " + uniqueGeofenceName + " is visible on map");
    }

    //right click on geofence to open context menu
    async RightClickOnGeofence(geofenceName) {
        await this.page1.mouse.click(550, 300, { button: 'right' });
        await this.page1.waitForTimeout(2000);
        const contextMenu = this.page1.locator(`//*[local-name() = 'div'][starts-with(@class,'leaflet-tooltip') and contains(@class,'leaflet-zoom-animated leaflet-tooltip') and contains(normalize-space(.), ${geofenceName})]`);
        await expect(contextMenu).toBeVisible();
        console.log("Right click on geofence " + geofenceName + " successful");
    }

    //select context menu option from geofence context menu
    async SelectContextMenuOption(option) {
        //await this.page1.locator("//div[@class='hxgn-menu-item']").filter({ hasText: 'Send Message to Units' }).click();
        const contextMenuOption = this.page1.locator(`//*[local-name() = 'div'][starts-with(@class,'leaflet-tooltip') and contains(@class,'leaflet-zoom-animated leaflet-tooltip') and contains(normalize-space(.), ${option})]`);
        await contextMenuOption.click();
        console.log("Context menu option " + option + " selected successfully");
    }

    //file path must be passed as parameter like this example;;
    //'C:/PlayWright/Automated Testing/tests/tests_GB/starwars.txt'
    async SendMessageToUnits(genfenceID, unitID, subject, message, filePath, context) {
        //confirm "Send Message" dialog is open
        await expect(this.sendMessageToUnits_dialog).toBeVisible();
        //check if unit is visible in the list
        await expect(this.recipients_list).toHaveText(unitID);
        await this.subject_textbox.fill(subject);
        await this.subject_textbox.press('Enter');
        await this.messageBody_textbox.fill(message);
        await this.messageBody_textbox.press('Enter');
        //add attachment
        await this.attachMedia_button.click({ force: true, noWaitAfter: true });
        //changed from page0
        const page1 = context.pages()[1];
        const [fileChooser] = await Promise.all([
            page1.waitForEvent('filechooser'),
            await this.AddAttachmentButton.click({ force: true, noWaitAfter: true }),
        ]);
        await fileChooser.setFiles(filePath);
        const attachButton = page1.getByRole('button', { name: 'Attach', exact: true });
        await attachButton.click({ force: true, noWaitAfter: true });

        this.sendMessage_button
    }



    async GetAttributes(element) {
        const attributes = await element.evaluate((el) => {
            const attrs = {};
            for (let i = 0; i < el.attributes.length; i++) {
                const attr = el.attributes[i];
                attrs[attr.name] = attr.value;
            }
            return attrs;
        });
        console.log(attributes);
        return attributes;
    }

    async SetAllGeofenceNotifications(gefenceID, recipients) {
        await this.searchGeofence_textbox.click();
        await this.searchGeofence_textbox.fill(gefenceID);
        await this.searchGeofence_textbox.press('Enter');
        //check if geofence is visible in the list
        await this.page1.waitForTimeout(2000);
        await expect(this.geofenceList_button).toBeVisible();
        await expect(this.geofenceList_button).toHaveText(gefenceID);
        //click on the geofence in the list
        await this.geofenceList_button.click();
        await this.page1.waitForTimeout(2000);
        //Update and DElete geofence from editor
        await this.updatedGeofence_burgermenu.click();
        await this.notificationSettings_button.click();
        await this.page1.waitForTimeout(2000);
        await this.incidentCreation_checkbox.click();
        await this.unitEnter_checkbox.click();
        await this.unitExit_checkbox.click();
        //failed to set recipients.
        await this.CommonUtilsMappage.SelectDropdownNotificationRecipient("Notification Recipients", recipients);
        await this.submit_button.click();
    }

    async CheckGeofenceNotification(notificationText, genfenceID, incidentID) {
        await expect.soft(this.genericGeofence_notification.filter({ hasText: notificationText }).first()).toBeVisible();
    }

    async CheckIncidentNotification(notificationText, incidentID) {
        await expect.soft(this.genericGeofence_notification.filter({ hasText: notificationText }).first()).toBeVisible();
    }




}
module.exports = { GeoFence }