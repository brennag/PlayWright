const { error } = require("console");
const { test, expect } = require('@playwright/test');
const { Map } = require('./Map');
const { CommonUtilsMap } = require("../CommonUtilsMap");

class MapLayers extends Map {
    constructor(page1) {
        super(page1)
        this.page1 = page1;
        this.CommonUtilsMappage = new CommonUtilsMap(page1);
        this.mapPage = new Map(page1);
        this.layerSearch_searchbox = page1.getByRole('searchbox', { name: 'Layer Search...' })
        this.layerSearch_icon = page1.locator('div').filter({ hasText: /^Base LayersOverlay Layers\|\|OS Maps - Light\|\|OS Roads\|\|OS Maps - Outdoor$/ }).getByRole('img')
        this.layerSaveChanges_button = page1.getByRole('button', { name: 'Save Changes' })
        this.layerRestoreDefaults_button = page1.getByRole('button', { name: 'Restore DefaultsRestore' })
        this.baseLayers_tab = page1.getByText('Base Layers')
        //||
        //==>
        this.osMapsLight_toggle = page1.getByRole('listitem').filter({ hasText: '||OS Maps - Light' }).getByRole('button')
        this.osRoads_toggle = page1.getByRole('listitem').filter({ hasText: '||OS Roads' }).getByRole('button')
        this.osMapsOutdoor_toggle = page1.getByRole('listitem').filter({ hasText: '||OS Maps - Outdoor' }).getByRole('button')
        //^
        this.overlayLayers_tab = page1.getByText('Overlay Layers')
        //||
        //==>
        this.incidentsLayer_toggle = page1.getByRole('listitem').filter({ hasText: '||(Incidents)' }).getByRole('button')
        this.unitsLayer_toggle = page1.getByRole('listitem').filter({ hasText: '||Units' }).getByRole('button')
        this.personLayer_toggle = page1.getByRole('listitem').filter({ hasText: '||Persons' }).getByRole('button')
        this.RVPLayer_toggle = page1.getByRole('listitem').filter({ hasText: '||Persons' }).getByRole('button')
        this.specialSituations_toggle = page1.getByRole('listitem').filter({ hasText: '||Special' }).getByRole('button')
        this.expandSpecialSituations_expander = page1.locator('div').filter({ hasText: /^\|\|Special Situations$/ }).locator('div').first()
        //||
        //==>
        this.specialSituationsPolygons_radiobutton = page1.locator('label').filter({ hasText: 'Polygons' })
        this.specialSituationsPoints_radiobutton = page1.locator('label').filter({ hasText: 'Points' })
        this.specialSituationsBoth_radiobutton = page1.locator('label').filter({ hasText: 'Both' })
        this.specialSituations_slidertrack = page1.locator('.rc-slider-track')
        this.specialSituations_slider = page1.getByRole('slider')
        this.specialSituationSlider_handle = page1.locator("//div[@class='rc-slider-handle']")
        this.opacityValue_text = page1.locator("//output[normalize-space()]")
        //^
        this.mapUtilities_toggle = page1.getByRole('listitem').filter({ hasText: '||(Map Utilities)' }).getByRole('button')
        this.mapUtilities_expander = page1.getByRole('listitem').filter({ hasText: '||(Map Utilities)' }).locator('div').nth(1)
        //||
        //==>
        this.minimap_toggle = page1.getByRole('listitem').filter({ hasText: '||(MiniMap)' }).getByRole('button')
        this.coordinates_toggle = page1.getByRole('listitem').filter({ hasText: '||(Coordinates)' }).getByRole('button')
        this.measuringTool_toggle = page1.getByRole('listitem').filter({ hasText: '||(MeasuringTool)' }).getByRole('button')
        this.page1Numbers_toggle = page1.getByRole('listitem').filter({ hasText: '||(MeasuringTool)' }).getByRole('button')
        //^
        this.pointsOfInterest_toggle = page1.getByRole('listitem').filter({ hasText: '||(Points of Interest)' }).getByRole('button')
        this.pointsOfInterest_expander = page1.getByRole('listitem').filter({ hasText: '||(Points of Interest)' }).locator('div').nth(1)
        //||
        //==>
        this.userPins_toggle = page1.getByRole('listitem').filter({ hasText: '||(UserPins)' }).getByRole('button')
        this.policeStations_toggle = page1.getByRole('listitem').filter({ hasText: '||(Police Stations)' }).getByRole('button')
        this.RNLIStations_toggle = page1.getByRole('listitem').filter({ hasText: '||(RNLI stations)' }).getByRole('button')
        this.LFBStations_toggle = page1.getByRole('listitem').filter({ hasText: '||(LFB Stations)' }).getByRole('button')
        this.TFLStations_toggle = page1.getByRole('listitem').filter({ hasText: '||(TFL stations)' }).getByRole('button')
        this.communityCentres_toggle = page1.getByRole('listitem').filter({ hasText: '||(Community Centres)' }).getByRole('button')
        this.placesOfWorship_toggle = page1.getByRole('listitem').filter({ hasText: '||(Places of Worship)' }).getByRole('button')
        this.primarySchools_toggle = page1.getByRole('listitem').filter({ hasText: '||(Primary Schools)' }).getByRole('button')
        this.secondarySchools_toggle = page1.getByRole('listitem').filter({ hasText: '||(Secondary Schools)' }).getByRole('button')
        this.prisons_toggle = page1.getByRole('listitem').filter({ hasText: '||(Prisons)' }).getByRole('button')
        this.hospitals_toggle = page1.getByRole('listitem').filter({ hasText: '||(Hospitals)' }).getByRole('button')
        this.defibrillator_toggle = page1.getByRole('listitem').filter({ hasText: '||(Defibrillator)' }).getByRole('button')
        this.petrolStations_toggle = page1.getByRole('listitem').filter({ hasText: '||(Petrol stations)' }).getByRole('button')
        //^
        this.MPSBoundaries_toggle = page1.getByRole('listitem').filter({ hasText: '||(MPS Boundaries)' }).getByRole('button')
        this.MPSBoundaries_expander = page1.getByRole('listitem').filter({ hasText: '||(MPS Boundaries)' }).locator('div').nth(1)
        //||
        //==>
        this.MPSBoroughs_toggle = page1.getByRole('listitem').filter({ hasText: '||(MPS Boroughs)' }).getByRole('button')
        this.MPSWards_toggle = page1.getByRole('listitem').filter({ hasText: '||(MPS Wards)' }).getByRole('button')
        this.MPSScottisRaSP_toggle = page1.getByRole('listitem').filter({ hasText: '||(MPS Scottish RaSP)' }).getByRole('button')
        this.MPSBCUSectors_toggle = page1.getByRole('listitem').filter({ hasText: '||(MPS BCU Sectors)' }).getByRole('button')
        this.MPSBCUs_toggle = page1.getByRole('listitem').filter({ hasText: '||(MPS BCUs)' }).getByRole('button')
        this.PBOCU_toggle = page1.getByRole('listitem').filter({ hasText: '||(PBOCU (Aviation/Parks/' }).getByRole('button')
        this.townCentres_toggle = page1.getByRole('listitem').filter({ hasText: '||(Town Centres)' }).getByRole('button')
        this.CoLPWardClusters_toggle = page1.getByRole('listitem').filter({ hasText: '||(CoLP Ward Clusters)' }).getByRole('button')
        this.CoLPWards_toggle = page1.getByRole('listitem').filter({ hasText: '||(CoLP Wards)' }).getByRole('button')
        //^
        this.emergencyService_toggle = page1.getByRole('listitem').filter({ hasText: '||(Emergency Service' }).getByRole('button')
        this.emergencyService_expander = page1.getByRole('listitem').filter({ hasText: '||(Emergency Service' }).locator('div').nth(1)
        //||
        //==>
        this.UKPoliceForce_toggle = page1.getByRole('listitem').filter({ hasText: '||(UK Police Force)' }).getByRole('button')
        this.UKAmbulance_toggle = page1.getByRole('listitem').filter({ hasText: '||(UK Ambulance)' }).getByRole('button')
        this.UKFire_toggle = page1.getByRole('listitem').filter({ hasText: '||(UK Fire)' }).getByRole('button')
        //^
        this.traffic_toggle = page1.getByRole('listitem').filter({ hasText: '||(Traffic)' }).getByRole('button')
        this.traffic_expander = page1.getByRole('listitem').filter({ hasText: '||(Traffic)' }).locator('div').nth(1)
        //||
        //==>
        this.redRoutes_toggle = page1.getByRole('listitem').filter({ hasText: '||(Red Routes)' }).getByRole('button')
        this.trimbleTraffic_toggle = page1.getByRole('listitem').filter({ hasText: '||(TRIMBLE TRAFFIC)' }).getByRole('button')
        this.motorwayMarkerPosts_toggle = page1.getByRole('listitem').filter({ hasText: '||(Motorway Marker Posts)' }).getByRole('button')
        this.fastRoads_toggle = page1.getByRole('listitem').filter({ hasText: '||(Fast Roads)' }).getByRole('button')
        //^
        this.CCTV_toggle = page1.getByRole('listitem').filter({ hasText: '||(CCTV)' }).getByRole('button')
        this.CCTV_expander = page1.getByRole('listitem').filter({ hasText: '||(CCTV)' }).locator('div').nth(1)
        //||
        //==>
        this.MPSCCTV_toggle = page1.getByRole('listitem').filter({ hasText: '||(MPS CCTV)' }).getByRole('button')
        //^
        this.emergencyCalls_toggle = page1.getByRole('listitem').filter({ hasText: '||(Emergency Calls)' }).getByRole('button')
        this.scheduledIncidents_toggle = page1.getByRole('listitem').filter({ hasText: '||(Scheduled Incidents)' }).getByRole('button')
        //^
    }

    async switchLayer(layer, alternateSliderCaption, sliderCaption, onOrOff) {
        await this.mapPage.mapToolLayers_button.click();
        await this.CommonUtilsMappage.layers(layer, alternateSliderCaption, sliderCaption, onOrOff);
        await this.mapPage.mapToolLayers_button.click();
    }

    async SetLayerOpacityLevel(layer, alternateSliderCaption, sliderCaption, onOrOff, desiredOpacity) {
        await this.mapPage.mapToolLayers_button.click();
        await this.CommonUtilsMappage.layers(layer, alternateSliderCaption, sliderCaption, onOrOff);
        await this.page1.waitForTimeout(2000);
        const currentOpacity = await this.opacityValue_text.innerText();
        const currentOpacityNum = parseInt(currentOpacity.replace("%", ""));
        console.log("Current opacity is: " + currentOpacity);
        // check if current percentage meets expected
        if (currentOpacityNum == desiredOpacity) {
            console.log("Current opacity is equal to desired opacity. No need to change.");
            return;
        }
        // else, begin loop
        else {
            console.log("Current opacity is not equal to desired opacity. Need to change.");
            // move slider to the far left (using keyboard) until the percentage meets 0% (maximum 10 times)
            for (let i = 0; i < 10; i++) {
                // select slider
                await this.specialSituationSlider_handle.focus();
                await this.specialSituationSlider_handle.press('ArrowLeft')
                const newOpacity = await this.opacityValue_text.innerText();
                const newOpacityNum = parseInt(newOpacity.replace("%", ""));
                console.log("New opacity is: " + newOpacity);
                if (newOpacityNum == 0) {
                    break;
                }
            }
            // move slider to the right (using keyboard) until the percentage meets % (again max 10 times)
            for (let i = 0; i < 10; i++) {
                // select slider
                const newOpacity = await this.opacityValue_text.innerText();
                const newOpacityNum = parseInt(newOpacity.replace("%", ""));
                if (newOpacityNum == desiredOpacity) {
                    break;
                }
                await this.specialSituationSlider_handle.focus();
                await this.specialSituationSlider_handle.press('ArrowRight')
                console.log("New opacity is: " + newOpacity);
            }
        }
        await this.mapPage.mapToolLayers_button.click();
    }
}
module.exports = { MapLayers }