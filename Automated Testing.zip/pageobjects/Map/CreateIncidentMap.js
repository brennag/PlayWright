const { error } = require("console");
const { test, expect, mouse } = require('@playwright/test');
const { Map } = require('./Map');
const { CommonUtilsMap } = require('../CommonUtilsMap');
const exp = require("constants");

class CreateIncidentMap extends Map {

    constructor(page1)
    {
        super(page1)
        this.page1=page1;
        this.CommandLine =page1.locator("[title='Command Line']");
        this.InputCommand =page1.getByPlaceholder('Command Line...');
        this.AttendanceLocation =page1.locator("[ID='LOCATION-INPUT-FIELD'] input").first()
        this.IncidentLocation = page1.locator("[ID='LOCATION-INPUT-FIELD'] input").nth(1)
        this.locationsearch =page1.locator(".location-result").first();
        this.CallerName= page1.locator("[name='(LBL_Caller_Name)']");
        this.IncidentType =page1.locator("angwrap-dialog-event-type-selector[name='(LBL_Incident_Type)'] input").first();
        this.IncidentSubtype =page1.locator("angwrap-dialog-event-type-selector[name='(LBL_Subtype)'] input").first();
        this.Submit_Button = page1.locator(".btn.btn-primary.submit-btn.cd-tabbable.ng-binding")
        //TODO - add has text "Incident ID = MPS" to locator 
        this.IncidentCreated_notification = page1.locator("//div[@class='ui-notification-body shortened']").first();
        

    }


    async CreateInc(address, CallerName, IncidentType)
    {
        await this.CommandLine.click();
        await this.InputCommand.fill('Create Incident');
        await this.page1.keyboard.press('Enter')
        await this.AttendanceLocation.fill(address);
        await this.locationsearch.click();
        await this.IncidentLocation.fill(address);
        await this.locationsearch.click();
        await this.CallerName.fill(CallerName);
        await this.IncidentType.fill(IncidentType);
        //await this.IncidentSubType.fill(IncidentSubType);
        await this.page1.waitForTimeout(2000);
        await this.page1.keyboard.press("Enter");
        await this.Submit_Button.click();
        await expect(this.IncidentCreated_notification).toBeVisible();
        const fullIncidentID = await this.IncidentCreated_notification.innerText();
        // maybe ("Success Incident ID = " + incidentID) - 21
        const incidentID = fullIncidentID.slice(14);
        console.log("Incident Created with ID: " + incidentID);
        
    }

}
module.exports={CreateIncidentMap};
