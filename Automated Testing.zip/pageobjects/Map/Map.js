//This class is to have all the locators from map page1 

const { expect } = require("playwright/test")

class Map {
    constructor(page1) {
        // Store test data for the map postcodes
        this.postcodeTestData = new Array();
        //Locators within the page1
        this.page1 = page1
        //buttons along the top
        //this.getStartedLink = page1.locator('a', { hasText: 'Get started' });
        this.mappage1Title = page1.getByTitle("Map - HxGN OnCall® Despatch")
        this.map_tab = page1.getByRole('button', { name: 'Map', exact: true })
        this.sharedTask_alert = page1.getByText("SHARED TASK ALERT").first()
        this.taskAlertRecap_alert = page1.getByText("Task Alert recap").first()
        this.dismissSharedTasks_button = page1.getByText('Dismiss', { exact: true })
        this.dismissAllTasks_button = page1.getByRole('button', { name: 'Dismiss All' })
        this.mapSideMenu_navbar = page1.locator('.oc-navbar-toggle').first()
        this.mapSOPs_button = page1.getByRole('button', { name: 'SOPs' })
        this.mapCommandline_button = page1.getByRole('button', { name: 'Command Line' })  // Select again to close
        this.mapCommandLineInput_textbox = page1.getByRole('textbox', { name: 'Command Line...' }) // Enter commands here
        this.mapAdHocTimers_button = page1.getByRole('button', { name: 'Ad-Hoc Timers' })
        this.mapFeeds_button = page1.getByRole('button', { name: 'Feeds' })
        this.mapContactDirectory_button = page1.getByRole('button', { name: 'Contact Directory' })
        this.mapHelp_button = page1.getByRole('button', { name: '' })
        this.mapNotifications_button = page1.getByRole('button', { name: ' ' })
        this.mapAbout_button = page1.getByRole('button', { name: 'About' })
        this.mapCommandLineInput_textbox = page1.getByRole('textbox', { name: 'Command Line...' })
        //the actual map layer
        //this.map_container = page1.locator('.map-container')
        this.map_container = page1.locator(`//div[contains(@class,'map-container')]`)
        this.ll_text = page1.locator(`//input[@class='form-control cd-tabbable ng-pristine ng-valid ng-not-empty ng-valid-required ng-touched']`).nth(0);
        this.en_text = page1.locator(`//input[@class='form-control cd-tabbable ng-pristine ng-valid ng-not-empty ng-valid-required ng-touched']`).nth(1);
        //map tools
        this.mapToolSearch_icon = page1.getByTitle('Map Search').getByRole('img')
        //||
        //==>
        this.mapSearch_textbox = page1.getByRole('search', { name: 'Search...' })
        this.locationSearchResult_textbox = page1.locator("//*[contains(@class,'result-address-row')]")
        this.locationMapPinResult_textbox = page1.locator("//*[contains(@class,'result-name')]").first()
        this.locationMap_icon = page1.locator("//*[contains(@class,'leaflet-marker-icon leaflet-zoom-animated leaflet-interactive").getByRole('img')
        this.unitSearchresult_icon = page1.getByText('#unitID')
        this.policeStation_icon = page1.locator("//img[@class='icon-image-small']")
        this.policeStationIcon_Callout = page1.locator("//span[@class='icon-id-inner']")
        this.CCTV_icon = page1.locator("//img[@class='icon-image-small']")
        this.CCTVIcon_Callout = page1.locator("//div[@class='icon-id']")
        //^
        this.mapToolLayers_button = page1.getByRole('button', { name: 'Map Layers' })
        this.mapToolGeofences_button = page1.getByRole('button', { name: 'Geofences' })
        this.mapToolgraphics_button = page1.getByRole('button', { name: 'Map Graphics' })
        this.mapToolZoom_button = page1.getByRole('button', { name: 'Area Zoom' })
        //Filter map notifications
        this.mapDismissAllNotifications_button = page1.getByRole('button', { name: 'Dismiss All' })
        this.mapShowAllUnitsAndIncidents_button = page1.getByRole('button', { name: 'Show All' })
        this.mapDismissShowAllUnitsAndIncidents_button = page1.getByText('Dismiss', { exact: true })
        // List of Unit specific icons 
        this.mapUnit_icon = page1.locator('#Unit').getByRole('img').first()
        this.mapUnitGroup_icon = page1.locator('div').filter({ hasText: /^#numberOfUnits$/ }).locator('div').nth(1)  //<div class="cluster-hitbox"></div>
        this.mapUnitStatusAvailable_icon = page1.locator('#unitid').getByTitle('Available').getByRole('img')  //status value = available, 
        this.mapUnitStatusAtIncident_icon = page1.locator('div').filter({ hasText: /^#unit$/ }).getByRole('img').nth(1)  //status value = At Incident
        this.mapUnitStatusDespatched_icon = page1.getByTitle('Despatched', { exact: true }).getByRole('img')
        // unit context menu options available via right click
        this.mapUnitContext_menu = page1.getByRole('link', { name: '#menuoption' })          //menu options = 'Edit Unit Properties',  'Call PtP', 'Enable Person Level Tracking', 'Despatch', 'Field Incident', 'Out-of-Service', 'More Options', 'Manage Ad-Hoc Timers', 'Create Ad-Hoc Timer', 'Despatch RVP' , 'At Incident', 'Enroute',  'Acknowledge',  'Clear' 
        this.mapUnitContextOuter_menu = page1.locator('#outer-layer').getByRole('link', { name: 'More Options' })
        // List of Incident specific icons
        this.mapIncident_icon = page1.locator(`//div[@id='MPS20211007000016']//img[@class='icon-image-small']`)
        this.mapIncidentGroup_icon = page1.locator('div').filter({ hasText: /^#numberOfIncidents$/ }).locator('div').nth(1)  //<div class="cluster-hitbox"></div>
        // incident context menu options available via right click
        this.mapIncidentSelect_icon = page1.getByRole('link', { name: 'Select Incident' })
        this.mapIncidentDespatch_icon = page1.getByRole('link', { name: 'Despatch' })
        this.mapIncidentEdit_icon = page1.getByRole('link', { name: 'Edit' })
        this.mapIncidentAddRemarks_icon = page1.getByRole('link', { name: 'Add Remarks' })
        this.mapIncidentClose_icon = page1.getByRole('link', { name: 'Close' })
        this.mapIncidentMore_icon = page1.getByRole('link', { name: 'More Options' })
        this.mapIncidentDrawGraphics_icon = page1.getByRole('link', { name: 'Draw Graphics' })
        this.mapIncidentRVP_Icon = page1.getByRole('link', { name: 'Create RVP' })
        this.mapIncidentCreateAdHocTimer_icon = page1.getByRole('link', { name: 'Create Ad-Hoc Timer' })
        this.mapIncidentManageRVPs_icon = page1.getByRole('link', { name: 'Manage RVPs' })
        this.mapIncidentHold_icon = page1.getByRole('link', { name: 'Hold' })


        
    }

    // The third parameter, reinitialise, is optional.  Set to true if it needs to re-read the
    // same or a different file of data.
    async GetRandomPostcode(filepath, filename, requiredDGroups = [], reinitialise = false) {
        // If it has no data stored, or it needs to be reinitialised...
        if ( this.postcodeTestData.length == 0 || reinitialise)
        {
            const fs = require('fs');
            const path = require('path');
            const { parse } = require('csv-parse/sync');
            const csvFullFileName = path.join(path.join(__dirname, filepath), filename);
            const csvData = fs.readFileSync(csvFullFileName, 'utf8');
            this.postcodeTestData = parse(csvData, { columns: true });
            const rowCount = this.postcodeTestData.length;
            console.log(`Number of rows in ${filename}: ${rowCount}`);
        }
 
        let postcodeSubset = new Array();

        if (requiredDGroups.length > 0)
        {
            // Using 'filter' to extract only those rows that have a desired DGroup.  'dataRow' is an iterator for each row in the test data.
            // => means, for each dataRow run this code.  => is a shorthand function definition.
            postcodeSubset = this.postcodeTestData.filter(dataRow => requiredDGroups.indexOf(dataRow.DispatchGroup) >= 0);
        }
        else
        {
            postcodeSubset = this.postcodeTestData;
        }

        if (postcodeSubset.length == 0)
        {
            console.log("No suitable postcode rows found");
            return "";
        }

        const randomRowIndex = Math.floor(Math.random() * (postcodeSubset.length - 1));
        const randomRow = postcodeSubset[randomRowIndex];
        const randomPostcode = randomRow.Postcode;
        console.log(`Random Postcode: ${randomPostcode}`);

        return randomPostcode;
    }

    async MapSearchAddress(address) {
        await this.mapToolSearch_icon.click();
        await this.mapSearch_textbox.click();
        await this.mapSearch_textbox.fill(address);
        const searchTextResult = await this.locationSearchResult_textbox.first();
        const searchLocator = await searchTextResult.locator("//*[contains(@class,'result-address')]");
        const searchResult = await searchLocator.innerText().toString();
        await searchTextResult.click();
        console.log(`Address: ${searchResult}`);
        await this.mapToolSearch_icon.click();
        return searchResult;
    }

    async MapSearchPin(address) {
        await this.mapToolSearch_icon.click();
        await this.mapSearch_textbox.click();
        await this.mapSearch_textbox.fill(address);
        await this.locationMapPinResult_textbox.click();
        await this.mapToolSearch_icon.click();
    }

    async awaitAlerts() {
        await this.sharedTask_alert.waitFor({ state: 'visible' });
        await expect (this.sharedTask_alert).toHaveCount(0);
        //await this.sharedTask_alert.waitFor({ state: 'hidden' });
        await this.dismissSharedTasks_button.click();
        await this.dismissAllTasks_button.click();
    }

    async rightClickMapIncidentIcon(incident) {
        await this.mapIncident_icon.click({ button: 'right' });
        await this.mapIncidentAddRemarks_icon.click();
    }

    async rightClickMapUnitIcon(unit, menuitem) {
        await this.mapUnit_icon.click(unit);
        await this.mapUnit_icon.click({ button: 'right' });
        await this.mapUnitContext_menu.click({ menuitem });
    }
    async mappage1Present() {
        await expect(this.mappage1Title).toBeVisible();
    }

    async MapSearchUnit(unitID) {
        await this.mapToolSearch_icon.click();
        await this.mapSearch_textbox.click();
        await this.mapSearch_textbox.click();
        await this.mapSearch_textbox.fill(unitID);
        await this.locationMapPinResult_textbox.click();
        await this.unitSearchresult_icon.click();
    }

    async MapSearchIncident(Incident) {
        await this.mapToolSearch_icon.click();
        await this.mapSearch_textbox.click();
        await this.mapSearch_textbox.type(Incident,{ delay: 1000 });
        //Failing here, no results are being presented on the search, may need to introduce further delays?
        await this.page1.waitForTimeout(2000);
        await this.locationMapPinResult_textbox.click();
        await this.page1.waitForTimeout(2000);
        await this.mapToolSearch_icon.click();
        console.log("Incident located on map");
    }

    //todo: generalise for any map icon
    async selectMapPin(title) {
        const mapIcon = this.page1.locator(`//*[contains(@class,'map-marker') and contains(@title,'${title}')]`).getByRole('img');
        await mapIcon.click();
        await expect(mapIcon).toBeVisible();
    }

    async verifyPoliceStationIcon(title) {
        await expect(this.policeStation_icon).toBeVisible();
        await expect(this.policeStationIcon_Callout).toContainText(title);
    }

    async verifyCCTVIcon(title) {
        await expect(this.CCTV_icon).toBeVisible();
        await expect(this.CCTVIcon_Callout).toContainText(title);
    }




   //SearchResult = (value) => this.page1.getByText(`${searchtext}`)

}
module.exports = { Map }