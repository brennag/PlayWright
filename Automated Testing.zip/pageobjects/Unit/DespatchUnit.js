const{appendToLogFile}=require('../../tests/testlogs')
const{CommonUtils} =require('../CommonUtils')
const{DialogOpen}=require('../General/DialogOpen')
const{GetUnitFilterResults}=require('./GetUnitFilterResults')

class DespatchUnit{
    constructor(page)
    {
        this.page = page;
        this.CommonUtilspage = new CommonUtils(page)
        this.DialogOpenpage = new DialogOpen(page)
        this.GetUnitFilterResultspage= new GetUnitFilterResults(page)
        this.UnitsTab = page.locator("li[title='Units']");
        this.SubmitBtn = page.locator("//*[contains(@class,'btn btn-primary submit-btn cd')]")
    }

    async DespatchUnit(UnitId,IncidentId)
    {
        await this.UnitsTab.click();
        await this.DialogOpenpage.DialogOpen(`Despatch Unit`,'DESPATCH UNIT')
        if(UnitId){
            await this.CommonUtilspage.SelectDropdownValue('(lbl_despatch_unit_units)',UnitId)
        }
        if(!UnitId){
            await this.page.locator(`//*[@label="(lbl_despatch_unit_units)"]//*[contains(@class,"select__dropdown")]`).click()
            //selecting the first available unit if unit not provided
            await this.page.locator(`(//*[contains(@id,"-option-0")])[1]`).click()
            await this.page.waitForTimeout(1000)
            UnitId=await this.page.locator(`//*[@label="(lbl_despatch_unit_units)"]//*[contains(@class,'hxgn-inner-select__single-value')]`).textContent()
            // console.log(UnitId)

        }

        await this.CommonUtilspage.SelectDropdownValue('(lbl_despatch_unit_incident_id)',IncidentId)
        await this.CommonUtilspage.SelectDropdownValue('(lbl_despatch_unit_despatch_type)','Normal')
        await this.SubmitBtn.click()
        await this.page.waitForTimeout(5000)
       
        //Checking whether dialog closed
        if(!await this.DialogOpenpage.DialogOpen('Despatch Unit',null)){
            console.log(`Despatch Unit dialog closed successfully`)
            let unitstatus = await this.GetUnitFilterResultspage.getUnitStatus(UnitId)
            if(unitstatus=='Despatched'){
                appendToLogFile(`Pass: Unit '${UnitId}' despatched successfully for incident '${IncidentId}'`)
                return [UnitId,unitstatus];
            }
            else{
                appendToLogFile(`Fail:Unit '${UnitId}' NOT despatched`)
                return false;
            }

        }
        
        else{
            appendToLogFile(`Fail: Despatch Unit dialog NOT closed successfully`)
            return false;
        }
    }
}
module.exports ={DespatchUnit};
