const{CommonUtils} =require('../CommonUtils')
const{DialogOpen}=require('../General/DialogOpen')
const{GetUnitFilterResults}=require('./GetUnitFilterResults')
const{appendToLogFile}=require('../../tests/testlogs')

class AcknowledgeUnit{
    constructor(page){
        this.page=page;
        this.CommonUtilspage = new CommonUtils(page)
        this.DialogOpenpage = new DialogOpen(page)
        this.GetUnitFilterResultspage= new GetUnitFilterResults(page)
        this.UnitsTab = page.locator("li[title='Units']");
        this.SubmitBtn = page.locator("//*[contains(@class,'btn btn-primary submit-btn cd')]")
    }

    async acknowledgeunit(UnitId,Incident_Id,Mileage,Comment)
    {
        await this.UnitsTab.click();
        await this.DialogOpenpage.DialogOpen(`Acknowledge Unit`,'ACKNOWLEDGE UNIT')
        if(UnitId){
            await this.CommonUtilspage.SelectDropdownValue('(LBL_ACKUNIT_UNITID)',UnitId)
            let incidentid_ack=await this.page.locator(`//*[@label="(LBL_ACKUNIT_INCIDENTID)"]//*[contains(@class,'hxgn-inner-select__single-value')]`).textContent()
            if(incidentid_ack==Incident_Id){
                console.log(`IncidentID which is assigned to the Unit is automatically selected.`)
            }
            else{
                console.log(`IncidentID which is assigned to the Unit is NOT automatically selected.`)
            }
            if(Mileage){
                await this.CommonUtilspage.EnterText(`LBL_ACKUNIT_MILEAGE`,Mileage)
            }
            if(Comment){
                await this.CommonUtilspage.EnterText(`LBL_ACKUNIT_COMMENT`,Comment)
            }
            await this.SubmitBtn.click()
            await this.page.waitForTimeout(5000)

            //Checking whether dialog closed & Validation whether unit status changed
            if(!await this.DialogOpenpage.DialogOpen('Acknowledge Unit',null)){
                console.log(`Acknowledge Unit dialog closed successfully`)
                let unitstatus = await this.GetUnitFilterResultspage.getUnitStatus(UnitId)
                if(unitstatus=='Acknowledge'){
                    appendToLogFile(`Pass:Unit '${UnitId}' Acknowledged successfully for incident '${Incident_Id}'`)
                    return [UnitId,unitstatus];
                }
                else{
                    appendToLogFile(`Fail: Unit '${UnitId}' NOT Acknowledged`)
                    return false;
                }
    
            }
            
            else{
                appendToLogFile(`Fail: Acknowledge Unit dialog NOT closed successfully`)
                return false;
            }           
           
        }

        if(!UnitId){
            console.log(`unit id not provided to acknowledge`)
        }

    }
}
module.exports={AcknowledgeUnit}
