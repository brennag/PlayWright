const{expect}=require('@playwright/test')
class UnitFilters{

    constructor(page)
    {
        this.page = page;
        this.UnitsTab = page.locator("li[title='Units']");
        this.FilterButton=page.locator(`//*[@title="Filters"]`);
        this.ClearAllFiltersButton =page.locator(`//*[@data-testid="unitBoardFilterPopoverFormClearFiltersButton"]`);
        // this.UnitIdfilterbutton = page.locator("div[title='Filter by: Unit ID']")
        // this.StatusFilter = page.locator("div[title='Filter by: Status']")
    }
    
   

    // async UnitFilters(UnitId,status)
    // {
    //     // const unitSelect = this.page.locator(`//label[normalize-space()='${UnitId}']`);
    //     // const StatusSelect = this.page.locator(`//label[normalize-space()='${status}']`);
      
    //     // await this.UnitsTab.click();
    //     // await this.UnitIdfilterbutton.click();
        
    //     // await unitSelect.click();
    //     // await this.UnitIdfilterbutton.click();
    //     // await this.StatusFilter.click()
    //     // await StatusSelect.click()
    //     // await this.StatusFilter.click()
        
    // }
    tabNameInFilters = (tabName ) => this.page.locator(`//*[@title="Filter by: ${tabName}"]`);
    
    async ApplyingMultipleFiltersInUnitsTab(dropdown, values )
    {
        await this.UnitsTab.click();
        await this.page.locator(`//*[contains(@class,'SearchBar_searchBarInput__tV0XP')]`).waitFor()
        if(await this.page.locator("//button[contains(@class,'UnitBoardFilter')]").isVisible()){
            await this.FilterButton.click();
            await this.ClearAllFiltersButton.click();
        }
        let allcolumns = [];
        const column =await this.page.locator(`//*[@class="grid-column-header "]//*[contains(@class,"ColumnHeader_labelText")]`);
        for(let i=0;i<await column.count();i++){
            allcolumns.push(await column.nth(i).textContent());
        }

        //dropdown =['Unit ID', 'Status', 'Time in Status', 'Type', 'Timer', 'Incident', 'Current Location', 'Despatch Group', 'Sector', 'GPS STATUS', 'Incident Type', 'Incident Subtype', 'Clear All']
        //Values should be paased as a list of lists [['ASO2','ASO3'],['Available','Despatched']]
        for(let i=0;i<dropdown.length;i++){
            await this.tabNameInFilters(dropdown[i]).click();
            for(let k=0;k<values[i].length;k++){
                await this.page.locator(`//*[text()="${values[i][k]}"]/preceding-sibling::input`).click({timeout:5000});
                await this.page.waitForTimeout(1000);
            }
            await this.tabNameInFilters(dropdown[i]).click();
            await this.page.waitForLoadState('domcontentloaded', { timeout: 200000 });
        }


        await this.page.waitForTimeout(5000);
        // await this.page.pause();
        await this.page.waitForLoadState('domcontentloaded', { timeout: 200000 });

        //Validation
        const regex = /Showing (\d+) results/;
        const textLocator = await this.page.locator(`//*[@class="UnitsSearch_resultsText__PZhlr"]`).textContent();
        const match = textLocator.match(regex);
        const noOfRows = Number(match[1]);
        console.log(`No of rows:${noOfRows}`);
        let allrowsMatched = true;
        // const allcolumns =['Unit ID','Info', 'Status', 'Time in Status', 'Updates','Type', 'Timer', 'Incident','Queue', 'Current Location', 'Despatch Group', 'Sector', 'GPS STATUS','RVP' ]

        
        if(noOfRows>0){
        for(let i=0;i < noOfRows;i++){
            if(await this.page.locator(`//*[@data-item-index="${i}"]`).isVisible()){
                await this.page.locator(`//*[@data-item-index="${i}"]//*[@type="checkbox"]`).click()
                for(let j=0;j<dropdown.length;j++){
                    const index=allcolumns.indexOf(dropdown[j])
                    let text =await this.page.locator(`//*[@data-item-index="${i}"]//*[@data-testid='gridColumnCell']`).nth(index).textContent()
                    if(!values[j].includes(text)){
                        console.log(`Fail: Unit Filters NOT correctly applied.  found "${text} in row "${i}"`)
                        allrowsMatched=false;
                    }

                }
                await this.page.locator(`//*[@data-item-index="${i}"]//*[@type="checkbox"]`).click()
                while(i+1 < noOfRows){
                    if(await this.page.locator(`//*[@data-item-index="${i+1}"]`).isVisible()){
                        // await this.page.waitForTimeout(1000);
                        break;
                    }
                    else{
                        await this.page.locator(`//*[@id="grid-scrollbar"]`).hover();
                        // await this.page.waitForTimeout(1000);
                        await this.page.mouse.wheel(0,10);
                        // await this.page.waitForTimeout(1000);
                        await this.page.waitForTimeout(500);
                        await this.page.waitForLoadState('domcontentloaded', { timeout: 35000 });
                        // await this.page.waitForTimeout(1000);
                    }
                }

            }

        }
        if (allrowsMatched) {
            console.log(`Pass: Unit filters correctly applied`);
        }
    }
    else{
        console.log(`No results found after applying Unit filters`)
    }   


    }


    
}
module.exports ={UnitFilters}

