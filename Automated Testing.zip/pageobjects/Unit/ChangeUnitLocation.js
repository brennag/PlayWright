class ChangeUnitLocation{
    constructor(page)
    {
        this.page = page;
        this.CommandLine =page.locator("[title='Command Line']");
        this.InputCommand =page.getByPlaceholder('Command Line...');
        this.location =page.locator("//angwrap-dialog-location[contains(@display-enhanced-verify-location-dialog,'dialog.req.displayEnhancedVerifyLocationDialog')]//input[contains(@type,'text')]").first();
        this.SubmitBtn = page.locator(".btn.btn-primary.submit-btn.cd-tabbable.ng-binding");
    }

    async changeUnitLocation(UnitId,Location)
    {
        await this.UnitsTab.click();
        await this.CommandLine.click();
        await this.InputCommand.fill('CHANGE LOCATION -U ' + UnitId);
        await this.page.keyboard.press('Enter')
        await this.page.waitForTimeout(2000);
        await this.location.fill(location);
        await this.page1.waitForTimeout(1000);
        await this.page1.locator(`//span[contains(text(),'${Location}')]`).first().click();
        await this.page.waitForTimeout(2000);
        await this.page.keyboard.press('Enter');
        await this.SubmitBtn.click();
    }
}
module.exports ={ChangeUnitLocation};
