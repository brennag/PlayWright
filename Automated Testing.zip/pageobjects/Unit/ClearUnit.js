const{appendToLogFile}=require('../../tests/testlogs')
const{CommonUtils} =require('../CommonUtils')
const{DialogOpen}=require('../General/DialogOpen')
const{GetUnitFilterResults}=require('./GetUnitFilterResults')
class ClearUnit{
    constructor(page)
    {
        this.page = page;
        this.CommonUtilspage = new CommonUtils(page)
        this.DialogOpenpage = new DialogOpen(page)
        this.GetUnitFilterResultspage= new GetUnitFilterResults(page)
        this.UnitsTab = page.locator("li[title='Units']");
        this.SubmitBtn = page.locator("//*[contains(@class,'btn btn-primary submit-btn cd')]")

    }

    async ClearUnit(UnitId,Incident_ID,Resolution,Comment)
    {
        await this.UnitsTab.click()
        const unitstatus = await this.GetUnitFilterResultspage.getUnitStatus(UnitId)
        if(unitstatus=='Available')
        {
            console.log(`Unit: ${UnitId} is already available. so skipping clear Unit step`)
        }
        else
        {
            await this.DialogOpenpage.DialogOpen(`Clear Unit`,'CLEAR UNIT')
            await this.CommonUtilspage.SelectDropdownValue('(LBL_CLRUNIT_UNITID)',UnitId)
            if(Incident_ID)
            {
                let incidentid_CLR=await this.page.locator(`//*[@label="(LBL_CLRUNIT_INCIDENTID)"]//*[contains(@class,'hxgn-inner-select__single-value')]`).textContent()
                if(incidentid_CLR==Incident_ID){
                    console.log(`IncidentID which is assigned to the Unit is automatically selected.`)
                }
                else{
                    console.log(`IncidentID which is assigned to the Unit is NOT automatically selected.`)
                }
            }
            if(Resolution){
                await this.CommonUtilspage.SelectDropdownValue('(LBL_CLRUNIT_RESOLUTION)',Resolution)
            }
            if(Comment){
                await this.CommonUtilspage.EnterText('LBL_CLRUNIT_COMMENT',Comment)
            }
            await this.SubmitBtn.click();
            await this.page.waitForTimeout(5000)

             //Checking whether dialog closed & Validation whether unit status changed
            if(!await this.DialogOpenpage.DialogOpen('Clear Unit',null)){
                console.log(`Clear Unit dialog closed successfully`)
                let unitstatus = await this.GetUnitFilterResultspage.getUnitStatus(UnitId)
                if(unitstatus=='Available'){
                    appendToLogFile(`Pass:Unit '${UnitId}' cleared successfully'`)
                    return [UnitId,unitstatus];
                }
                else{
                    appendToLogFile(`Fail: Unit '${UnitId}' NOT cleared`)
                    return false;
                }
    
            }
            
            else{
                appendToLogFile(`Fail: Clear Unit dialog NOT closed successfully`)
                return false;
            }   

        }
        

    }
}
module.exports ={ClearUnit}