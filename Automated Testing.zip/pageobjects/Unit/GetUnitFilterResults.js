const{UnitFilters}=require('./UnitFilters')
class GetUnitFilterResults{
    constructor(page){
        this.page=page;
        this.UnitFilterspage = new UnitFilters(page)
    }

    async getUnitStatus(Unit_Id){
        await this.UnitFilterspage.ApplyingMultipleFiltersInUnitsTab(['Unit ID'],[[Unit_Id]]);
        await this.page.waitForTimeout(2000)
        let unitstatus = await this.page.locator(`//div[@data-automation='header=Status']`).textContent()
        return unitstatus;
    }

    async getAvailableUnits(){
        await this.UnitFilterspage.ApplyingMultipleFiltersInUnitsTab(['Status'],[['Available']])
        const regex = /Showing (\d+) results/;
        const textLocator = await this.page.locator(`//*[@class="UnitsSearch_resultsText__PZhlr"]`).textContent();
        const match = textLocator.match(regex);
        const noOfRows = Number(match[1]);
        await this.page.pause()
        await this.page.evaluate(() => window.scrollTo(0, 0));
        let AvailableUnits=[]
        let unit = await this.page.locator(`//*[@data-Automation='header=Unit ID']`)
        if(AvailableUnits.length<noOfRows)
        {
            for(let i=0;i<await unit.count();i++)
            {
                let text = await unit.nth(i).textContent()
                if(!AvailableUnits.includes(text)){
                    AvailableUnits.push(text)
                }
            }
    

        }

        console.log(AvailableUnits)
        return AvailableUnits;
    }
}

module.exports={GetUnitFilterResults}