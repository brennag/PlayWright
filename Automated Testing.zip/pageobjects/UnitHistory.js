class UnitHistory {

    constructor(page)
    {
        this.page=page;
        this.page = page;
        this.CommandLine = page.locator("[title='Command Line']");
        this.InputCommand = page.getByPlaceholder('Command Line...');
        this.dateSettingicon = page.locator("angwrap-hxgn-select[placeholder='ddrs.placeholder'] svg")
        this.datesSetting = page.getByText('Last 12 Hours', { exact: true });
        this.UnitEnter =page.locator("//input[@ng-model='dialog.req.unitId']")
        this.SubmitBtn = page.getByRole('button', { name: 'Submit', exact: true })
        this.results = page.getByRole('button', { name: 'View All Results', exact: true })
    }

    async UnitHistory(UnitId)
    {
        await this.CommandLine.click();
        await this.InputCommand.fill('UNIT HISTORY');
        await this.page.keyboard.press('Enter')
        await this.dateSettingicon.click();
        await this.datesSetting.click();
        await this.UnitEnter.fill(UnitId);
        await this.SubmitBtn.click();
        await this.results.click();
    }
}
module.exports ={UnitHistory}