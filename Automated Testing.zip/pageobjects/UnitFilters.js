class UnitFilters{

    constructor(page)
    {
        this.page = page;
        this.UnitsTab = page.locator("li[title='Units']");
        this.UnitIdfilterbutton = page.locator("div[title='Filter by: Unit ID']")
        this.StatusFilter = page.locator("div[title='Filter by: Status']")
    }
    
   

    async UnitFilters(UnitId,status)
    {
        const unitSelect = this.page.locator(`//label[normalize-space()='${UnitId}']`);
        const StatusSelect = this.page.locator(`//label[normalize-space()='${status}']`);
      
        await this.UnitsTab.click();
        await this.UnitIdfilterbutton.click();
        
        await unitSelect.click();
        await this.UnitIdfilterbutton.click();
        await this.StatusFilter.click()
        await StatusSelect.click()
        await this.StatusFilter.click()
        
    }
    
}
module.exports ={UnitFilters}

