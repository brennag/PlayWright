const{SelectIncident}=require('./SelectIncidents')
class IncidentPanelContextMenu{
    constructor(page){
        this.page =page;
        this.SelectIncidentpage = new SelectIncident(page)
        // this.contextmenubutton = page.locator(`//*[contains(@class,'verticalEllipsisButton ')]`)
        this.contextmenubutton =page.locator(`//angwrap-panel-manager//div[@id='commands']`)
    }

    async incidentpanelcontextmenu(Incident_ID,menuoption)
    {
        let isincidentpanelopened = await this.SelectIncidentpage.SelectIncident(Incident_ID)
        console.log(`isincidentpanelopened : ${isincidentpanelopened}`)
        if(isincidentpanelopened)
        {
            await this.contextmenubutton.click()
            await this.page.waitForTimeout(3000)
            await this.page.getByRole('listitem', { name: menuoption }).click();
            console.log(`Pass: ${menuoption} selected from Incident card Context Menu  for incident :${Incident_ID}`)
        }
        else{
            console.log(`Fail : Incident panel not opened for ${Incident_ID}. so context menu cannot be displayed`)
        }
    }

}
module.exports={IncidentPanelContextMenu}