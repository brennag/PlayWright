const { expect } = require('@playwright/test');
const { CommonUtils } = require('../CommonUtils');
const { DialogOpen } = require(`../General/DialogOpen`);
const { InvokeCommand } = require(`../General/InvokeCommand`);
const { SelectIncident } = require('../Incident/SelectIncidents');
const {SearchComments} = require ('../CreateContact/SearchComments');
const {appendToLogFile } = require('../../tests/testlogs');
const { clear } = require('console');
class DuplicateAndCancel {
    constructor(page) {
        this.page = page;
        this.SubmitBtn = page.locator(`//button[text()='Submit']`)
    }
async DuplicateCancel(PrimaryIncidentID, IncidentID, Comment) {
        const DialogOpenpage = new DialogOpen(this.page)
        const CommonUtilspage = new CommonUtils(this.page)
        await this.page.bringToFront()
        await CommonUtilspage.DismissAllNotifications(this.page)
        await DialogOpenpage.DialogOpen('Duplicate and Cancel', 'Duplicate and Cancel')
        
        await CommonUtilspage.SelectDropdownValue('(LBL_DUPNCAN_IncidentIDToKeep)', PrimaryIncidentID)
        await CommonUtilspage.SelectDropdownValue('(LBL_DUPNCAN_IncidentIDToCancel)', IncidentID)
        await CommonUtilspage.EnterText('LBL_DUPNCAN_Remarks',Comment)
        await this.SubmitBtn.click()
        await this.page.waitForTimeout(30000)
        let IsDialogOpen = await DialogOpenpage.DialogOpen('Copy Incident Information',null)
        console.log (IsDialogOpen)
        if (IsDialogOpen)
        {
            await this.page.locator(`//button[text()='Submit']`).click()
        }
        else
        {
            console.log('Copy Incident Information dialog is not opened')
            appendToLogFile (`Fail: Copy Incident Information dialog is not opened`)
        }
    }
    

}module.exports={DuplicateAndCancel}