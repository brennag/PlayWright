//This flow is to check whether an incident is present in the incident board and return status if present else return false.
const{appendToLogFile}=require('../../tests/testlogs')
class IncidentBoardSearch{
    constructor(page){
        this.page =page;
        this.IncidentTab =page.locator("li[title='Incidents']")
        this.SearchIncidents = page.locator("input[placeholder='Search Incidents...']")
        this.searchresult =page.locator("//span[@class='results-title']")

    }

    async incidentboardsearch(Tabname,Incident_ID)
    {
        await this.IncidentTab.click()
        if(Tabname){
            await this.page.waitForTimeout(3000)
            await this.page.locator(`//div[@title='${Tabname}']`).click()
        }
        await this.SearchIncidents.fill(Incident_ID)
        const result = await this.searchresult.textContent()
        if(result.includes(`Showing 1 results for "${Incident_ID}"`))
        {
            console.log(`Pass :'${Incident_ID}' incident available in the Incident Board`)
            const Incidentgroups =[]
            let elements = await this.page.$$("//h4[@class='group-title']")
            for(let element of elements){
                let text = await element.textContent()
                Incidentgroups.push(text)
            }
            // console.log(Incidentgroups)
            let IncidentStatus;
            for(let Incidentgroup of Incidentgroups){
                if(Incidentgroup.includes('1')){
                  IncidentStatus =Incidentgroup.replace(/\s*\(\d+\)$/, "")// regex to remove the number present beside Incident status
                }
            }
            console.log(`IncidentStatus:${IncidentStatus}`)
            return IncidentStatus;


        }
        else
        {
            console.log(`Fail :'${Incident_ID}' incident NOT available in the Incident Board`)
            return false;
        }
       
      
    }



}
module.exports ={IncidentBoardSearch}