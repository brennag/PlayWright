const { CreateContactPage }=require("../CreateContact/CreateContactpage");
const{CommonUtils}=require('../CommonUtils')
const{appendToLogFile}=require('../../tests/testlogs')
const{expect}=require('@playwright/test')
//const{PageObjects}=require('../PageObjects');


class ScheduledIncident extends CreateContactPage{
    constructor(page){
      
        super(page);
        this.page=page;
        this.scheduledDate = page.locator("//schedule-date-selector[@label='(lbl_ScheduledEvent_ScheduleDate)']")
        this.StartDate = this.scheduledDate.locator("//div[@id='startDatePicker']//input")
        this.EndDate = this.scheduledDate.locator("//div[@id='endDatePicker']//input")
        this.StartTimeHrs =this.scheduledDate.locator("//div[@id='startTime']//input").first()
        this.StartTimeMin =this.scheduledDate.locator("//div[@id='startTime']//input").nth(1)
        this.EndTimeHrs =this.scheduledDate.locator("//div[@id='endTime']//input").first()
        this.EndTimeMin =this.scheduledDate.locator("//div[@id='endTime']//input").nth(1)
        this.Delta =page.locator("//*[@name='(lbl_ScheduledEvent_DeltaTime)']//input")
        this.CreateIncidentbutton =page.locator("//button[text()='Create Incident']")
        this.Callerinfobutton= page.locator("//div[@id='EVENT_PANEL_CALLER_INFO']")
        this.addcallerinfo =page.locator("//button[normalize-space()='Add Caller Information']")
        this.scheduleincidentcalleraddress =page.locator("//angwrap-dialog-location[contains(@name,'(lbl_ScheduledEventCallerInfo_CallerAddress)')] //input")
        this.locationresult =page.locator("//div[contains(@class,'location-result')]").first()
        this.savecaller=page.locator("//div[contains(@class,'caller-info-add-update-view')]//button[contains(@class,'submit-btn')]")
        this.scheduleincidentinfobutton= page.locator("//div[@id='SCHEDULED_EVENT_INFO']")
        this.updateincident = page.locator(`//*[contains(@class,'create-schedule-event-dialog')]//*[text()='Update Incident']`)
        this.CommonUtilspage = new CommonUtils(this.page)

    }

    async savescheduledIncidentdetails(Incidentlocation,IncidentType,IncidentSubType,Incidenttitle,Caller_name)
    {
        await this.scheduleincidentinfobutton.click()
        if(Incidentlocation){
            await this.AttendanceLocation.fill(Incidentlocation);
            await this.locationsearch.first().click();
            await this.page.waitForTimeout(5000)
            const Attlocationverified=await this.page.locator("svg[data-icon='check-circle']").first().isVisible()//verifying the location
         
                if(!Attlocationverified){
                    appendToLogFile("Fail : Attendance location not verified")
                }else{
                    appendToLogFile('Pass:Attendance location verified ')
                }
        }
        else{
            console.log("Incident location not provided.")
        }
        if(IncidentType){
            await this.page.waitForTimeout(2000)
           await this.CommonUtilspage.SelectDropdownValue('(lbl_ScheduledEvent_Type)',IncidentType)
        }
        else{
            console.log("Incident type not provided.")
        }
        if(IncidentSubType){
           await this.CommonUtilspage.SelectDropdownValue('(lbl_ScheduledEvent_SubType)',IncidentSubType)
        }
        else{
            console.log("Incident Sub Type Not Provided.")
        }
        if(Incidenttitle){ 
            await this.CommonUtilspage.EnterText('lbl_ScheduledEvent_EventTitle',Incidenttitle) 
        }
        else{
            console.log("Incident Title Not Provided.")
        }
        if(Caller_name){ 
            await this.CommonUtilspage.EnterText('lbl_ScheduledEvent_CallerName',Caller_name) 
        }
        else{
            console.log("Caller Name Not Provided.")
        }
        
    }
    //This function is to add 0's before time if time is lessthan 10 like if it is 8, it will return 08.
    async padNumber(num) {
        return num.toString().padStart(2, '0');
    }

    //method to get date , time values  and return them so that we an use anywhere in class.
    //oddset should be passed as an object like {hours:2}
    async getDateTime(offset){
        let Datetime =await this.CommonUtilspage.offsetDateTime(offset)
        let Year=Datetime.offsetyear
        let Month=Datetime.offsetmonth
        let Day=Datetime.offsetday
        let starthrs= await this.padNumber(Number(Datetime.offsetHrs))
        let startmin =await this.padNumber(Number(Datetime.offsetmin))
        let endHrs = await this.padNumber(Number(starthrs )+1);
        let endmin = await this.padNumber(Datetime.offsetmin);
        if(endHrs==24){
            endHrs=0;
        }
        if (startmin < 0) {
            startmin += 60;
            starthrs -= 1;
        }
        let fixedDatetime={Year,Month,Day,starthrs,startmin,endHrs,endmin}
        return fixedDatetime
    }
    

    async CreateScheduledIncidentTimings(offset,delta)
    {
        await this.scheduleincidentinfobutton.click()
        let {Year ,Month, Day,starthrs,startmin,endHrs,endmin} =await this.getDateTime(offset)
        console.log('Savescheduledincident',Year ,Month, Day,starthrs,startmin,endHrs,endmin)
        await this.StartDate.click()
        await this.CommonUtilspage.DatePickerCalendar(Year, Month, Day)
        await this.EndDate.click()
        await this.CommonUtilspage.DatePickerCalendar(Year, Month, Day)
        await this.StartTimeHrs.fill(`${starthrs}`)
        await this.StartTimeMin.fill(`${startmin}`)
        await this.EndTimeHrs.fill(`${endHrs}`)
        await this.EndTimeMin.fill(`${endmin}`)
        await this.Delta.fill(`${delta}`)
        await this.page.setViewportSize({width:1920,height:1200})
        await this.CreateIncidentbutton.scrollIntoViewIfNeeded()
        await this.CreateIncidentbutton.click()
        await this.page.waitForTimeout(2000)
        
         const isDialogOpen =await this.page.locator(`//*[contains(@class,'dialog-header')]//*[text()='Create Scheduled Incident']`).isVisible()
        
        if(!isDialogOpen){
            console.log(`Pass: Scheduled Incident Dialog Closed`)
        }
        else{
            console.log(`Fail: Scheduled Incident Dialog not closed`)
        }
       
    }

    async ScheduledIncidentSaveCallerDetails(callername,phonenumber,Source,address)
    {
       await this.Callerinfobutton.click()
       await this.addcallerinfo.click()
       await this.CommonUtilspage.EnterText('lbl_ScheduledEventCallerInfo_CallerAddress',callername)
       await this.CommonUtilspage.EnterText('lbl_ScheduledEventCallerInfo_PhoneNumber',phonenumber)
       await this.CommonUtilspage.SelectDropdownValue('(lbl_ScheduledEventCallerInfo_Source)',Source)
       await this.scheduleincidentcalleraddress.fill(address)
       await this.page.waitForTimeout(3000)
       await this.locationresult.click()
       await this.savecaller.click()
       await this.page.waitForTimeout(3000)
       await expect(this.page.locator("//dialog-text-display[@textparam='CallerName']//span")).toContainText(callername)
       await expect(this.page.locator("//dialog-text-display[@textparam='CallerPhone']//span")).toContainText(phonenumber)
       await expect(this.page.locator("//dialog-text-display[@textparam='CallSource']//span")).toContainText(Source)
       await expect(this.page.locator("//dialog-text-display[@textparam='CallerAddress']//span")).toContainText(address)
       appendToLogFile(`Pass:Caller details in scheduled Incident saved successfully`)


    }

    async EditScheduledIncidentdetails(offset,delta)
    {
        let {Year ,Month, Day,starthrs,startmin,endHrs,endmin} =await this.getDateTime(offset)
        console.log('editsschedule',Year ,Month, Day,starthrs,startmin,endHrs,endmin)
        await this.StartDate.click()
        await this.CommonUtilspage.DatePickerCalendar(Year, Month, Day)
        await this.EndDate.click()
        await this.CommonUtilspage.DatePickerCalendar(Year, Month, Day)
        await this.StartTimeHrs.fill(`${starthrs}`)
        await this.StartTimeMin.fill(`${startmin}`)
        await this.EndTimeHrs.fill(`${endHrs}`)
        await this.EndTimeMin.fill(`${endmin}`)
        await this.Delta.fill(`${delta}`)
        await this.updateincident.click()
        await this.page.waitForTimeout(2000)
        const isDialogOpen =await this.page.locator(`//*[contains(@class,'dialog-header')]//*[text()='Edit Scheduled Incident']`).isVisible()
        
        if(!isDialogOpen){
            console.log(`Pass:Edit Scheduled Incident Dialog Closed`)
        }
        else{
            console.log(`Fail:Edit Scheduled Incident Dialog not closed`)
        }

    }


    async ValidateScheduleIncidentsTab(offset,Caller_name,Incidenttitle)
    {
        
        let {Year ,Month, Day,starthrs,startmin,endHrs,endmin} =await this.getDateTime(offset)
        console.log(Year ,Month, Day,starthrs,startmin,endHrs,endmin)
        await this.page.locator("//li[@title='Scheduled Incidents']").click()
        await this.page.waitForTimeout(2000)
        const istabopen = await this.page.locator("//label[normalize-space()='Scheduled Incidents Calendar']").isVisible()
        if(istabopen){
            console.log("Scheduled Incidnet tab displayed")
        }
        else{
            console.log(`Scheduled Incident tab not displayed`)
        }
        await this.page.locator(`//input[@placeholder='Search Scheduled Incidents...']`).fill(Caller_name)
        await this.page.locator("//div[contains(@class,'ScheduledEventsDateTime_dateFrom')]//input").click()
        await this.CommonUtilspage.DatePickerCalendar(Year, Month, Day)
        await this.page.locator("//div[contains(@class,'ScheduledEventsDateTime_dateTo')]//input").click()
        await this.CommonUtilspage.DatePickerCalendar(Year, Month, Day)
        await this.page.locator("//div[contains(@class,'ScheduledEventsDateTime_timeFrom')]//input").fill(`${starthrs}:${startmin}`)
        await this.page.keyboard.press('Enter')
        await this.page.locator("//div[contains(@class,'ScheduledEventsDateTime_timeTo')]//input").fill(`${endHrs}:${endmin}`)
        await this.page.keyboard.press('Enter')
        let date = `${await this.padNumber(Day)}/${await this.padNumber(Month)}/${Year}`
        const isScheduledIncidentvisible = await this.page.locator("//div[@role='row' and contains(@class,'GridRow_grid-row')]").first().isVisible()
        if(isScheduledIncidentvisible){
           console.log(`Pass:Scheduled Incident created is available in the scheduled incidents tab`)
           
            let scheduledincidentlistrow = await this.page.locator("//div[@role='row' and contains(@class,'GridRow_grid-row')]").first().textContent()
            console.log(`row: ${scheduledincidentlistrow}`)
            
            if(scheduledincidentlistrow.includes(date) && scheduledincidentlistrow.includes(Incidenttitle))
            {
                console.log(`Pass:Scheduled incident details displayed correctly`)
                
            }
            else{
                console.log(`FAIL:Scheduled incident details NOT displayed correctly`)
                return false
            }
        }
        else{
            console.log(`Fail:Scheduled Incident created is NOT available in the scheduled incidents tab`)
            
        }
        
        //validating Calendar
        await this.page.locator(`//*[@data-automation="header=LOCATION"]/parent::*`).click()
        let scheduledinfodetails = await this.page.locator(`//*[contains(@class,'ScheduledEventsDetailsPanel')]//span[contains(text(),'To')]`).textContent()
        let {incidentstarthr, incidentstartmin, incidentendhr, incidentendmin} = await this.extractHourMinuteParts(scheduledinfodetails)
        console.log('incidentstarthr',incidentstarthr)
        await this.page.locator(`//abbr[text()='${Day}']`).first().click()
        await this.page.locator(`//button[@id='ScheduleEventCalendarAgendaView']`).click()
        await this.page.locator(`//span[text()='${incidentstarthr}:${incidentstartmin} – ${incidentendhr}:${incidentendmin}']/parent::*/following-sibling::*`).click()
        await this.page.locator(`//angwrap_scheduled_event_popup_date_display`).isVisible()
        let IncidentdetailsinCalendar = await this.page.locator(`//angwrap_scheduled_event_popup_date_display`).textContent()
        console.log(`cal:${IncidentdetailsinCalendar}`)
        if(IncidentdetailsinCalendar.includes(date)&& IncidentdetailsinCalendar.includes(`${incidentstarthr}:${incidentstartmin}`) && IncidentdetailsinCalendar.includes(`${incidentendhr}:${incidentendmin}`))
        {
            appendToLogFile(`Pass:Scheduled incident details displayed correctly in Calendar`)
            return true
        }
        else{
            appendToLogFile(`Fail:Scheduled incident details NOT displayed correctly in Calendar`)
            return false
        }
        await this.page.locator("//div[@title='All']").click()
        
    }

    async extractHourMinuteParts(text) {
        const timeRangeRegex = /(\d{2}):(\d{2}):\d{2}\s*To\s*(\d{2}):(\d{2}):\d{2}/;
    
        const match = text.match(timeRangeRegex);
        if (!match) return null;
    
        const incidentstarthr = match[1];
        const incidentstartmin = match[2];
        const incidentendhr = match[3];
        const incidentendmin = match[4];
    
        return { incidentstarthr, incidentstartmin, incidentendhr, incidentendmin };
    }
}
module.exports={ScheduledIncident}

