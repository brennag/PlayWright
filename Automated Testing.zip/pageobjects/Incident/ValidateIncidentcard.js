const { appendToLogFile } = require("../../tests/testlogs");

class ValidateIncidentcard {
    constructor(page){
        this.page=page;
        this.IncidentTab =page.locator("li[title='Incidents']")
        this.SearchIncidents = page.locator("input[placeholder='Search Incidents...']")
        this.searchdetails = page.locator(`//*[@class="event-search-result-details"]`)

    }

    async ValidateIncidentcard(Incident_ID,Priority,Incident_Type_code,Incident_type_description,Incident_Sub_Type_code,Incident_Sub_Type_description,Location,despatch_group,Assigned_Unit)
    {
        await this.IncidentTab.click()
        await this.SearchIncidents.fill(Incident_ID)
        await this.page.waitForTimeout(3000)
        await this.searchdetails.dblclick()
        await this.page.waitForTimeout(3000)
        let eventcarddetails =await this.page.locator(`//*[contains(text(),'${Incident_ID}')]/ancestor::*[contains(@class,'EventItem_header')]`).textContent()
        console.log(eventcarddetails)
        let NotMatchedDetails = [];

        function checkAndLog(value, label) {
            if (value) {
                if (eventcarddetails.includes(value)) {
                    console.log(`${label} correctly shown in Incident card details`);
                } else {
                    console.log(`${label} NOT correctly shown in Incident card details`);
                    NotMatchedDetails.push(label);
                }
            }
            else{
                console.log(`${label} Not Provided. so skipping validation `)
            }
        }
    
        checkAndLog(Priority, "Priority");
        checkAndLog(Incident_Type_code, "Incident Type Code");
        checkAndLog(Incident_type_description, "Incident Type Description");
        checkAndLog(Incident_Sub_Type_code, "Incident Sub Type Code");
        checkAndLog(Incident_Sub_Type_description, "Incident Sub Type Description");
        checkAndLog(Location, "Location");
        checkAndLog(despatch_group, "Despatch Group");
        checkAndLog(Assigned_Unit, "Assigned Unit");
    
        
        if (NotMatchedDetails.length === 0) {
            appendToLogFile(`Pass:All provided details are correctly shown in the Incident card.`);
        } else {
            appendToLogFile(`Fail :The following fields are NOT correctly shown in the Incident card: ${NotMatchedDetails.join(", ")}`);
        }
        
    }
}
module.exports={ValidateIncidentcard}