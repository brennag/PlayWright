const{DialogOpen}=require('../General/DialogOpen')
const{RemoveNewline}=require('../General/RemoveNewline')
const { expect} = require ('@playwright/test');

class IncidentChronology{
    constructor(page){
        this.page=page;
        this.Incident= page.locator("//virtualized-selector[@class='ng-isolate-scope']")
        this.submitbutton=page.locator("//*[contains(@class,'ui-button sub-btn')]")
        this.representation =page.locator("//div[@role='row'] //div[@role='gridcell'][5]")
        this.RemoveNewlinepage = new RemoveNewline(page)
        // this.closedialogbutton = page.locator(`//*[@id="event-chronology-response-dialog"]//button[@title="Close"]`)
        this.closedialogbutton = page.locator(`//*[@id="event-chronology"]//*[text()='Close']`)
    }

    async incidentchronology(Contact_ID,Resolution)
    {
        const DialogOpenPage = new DialogOpen(this.page)
        const DialogName ='Chronology'
        await DialogOpenPage.DialogOpen(DialogName,`INCIDENT CHRONOLOGY -e ${Contact_ID}`)
        
        await expect(this.Incident).toContainText(Contact_ID)
        console.log(`Pass: Incident Chronology dialog opened for ${Contact_ID}`)
        await this.submitbutton.click()
        Resolution = await this.RemoveNewlinepage.removenewline(Resolution)
        let result =false
        await this.page.locator("//span[@title='Representation']").waitFor()
        let max =await this.representation.count()
        // let max = await this.page.$$("div[role='row'] > div[role='gridcell']:nth-child(5)")

        //console.log(max)
        for(let i=0;i<max; i++)
            {
               let  representation = await this.representation.nth(i).textContent()
               representation = await this.RemoveNewlinepage.removenewline(representation)
               
               if(representation.includes(Resolution))
                {
                   console.log(`Pass: Searched Resolution '${Resolution}' found`)   
                   result =true
                   break;  
               }
            }
        if(!result)
           {  
            console.log(`Fail: Searched Resolution '${Resolution}' not found`)
           }
        await this.closedialogbutton.click()
    }
}
module.exports ={IncidentChronology}