//here the values passed to the function are TabNames, ValuesList, where Tabnames is  alist of tab names like person,vehicle.. 
//and valuelist is a list of objects as TabsList=['Person','Vehicle','Property','References'] &ValuesList =[{Title:'mist',Surname:'Mega'},{Colour:'Green'},{Model:'N147'},{Comments:'TESTING Reference'}]

const { expect } = require('@playwright/test')
const { DialogOpen } = require('../General/DialogOpen')
class Supplementalinfo {
    constructor(page) {
        this.page = page;
        this.suppinfobutton = page.locator(`//div[@id='EVENT_PANEL_SUPP_INFO']`)
        this.add_edit_suppinfo = page.locator(`//button[text()='Add / Edit Supplemental Information']`)
        this.DialogOpenpage = new DialogOpen(page)
        this.addpersonbutton = page.locator("//button[text()='Add Person']")
        this.addvehiclebutton = page.locator("//button[text()='Add Vehicle']")
        this.addpropertybutton = page.locator("//button[text()='Add Property']")
        this.addreferencebutton = page.locator("//button[text()='Add Reference']")
        this.saveandsendupdatebutton = page.locator("//button[normalize-space()='Save and send update']")
    }
    selectTab = (tabname) => this.page.locator(`//button[@title='${tabname}']`).click()
    defaultPersoninfo = {
        'Interest Reason': null,
        'Title': null,
        'Surname': null,
        'Maiden Name': null,
        'Forename': null,
        'Nick Name': null,
        'Date of Birth': null,
        'Sex': null,
        'Ethnic Appearance': null,
        'Height': null,
        'Marks or Scars': null,
        'Unit ID': null,
        'Mobile Number': null,
        'Home Number': null,
        'Person Type': null,
        'Work Number': null,
        'Other Number': null,
        'Email': null,
        'Social Media Handle': null,
        'Comments': null,
        'Occupation': null,
        'Address': null,
        'Organisation Name': null,
        'PNC Reason Code': null,
        'Request POLE Search': null,
        'Requesting Employee ID': null,
        'Vehicle Links': null,
        'Property Links': null
    };
    
    defaultVehicleinfo = {
        'Status': null,
        'VRM': null,
        'Make': null,
        'Model': null,
        'Colour': null,
        'Vehicle Type': null,
        'Chassis Number': null,
        'Engine Number': null,
        'VIN or Frame Number': null,
        'PNC Reason Code': null,
        'Request POLE Search': null,
        'Requestor Employee ID': null,
        'Description': null,
        'Supplemental Info Links': null
    };
    
    defaultPropertyinfo = {
        'Property Type': null,
        'Status': null,
        'Currency': null,
        'Value': null,
        'Make': null,
        'Model': null,
        'Serial or ID Number': null,
        'IMEI Number': null,
        'Property Mark': null,
        'Inscription': null,
        'Description': null,
        'Request POLE Search': null,
        'Supplemental Info Links': null
    };
    
    defaultReferenceinfo = {
        'Internal MPS Ref': null,
        'Reference Number': null,
        'Neighbouring Police Forces': null,
        'UK Police Forces': null,
        'Other UK Law Enforcement Agencies': null,
        'Partner Agencies': null,
        'Local Authorities': null,
        'Other Organisation': null,
        'Comments': null
    };
    
    async SaveSupplementalinfo(TabNames, ValuesList) {
        let isdialogopened = await this.DialogOpenpage.DialogOpen('Add Edit Supplemental', null)
        if (!isdialogopened) {
            await this.suppinfobutton.click()
            await this.add_edit_suppinfo.click()
        }
    
        for (let option = 0; option < TabNames.length; option++) {
            const TabName = TabNames[option];
            const Values = ValuesList[option];
    
            await expect(this.page.locator(`//span[contains(@class,'dialog-header-title')]`).first()).toContainText(`Add Edit Supplemental`)
    
            if (TabName === 'Person') {
                const Personinfo = { ...this.defaultPersoninfo, ...Values }
                await this.selectTab('Person')
    
                Personinfo['Interest Reason'] && await this.setdropdownvalue('Interest Reason', Personinfo['Interest Reason']);
                Personinfo['Title'] && await this.EnterText('Title', Personinfo['Title']);
                Personinfo['Surname'] && await this.EnterText('Surname', Personinfo['Surname']);
                Personinfo['Maiden Name'] && await this.EnterText('Maiden Name', Personinfo['Maiden Name']);
                Personinfo['Forename'] && await this.EnterText('Forename', Personinfo['Forename']);
                Personinfo['Nick Name'] && await this.EnterText('Nick Name', Personinfo['Nick Name']);
                Personinfo['Date of Birth'] && await this.EnterText('Date of Birth', Personinfo['Date of Birth']);
                Personinfo['Sex'] && await this.setdropdownvalue('Sex', Personinfo['Sex']);
                Personinfo['Ethnic Appearance'] && await this.setdropdownvalue('Ethnic Appearance', Personinfo['Ethnic Appearance']);
                Personinfo['Height'] && await this.EnterText('Height', Personinfo['Height']);
                Personinfo['Marks or Scars'] && await this.EnterText('Marks or Scars', Personinfo['Marks or Scars']);
                Personinfo['Unit ID'] && await this.setdropdownvalue('Unit ID', Personinfo['Unit ID']);
                Personinfo['Mobile Number'] && await this.EnterText('Mobile Number', Personinfo['Mobile Number']);
                Personinfo['Home Number'] && await this.EnterText('Home Number', Personinfo['Home Number']);
                Personinfo['Person Type'] && await this.setdropdownvalue('Person Type', Personinfo['Person Type']);
                Personinfo['Work Number'] && await this.EnterText('Work Number', Personinfo['Work Number']);
                Personinfo['Other Number'] && await this.EnterText('Other Number', Personinfo['Other Number']);
                Personinfo['Email'] && await this.EnterText('Email', Personinfo['Email']);
                Personinfo['Social Media Handle'] && await this.EnterText('Social Media Handle', Personinfo['Social Media Handle']);
                Personinfo['Comments'] && await this.EnterText('Comments', Personinfo['Comments']);
                Personinfo['Occupation'] && await this.EnterText('Occupation', Personinfo['Occupation']);
                Personinfo['Address'] && await this.EnterText('Address', Personinfo['Address']);
                Personinfo['Organisation Name'] && await this.EnterText('Organisation Name', Personinfo['Organisation Name']);
                Personinfo['PNC Reason Code'] && await this.setdropdownvalue('PNC Reason Code', Personinfo['PNC Reason Code']);
                Personinfo['Request POLE Search'] && await this.setdropdownvalue('Request POLE Search', Personinfo['Request POLE Search']);
                Personinfo['Requesting Employee ID'] && await this.EnterText('Requesting Employee ID', Personinfo['Requesting Employee ID']);
                Personinfo['Vehicle Links'] && await this.EnterText('Vehicle Links', Personinfo['Vehicle Links']);
                Personinfo['Property Links'] && await this.EnterText('Property Links', Personinfo['Property Links']);
                await this.addpersonbutton.click()
            }
    
            if (TabName === 'Vehicle') {
                const Vehicleinfo = { ...this.defaultVehicleinfo, ...Values }
                await this.selectTab('Vehicle')
    
                Vehicleinfo['Status'] && await this.setdropdownvalue('Status', Vehicleinfo['Status']);
                Vehicleinfo['VRM'] && await this.EnterText('VRM', Vehicleinfo['VRM']);
                Vehicleinfo['Make'] && await this.EnterText('Make', Vehicleinfo['Make']);
                Vehicleinfo['Model'] && await this.EnterText('Model', Vehicleinfo['Model']);
                Vehicleinfo['Colour'] && await this.EnterText('Colour', Vehicleinfo['Colour']);
                Vehicleinfo['Vehicle Type'] && await this.setdropdownvalue('Vehicle Type', Vehicleinfo['Vehicle Type']);
                Vehicleinfo['Chassis Number'] && await this.EnterText('Chassis Number', Vehicleinfo['Chassis Number']);
                Vehicleinfo['Engine Number'] && await this.EnterText('Engine Number', Vehicleinfo['Engine Number']);
                Vehicleinfo['VIN or Frame Number'] && await this.EnterText('VIN or Frame Number', Vehicleinfo['VIN or Frame Number']);
                Vehicleinfo['PNC Reason Code'] && await this.setdropdownvalue('PNC Reason Code', Vehicleinfo['PNC Reason Code']);
                Vehicleinfo['Request POLE Search'] && await this.setdropdownvalue('Request POLE Search', Vehicleinfo['Request POLE Search']);
                Vehicleinfo['Requestor Employee ID'] && await this.EnterText('Requestor Employee ID', Vehicleinfo['Requestor Employee ID']);
                Vehicleinfo['Description'] && await this.EnterText('Description', Vehicleinfo['Description']);
                Vehicleinfo['Supplemental Info Links'] && await this.EnterText('Supplemental Info Links', Vehicleinfo['Supplemental Info Links']);
                await this.addvehiclebutton.click()
            }
    
            if (TabName === 'Property') {
                const Propertyinfo = { ...this.defaultPropertyinfo, ...Values }
                await this.selectTab('Property')
    
                Propertyinfo['Property Type'] && await this.setdropdownvalue('Property Type', Propertyinfo['Property Type']);
                Propertyinfo['Status'] && await this.setdropdownvalue('Status', Propertyinfo['Status']);
                Propertyinfo['Currency'] && await this.setdropdownvalue('Currency', Propertyinfo['Currency']);
                Propertyinfo['Value'] && await this.EnterText('Value', Propertyinfo['Value']);
                Propertyinfo['Make'] && await this.EnterText('Make', Propertyinfo['Make']);
                Propertyinfo['Model'] && await this.EnterText('Model', Propertyinfo['Model']);
                Propertyinfo['Serial or ID Number'] && await this.EnterText('Serial or ID Number', Propertyinfo['Serial or ID Number']);
                Propertyinfo['IMEI Number'] && await this.EnterText('IMEI Number', Propertyinfo['IMEI Number']);
                Propertyinfo['Property Mark'] && await this.EnterText('Property Mark', Propertyinfo['Property Mark']);
                Propertyinfo['Inscription'] && await this.EnterText('Inscription', Propertyinfo['Inscription']);
                Propertyinfo['Description'] && await this.EnterText('Description', Propertyinfo['Description']);
                Propertyinfo['Request POLE Search'] && await this.setdropdownvalue('Request POLE Search', Propertyinfo['Request POLE Search']);
                Propertyinfo['Supplemental Info Links'] && await this.EnterText('Supplemental Info Links', Propertyinfo['Supplemental Info Links']);
                await this.addpropertybutton.click()
            }
    
            if (TabName === 'References') {
                const Referenceinfo = { ...this.defaultReferenceinfo, ...Values }
                await this.selectTab('References')
    
                Referenceinfo['Internal MPS Ref'] && await this.setdropdownvalue('Internal MPS Ref', Referenceinfo['Internal MPS Ref']);
                Referenceinfo['Reference Number'] && await this.EnterText('Reference Number', Referenceinfo['Reference Number']);
                Referenceinfo['Neighbouring Police Forces'] && await this.setdropdownvalue('Neighbouring Police Forces', Referenceinfo['Neighbouring Police Forces']);
                Referenceinfo['UK Police Forces'] && await this.setdropdownvalue('UK Police Forces', Referenceinfo['UK Police Forces']);
                Referenceinfo['Other UK Law Enforcement Agencies'] && await this.setdropdownvalue('Other UK Law Enforcement Agencies', Referenceinfo['Other UK Law Enforcement Agencies']);
                Referenceinfo['Partner Agencies'] && await this.setdropdownvalue('Partner Agencies', Referenceinfo['Partner Agencies']);
                Referenceinfo['Local Authorities'] && await this.setdropdownvalue('Local Authorities', Referenceinfo['Local Authorities']);
                Referenceinfo['Other Organisation'] && await this.EnterText('Other Organisation', Referenceinfo['Other Organisation']);
                Referenceinfo['Comments'] && await this.EnterText('Comments', Referenceinfo['Comments']);
                await this.addreferencebutton.click()
            }
        }
    
        await this.saveandsendupdatebutton.click()
    }
    
    async validateSupplementalInfo(TabNames, ValuesList)
    {
        await this.suppinfobutton.click()
        await this.page.locator(`//*[@class="filtered-info"]`).waitFor()
        let expandbuttton =await this.page.locator(`//*[@class="cd-tabbable collapse-btn collapsed"]`)
        let allcorrectlysaved=true;
        for(let i=await expandbuttton.count()-1;i>=0;i--)
        {
            await expandbuttton.nth(i).click()
            let tabname =await this.page.locator(`//*[@class="supp-info-card-wrapper "]//h4`).textContent()
            let index =TabNames.indexOf(tabname)
            //to turn all key-value pairs into an array of strings where result is an array
            let result = Object.entries(ValuesList[index]).map(([key, value]) => `${key}:${value}`);
            // console.log(`${tabname}\n ${result}`)
            // console.log(result)
            let fieldValueslocator = await this.page.locator(`//*[@class="supp-info-card-field"]`)
            for(let k=0; k<await fieldValueslocator.count();k++)
            {
                let fieldValue = await fieldValueslocator.nth(k).textContent()
                // console.log(`${tabname}-- ${fieldValue}`)
                if(result.includes(fieldValue)){
                    continue;
                }
                else{
                    console.log(`${fieldValue} NOT correctly saved`)
                    allcorrectlysaved =false
                }
            }
            await this.page.locator(`//*[@class="cd-tabbable collapse-btn "]`).click()
        }
        if(allcorrectlysaved){
            console.log(`Pass:Supplemental Info correctly saved`)
            return true
        }
        else{
            console.log(`Fail:Supplemental Info NOT correctly saved`)
            return false
        }
    }


    async setdropdownvalue(name, Value) {
        await this.page.waitForTimeout(1000);
        await this.page.locator(`//*[text()='${name}']/parent::*//*[contains(@class,'dropdown-indicator')]`).scrollIntoViewIfNeeded()
        await this.page.locator(`//*[text()='${name}']/parent::*//*[contains(@class,'dropdown-indicator')]`).click()
        await this.page.waitForTimeout(1000);
        await this.page.locator(`//*[starts-with(text(),'${Value}')]`).last().click();
    }
    async EnterText(name, Value) {
        await this.page.locator(`//*[text()='${name}']/parent::*//input`).fill(Value)
    }
}
module.exports = { Supplementalinfo }