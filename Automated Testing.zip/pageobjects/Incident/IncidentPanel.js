//This class is to have all locators from Incident panel 

const{expect}=require('@playwright/test')

class IncidentPanel{
    constructor(page){
        this.page=page;
        this.priority = page.locator("//h5[@class='priority']")
        this.incidentid = page.locator("//dialog-text-display//span[starts-with(text(),'MPS')]")
        this.time= page.locator("//time-display")
        this.Incidenttypecode =page.locator(`(//dialog-text-display)[3]`)
        this.Incidenttype = page.locator(`(//dialog-text-display)[4]`)
        this.Incidentsubtypecode = page.locator(`(//dialog-text-display)[5]`)
        this.Incidentsubtype= page.locator(`(//dialog-text-display)[6]`)
        this.location=page.locator("//img[@title='Location']/following-sibling::*")
        this.Dispatchgroup =page.locator(`(//dialog-text-display)[7]`)
        this.sector = page.locator(`(//dialog-text-display)[8]`)
        this.Ward = page.locator(`(//dialog-text-display)[9]`)
        this.Incidentsummaryreport =page.locator("//button[text()='Incident Summary Report']")
        this.SMFbutton= page.locator("//button[contains(@title,'SMF')]")
        this.scrollingoffon=page.locator("//div[@title='Scrolling Off/On']").first()
        this.fitercomments=page.locator("//div[@title='Filter Comments']").first()
        this.Searchforkeywords=page.locator("//div[@title='Search for keywords']").first()
        this.overview=page.locator("//div[@id='EVENT_PANEL_OVERVIEW']")
        this.comments =page.locator("//div[@id='COMMAND_DIALOG_COMMENTS']")
        this.callerinfo=page.locator("//div[@id='EVENT_PANEL_CALLER_INFO']")
        this.Recommendedunits=page.locator("//div[@id='EVENT_PANEL_RECOMMEND_UNITS']")
        this.Assignedunits=page.locator("//div[@id='ASSIGNED_UNITS']")
        this.eventqueueunit=page.locator("//div[@id='UNITS_WITH_EVENT_IN_QUEUE']")
        this.attachments=page.locator("//div[@id='COMMAND_DIALOG_ATTACHMENTS']")
        this.suppinfo=page.locator("//div[@id='EVENT_PANEL_SUPP_INFO']")
        this.SOPs=page.locator("//div[@id='WEB_SOPS_TITLE']")
        this.LOI=page.locator("//div[@id='EVENT_PANEL_LOI']")
        this.tags=page.locator("//div[@id='EVENT_PANEL_TAGS']")
       
    }
    
    async ValidateIncidentPanelDetails(Incident_ID,Incident_Type,Incident_Sub_Type,location)
    {   
        await expect(this.incidentid).toContainText(Incident_ID)
        expect(Incident_Type).toContain(await this.Incidenttypecode.textContent())
        expect(Incident_Type).toContain(await this.Incidenttype.textContent())
        expect(Incident_Sub_Type).toContain(await this.Incidentsubtypecode.textContent())
        expect(Incident_Sub_Type).toContain(await this.Incidentsubtype.textContent())
        await expect(this.location).toContainText(location)
        
    }
    

}
module.exports ={IncidentPanel}