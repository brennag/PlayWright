class IncidentContextMenu{
    constructor(page)
    {
        this.page =page;
        this.eventdetailspanel = page.locator("//div[contains(@class,'EventItem_eventDetailsPanel')]").first()
        this.incident =this.eventdetailspanel.locator("//span[starts-with(text(),'MPS')]")
        this.menubutton =page.locator("//button[contains(@class,'VerticalEllipsisButton')]").first()
        
    }

    async IncidentContextMenu(menuoption)
    {
        const Incident_ID = await this.incident.first().textContent()
        await this.menubutton.click()
        await this.page.waitForTimeout(1000)
        await this.page.getByRole('listitem', { name: menuoption }).click();
        
       
        console.log(`Pass: ${menuoption} selected from Context Menu  for incident :${Incident_ID}`)

        return Incident_ID
    }
}
module.exports={IncidentContextMenu}