const{ValidateIncidentcard}=require('./ValidateIncidentcard')

class IncidentCardContextMenu extends ValidateIncidentcard{
    constructor(page){
        super(page)
        this.page=page;
        this.searchresult =page.locator("//span[@class='results-title']")
        
    }

    async incidentcardcontextmenu(Incident_ID,menuoption)
    {
        await this.IncidentTab.click()
        await this.SearchIncidents.fill(Incident_ID)
        const result = await this.searchresult.textContent()
        await this.page.waitForTimeout(3000)
        if(result.includes(`Showing 1 results for "${Incident_ID}"`))
        {
            await this.searchdetails.dblclick()
            await this.page.waitForTimeout(3000)
            await this.page.locator(`//*[contains(text(),'${Incident_ID}')]/ancestor::*[contains(@class,'EventItem_header')]//*[contains(@class,'VerticalEllipsisButton')]`).click()
            await this.page.waitForTimeout(3000)
            await this.page.getByRole('listitem', { name: menuoption }).click();
            console.log(`Pass: ${menuoption} selected from Incident card Context Menu  for incident :${Incident_ID}`)
        }
        else{
            console.log(`Incident : ${Incident_ID} NOT available on the Incident board`)
        }

    }
}
module.exports={IncidentCardContextMenu}