const{CommonUtils}=require('../CommonUtils')
const{DialogOpen}=require('../General/DialogOpen')
const{expect}=require('@playwright/test')
class AssignResultCodeNew{
    constructor(page){
        this.page=page;
        this.CommonUtilspage=new CommonUtils(page)
        this.DialogOpenpage = new DialogOpen(page)
        this.incidentidfield = page.locator(`//*[@label='(LBL__AssignResultCode_IncidentID)']//*[contains(@class,'hxgn-inner-select__value-container')]`)
        // this.incidentidfield = page.locator(`//div[@class='hxgn-inner-select__value-container hxgn-inner-select__value-container--has-value css-1hwfws3']`)
        this.SubmitBtn = page.locator("//*[text()='Submit']")
    }

    clickingdropdown =(label)=> this. page.locator(`//div[@label='${label}']//span[@class='k-select']`).click()
    selectingvalue =(value)=>  this.page.locator(`//*[starts-with(text(),'${value}')]`).last().click();
    async assignresultcode(Incident_ID,Result_Code,Result_Classification,Qualifier,Resolution,tag)
    {
        await this.DialogOpenpage.DialogOpen('Assign Result Code',`ASSIGN RESULT CODES -e ${Incident_ID}`)
        await expect(this.incidentidfield).toContainText(Incident_ID)
        await this.clickingdropdown('(LBL__AssignResultCode_ResultCode)')
        await this.selectingvalue(Result_Code)
        await this.page.waitForTimeout(2000)
        await this.clickingdropdown('(LBL__AssignResultCode_ResultClassification)')
        await this.selectingvalue(Result_Classification)
        await this.page.waitForTimeout(2000)
        await this.clickingdropdown('(LBL__AssignResultCode_Qualifier)')
        await this.selectingvalue(Qualifier)
        await this.page.waitForTimeout(2000)
        await this.clickingdropdown('(LBL__AssignResultCode_Resolution)')
        await this.selectingvalue(Resolution)
        await this.page.waitForTimeout(2000)
        // await this.CommonUtilspage.SelectDropdownValue('(LBL__AssignResultCode_ResultCode)',Result_Code)
        // await this.CommonUtilspage.SelectDropdownValue('(LBL__AssignResultCode_ResultClassification)',Result_Classification)
        // await this.CommonUtilspage.SelectDropdownValue('(LBL__AssignResultCode_Qualifier)',Qualifier)
        // await this.CommonUtilspage.SelectDropdownValue('(LBL__AssignResultCode_Resolution)',Resolution)
        await this.page.locator(`//button[text()='${tag}']`).click()
        await this.SubmitBtn.click()

        //checking whether dialog closed
        if(!await this.DialogOpenpage.DialogOpen('Assign Result Code',null))
        {
            console.log(`Assign Result Code dialog closed successfully`)
        }
    }
}
module.exports={AssignResultCodeNew}