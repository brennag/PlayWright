const{expect, context} = require('@playwright/test')
const {PageObjects} = require('../../pageobjects/PageObjects');



class AssignResultCode{ 
    constructor(page){
        this.page =page
        this.assignResultCode_dialog = page.getByRole('button', { name: 'Assign Result Code – ×' })
        this.minmiseARCDialog_button = page.getByRole('button', { name: '–', exact: true })
        this.closeARCDialog_button = page.getByRole('button', { name: '×', exact: true })
        this.incidentID_dropdown = page.locator("//div[@class='hxgn-inner-select__value-container hxgn-inner-select__value-container--has-value css-1hwfws3']")
        this.LOIAvailableTime_datetimepicker = page.locator("//div[contains(@class,'react-datetime-picker__inputGroup')]")
        this.LOIDay_datepicker = page.locator('input[name="day"]')
        this.LOIMonth_datepicker = page.locator('input[name="month"]')
        this.LOIYear_datepicker = page.getByPlaceholder('----')
        this.LOIHour_datepicker = page.locator('input[name="hour24"]')
        this.LOIMinute_datepicker = page.locator('input[name="minute"]')
        //||
        //==>
            this.LOIBackYear_button = page.getByRole('button', { name: '«', exact: true })
            this.LOIBackMonth_button = page.getByRole('button', { name: '‹', exact: true })
            this.LOIForwardYear_button = page.getByRole('button', { name: '«', exact: true })
            this.LOIForwardMonth_button = page.getByRole('button', { name: '»', exact: true })
            //TODO - change this locator to be parameterised
            this.currentDateSelect_button = page.getByRole('button', { name: 'October 2019', exact: true })

        this.resultCode_dropdown = page.locator("//div[@name='(LBL__AssignResultCode_ResultCode)']//span[@class='k-select']")
        this.resultClassification_dropdown = page.locator("//div[@name='(LBL__AssignResultCode_ResultClassification)']//span[@class='k-select']")
        this.qualifier_dropdown = page.locator("//div[@name='(LBL__AssignResultCode_Qualifier)']//span[@class='k-select']")
        this.resolution_dropdown = page.locator("//div[@name='(LBL__AssignResultCode_Resolution)']//span[@class='k-select']")
        this.incidentSearchTag_searchbox = page.getByRole('searchbox', { name: 'Search Tags...' })
        this.incidentSearchTagCancel_button = page.locator('#ASSIGN-RESULT-CODE').getByRole('button').filter({ hasText: /^$/ }).first()
        this.showOnlySelected_toggle = page.locator('#ASSIGN-RESULT-CODE').getByRole('button').filter({ hasText: /^$/ })
        //TODO - parameterise the ARC TAg buttons.
        
        
        this.cancel_button = page.getByRole('button', { name: 'Cancel', exact: true })
        this.submit_button = page.getByRole('button', { name: 'Submit', exact: true })
    
}

async AssignResultCode(Incident_ID, ResultCode, ResultClassification, Qualifier, Resolution, Tag)
    {
    await expect (this.assignResultCode_dialog).toBeVisible();
    await expect (this.incidentID_dropdown).toContainText(Incident_ID);
    await this.resultCode_dropdown.click();
    await this.page.getByText(ResultCode).click();
    await this.resultClassification_dropdown.click();
    await this.page.getByText(ResultClassification).click();
    await this.qualifier_dropdown.click();
    await this.page.getByText(Qualifier).click();
    await this.resolution_dropdown.click();
    await this.page.getByText(Resolution).click();
    await ARCTag_button(Tag).click();
    await this.submit_button.click();

}

ARCTag_button = (value) => this.page.locator(`//*[contains(@class,"close-event-tags")]//*[text()='${value}']`);
    
}
module.exports ={AssignResultCode}