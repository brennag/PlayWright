const{DialogOpen}=require('../General/DialogOpen')
class IncidentSearchwithDateTime{
    constructor(page)
    {
        this.page=page;
        this.rangesettingdropdown = page.locator(`//*[contains(text(),'Range setting')]/parent::*//*[contains(@class,'select__dropdown-indicator')]`)
        this.DialogOpenpage = new DialogOpen(page)
        this.submitBtn = page.locator(`//*[@id="advanced-search-header-submit-btn"]`)
        this.dialogclosebutton = page.locator(`//*[contains(@class,'event-search-view')]//*[@class="min-max-btn close-btn"]`)
    }

    fromdateselect = (type)=> this.page.locator(`//*[contains(text(),'Date from')]/parent::*//*[@name="${type}"]`)
    ToDateselect =(type) => this.page.locator(`//*[contains(text(),'Date to')]/parent::*//*[@name="${type}"]`)

    //date and time to be passed like this ['10','6','2025'],['10','6','2025'],['4','25'],['6','19']
    async incidentsearchwithdatetime(startDate,endDate,startTime,endTime,incident_type_desc,incident_location)
    {  
        await this.DialogOpenpage.DialogOpen(`Incident Search`,'INCIDENT SEARCH') 
        await this.rangesettingdropdown.click()
        await this.page.locator(`//*[starts-with(text(),'Custom Date Range')]`).first().click();
        let [startDay,startMonth,startYear] =startDate
        let [endDay,endMonth,endYear] = endDate
        let [startHrs,startmin] = startTime
        let [endHrs,endmin]= endTime
        await this.fromdateselect('day').fill(startDay.toString())
        await this.fromdateselect('month').fill(startMonth.toString())
        await this.fromdateselect('year').fill(startYear.toString())
        await this.fromdateselect('hour24').fill(startHrs.toString())
        await this.fromdateselect('minute').fill(startmin.toString())
        await this.ToDateselect('day').fill(endDay.toString())
        await this.ToDateselect('month').fill(endMonth.toString())
        await this.ToDateselect('year').fill(endYear.toString())
        await this.ToDateselect('hour24').fill(endHrs.toString())
        await this.ToDateselect('minute').fill(endmin.toString())
        await this.submitBtn.click()

        await this.page.waitForTimeout(3000)
        let idlocator=`//*[contains(text(),'${incident_type_desc}')]/parent::*/parent::*/following-sibling::*
        //*[contains(text(),'${incident_location}')]/parent::*/parent::*/following-sibling::*//*[contains(text(),'MPS2')]`

        if(this.page.locator(idlocator).isVisible()){
            let Incident_ID = (await this.page.locator(idlocator).first().textContent()).trim()
            await this.dialogclosebutton.click()
            return Incident_ID
        }
        else{
            console.log(`Requested Incident is not found`)
            await this.dialogclosebutton.click()
            return false
        }  

    }
}
module.exports ={IncidentSearchwithDateTime}