const{DialogOpen}=require('../General/DialogOpen')
const{CommonUtils}=require('../CommonUtils')
const{CreateCrossReference} = require(`../Incident/CreateCrossReference`)
const{expect }=require('@playwright/test')
const{appendToLogFile}=require('../../tests/testlogs')
class AssociatedIncident{
    constructor(page)
    {
        this.page=page;
        this.DialogOpenpage =new DialogOpen(page)
        this.CommonUtilspage = new CommonUtils(page)
        this.CreateCrossReferencepage= new CreateCrossReference(page)
        this.SubmitBtn = page.locator(`//button[text()='Submit']`)
        //this.Rangesettingdropdown = page.locator(`//div[contains(text(),'Range setting')]/following-sibling::*//*[contains(@class,"select__dropdown")]`)
        //this.AdvancedSearch = page.locator(`//*[@id="btnAdvancedEventSearch"]`)
        //this.submitbutton = page.locator(`//*[contains(@class,'advance-search-criteria')]//*[@class="btn btn-primary submit-btn"]`)
    }
    async CreateAssociatedIncident(PrimaryIncident_ID,IncidentType,IncidentSubType)
    {     
        await this.page.bringToFront()
        await this.DialogOpenpage.DialogOpen('Create Associated Incident','Create Associated Incident')
        await this.CommonUtilspage.SelectDropdownValue("(LBL_Associated_IncidentID)",PrimaryIncident_ID)
        await this.CommonUtilspage.SelectDropdownValue("(LBL_Associated_EventType)",IncidentType)
        await this.CommonUtilspage.SelectDropdownValue("(LBL_Associated_SubType)",IncidentSubType)
        //await this.page.waitfortimeout(2000)
        await this.page.waitForTimeout(3000)
        await this.SubmitBtn.click()
        //await this.page.pause()
        //this.CommonUtilspage.SelectDropdownValue(IncidentType)
    }
}module.exports={AssociatedIncident}