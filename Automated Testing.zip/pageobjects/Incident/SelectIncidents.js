//For this class while calling pass mappage as a page.
const{InvokeCommand}=require('../General/InvokeCommand')
const{expect}= require('@playwright/test')
const{appendToLogFile}=require('../../tests/testlogs')
const{CommonUtils}=require('../CommonUtils')
class SelectIncident
{
    constructor(page)
    {
        this.page =page;
        this.CommandLine =page.locator("[title='Command Line']");
        this.InputCommand =page.getByPlaceholder('Command Line...');
        this.panelcontent = page.locator("event-panel-remarks-content").nth(1);
        this.CommonUtilspage = new CommonUtils(page)
    }

    async SelectIncident(IncidentId)
    {
        await this.CommonUtilspage.DismissAllNotifications(this.page)
        const InvokeCommandpage=new InvokeCommand(this.page)
        await InvokeCommandpage.invokecommand(`Select Incident -e ${IncidentId}`)
        await this.page.waitForTimeout(10000)
        // await this.page.locator(`//div[@class='event-panel-header']`).waitFor()
        // await expect(this.page.locator(`//div[@class='event-panel-header']`)).toBeVisible()
        let isincidentpanelopened = await this.page.locator(`//span[@class='dialog-text-display ' and starts-with(text(),'${IncidentId}')]`).isVisible()
        if(isincidentpanelopened){
            appendToLogFile(`Pass:Incident panel opened for Incident ${IncidentId}`)
            return true
        }
        else{
            appendToLogFile(`Fail:Incident Panel not opened for incident ${IncidentId}`)
            return false
        }
      
    }
}

module.exports ={SelectIncident}