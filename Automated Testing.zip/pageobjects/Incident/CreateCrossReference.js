const { expect } = require('@playwright/test');
const { CommonUtils } = require('../CommonUtils');
const { DialogOpen } = require(`../General/DialogOpen`);
const { InvokeCommand } = require(`../General/InvokeCommand`);
const { SelectIncident } = require('../Incident/SelectIncidents');
const {SearchComments} = require ('../CreateContact/SearchComments');
const {appendToLogFile } = require('../../tests/testlogs');
const { clear } = require('console');
class CreateCrossReference {
    constructor(page) {
        this.page = page;
        this.CancelBtn = page.locator("//button[text()='Cancel']")
        this.CreateBtn = page.locator("//button[text()='Create']")
        this.CRsectionexpanded = page.locator ("//*[@class='cross-ref-events-wrapper open']")
        this.CRsection = page.locator ("//*[contains(@class, 'cross-ref-events-indicator')]")
        this.HideCRSection= page.locator (`//img[@title="Hide"]`)
        this.tearoff = page.locator(`//*[contains(@class,"open-tear-off")]`)
        this.NoOfIncidentsinCRDialog=page.locator(`//*[@label='(LBL_CrossReference_Incidents_Area)']//*[contains(@class,"ReactVirtualized__Table__row ReactVirtualized__Table__row")]`)
        this.IncidentIDinCRDialog= page.locator(`//*[@label='(LBL_CrossReference_Incidents_Area)']//*[@aria-label="row"]//*[@aria-colindex="4"]`)
        this.NoOfIncidentsinCRSection= page.locator(`//*[contains(@class,"ReactVirtualized__Table__row ReactVirtualized__Table__row")]`)
        this.IncidentIDinCRSection = page.locator(`//*[@aria-label="row"]//*[@aria-colindex="4"]`)
        this.ContextMenuinCRSection = page.locator (`//*[@aria-label="row"]//*[@aria-colindex="6"]`)
        //this.CheckboxinCRSection = page.locator (`//*[@aria-label="row"]//*[@aria-colindex="1"]//*[contains(@class, 'hxgn-checkbox')]`)
        this.CheckboxinCRSection = page.locator(`//input[contains(@class, "cd-tabbable-focused") and @type="checkbox"]`)
        this.OpenContextMenuinCRSection = page.locator(`//*[contains(@id,"cross-ref-touch-context-menu")] //*[text()="View incident panel"]`)
        //this.ReasonforCancellation= page.locator(`//*[text() =  "Enter reason for cancellation"]`)
        this.ReasonforCancellation= page.locator(`//*[text() =  "Enter reason for cancellation"]/following-sibling::*//input`)
        this.ReasonforCancellationBtn = page.locator(`//button[text() =  "Cancel Cross Reference"]`)

    }
    async CreateCrossReference(PrimaryIncidentID, IncidentID1, Comment) {
        const DialogOpenpage = new DialogOpen(this.page)
        const CommonUtilspage = new CommonUtils(this.page)
        //const InvokeCommandpage = new InvokeCommand(this.page)
        //const SeachCommentspage = new SearchComments(this.page)

        //await InvokeCommandpage.invokecommand('cross reference')
        await this.page.bringToFront()
        await DialogOpenpage.DialogOpen('cross reference', 'cross reference')
        await CommonUtilspage.SelectDropdownValue('(LBL_CR_FROM_INCIDENT)', PrimaryIncidentID)
        await CommonUtilspage.SelectDropdownValue('(LBL_CR_TO_INCIDENT)', IncidentID1)
        await CommonUtilspage.SelectDropdownValue('(LBL_CR_REASON)', Comment)
        await this.CreateBtn.click()
        await this.page.waitForTimeout(30000)
        let IsDialogOpen = await DialogOpenpage.DialogOpen('Copy Incident Information',null)
        console.log (IsDialogOpen)
        if (IsDialogOpen)
        {
            await this.page.locator(`//button[text()='Submit']`).click()
        }
        else
        {
            console.log('Copy Incident Information dialog is not opened')
            appendToLogFile (`Fail: Copy Incident Information dialog is not opened`)
        }
    }
    async CancelCrossReference(PrimaryIncidentID, IncidentID, Comment) {
        const SelectIncidentpage = new SelectIncident(this.page)
        await SelectIncidentpage.SelectIncident(PrimaryIncidentID)
        await this.page.bringToFront()
        await this.CRSectionOpen()
        //await this.VerifyCrossReference(PrimaryIncidentID,InidentID)
        let found = await this.VerifyCRinDialog(PrimaryIncidentID,IncidentID)
        if (found==0)
        {
        await this.page.waitForTimeout(2000)
        await this.CheckboxinCRSection.click({force: true})
        //await this.ReasonforCancellation.click()
        await this.ReasonforCancellation.fill(Comment)
        await this.page.keyboard.press("Tab")
        await this.ReasonforCancellationBtn.click()
        
        
        if(await this.page.locator(`//*[contains(@class, "modal-confirm-dialog")]`).isVisible())
        {
            await this.page.locator(`//*[text() ="OK"]`).click()
            //return 0
        }
        else{
            console.log ("confirmation dialog to cancel the cross reference was not popped up.")
           // return -1
        }
        await this.page.locator (`//img[@title="Hide"]`).click()
        await this.CRCommentsValidation(IncidentID,"Cancel")
    }
    
    else
    {
        console.log (`${PrimaryIncidentID} and ${IncidentID} are not cross referenced`)
    }

    }

    async BufferTimeValidation(appTimeString) {
        const buffer = 200; // seconds
        //const appTimeString = '14/05/2025 10:14:05'; // example timestamp from your app
        function parseAppTime(str) {
            const [day, month, year, hour, minute, second] = str.match(/\d+/g).map(Number);
            return new Date(year, month - 1, day, hour, minute, second);
        }
        const appTime = parseAppTime(appTimeString);
        const now = new Date();
 //       console.log (appTime)
 //       console.log(now)
        const diffInSeconds = (now - appTime) / 1000;
//        console.log(diffInSeconds)
        if (diffInSeconds >= -buffer && diffInSeconds <= buffer) {
            //console.log(`Time is within ±${buffer} seconds of app time`);
            return 0
        } else {
            //console.log(`Time difference exceeds ±${buffer} seconds`);
            return -1
        }
        //console.log(`Actual difference: ${diffInSeconds.toFixed(2)} seconds`);
       
    }

    async fetchingUsernameFromMenu(){
        await this.page.locator(`//*[@class="oc-navbar-toggle"]`).click();
        await this.page.waitForTimeout(1000);
        const userName = await this.page.locator(`//*[@id="user-area"]//*[@class="name-appearance"]`).textContent();
        await this.page.waitForTimeout(1000);
        await this.page.locator(`//*[@class="oc-navbar-toggle"]//*[@class="close-btn"]`).click();
        await this.page.waitForTimeout(1000);
        //console.log(userName)
        return(userName);
       
    } 
    async UserNameValidation(UserNameFromComments)
    {
        let UserNameFromMenu = await this.fetchingUsernameFromMenu()
        //UserNameFromComments = foundUserName.substring(receviedComment.lastIndexOf(':') + 1).trim();
        //console.log("Usernamefrommeny  =="+UserNameFromMenu)
        //console.log("UserNameFromComments  =="+UserNameFromComments)

        function normalizeParts(name) {
            return String (name)
              .replace(',', '')              // Remove commas
              .trim()
              .toLowerCase()
              .split(/\s+/);                 // Split into name parts
          }
        function containsAllParts(UserNameFromMenu, UserNameFromComments) {
            const sourceParts = normalizeParts(UserNameFromMenu);
            const targetParts = normalizeParts(UserNameFromComments);
            //console.log(sourceParts)
            //console.log(targetParts)
            return sourceParts.every(part => targetParts.includes(part));
          }
          
          const result = containsAllParts(UserNameFromMenu, UserNameFromComments);
          return result; 
   
    }

    async CRCommentsValidation(IncidentID,CRAddCancel)
    {
        const SeachCommentspage = new SearchComments(this.page)

        let comment 

        if (CRAddCancel =="Cancel")
        {
            comment = `Cross Reference Canceled to Event # ${IncidentID}  at: `
        }
       else if (CRAddCancel == "Add")
       {
        comment = `Cross Referenced to Event # ${IncidentID}  at: `
       }
        
        console.log (comment)
        let foundtext= await SeachCommentspage.searchcomments(comment)
        await this.page.waitForTimeout(2000)
        const foundDate = foundtext.match(/\b\d{2}\/\d{2}\/\d{4} \d{2}:\d{2}:\d{2}\b/)
     
        let output = await this.BufferTimeValidation(foundDate[0])
        if (output == 0)
        {
            let UserNameFromComments = foundtext.substring(foundtext.lastIndexOf(':') + 1).trim()
            //console.log (UserNameFromComments)
            //await this.page.pause()
            //let UserNameFromComments = UserName.match(/^[A-Za-z\s]+/)[0].trim()
            let result = await this.UserNameValidation(UserNameFromComments)
            //console.log (result)
            if (result)
            {console.log (`Pass: cross reference Comments are added correctly: ${foundtext}`)
            appendToLogFile (`Pass: cross reference Comments are added correctly: ${foundtext}`)
            }
            else 
            {console.log (`Fail: Cross reference comments are not added correctly.${foundtext}`)
            appendToLogFile(`Fail: Cross reference comments are not added correctly.${foundtext}`)
            }
       
        }
        else{
            console.log ("Fail: No need to validate username as timestamp validation failed for corss reference comments")
            appendToLogFile("Fail: No need to validate username as timestamp validation failed for corss reference comments")
        }
        
    }

    async CRSectionOpen(){
    
        if (await this.CRsectionexpanded.isVisible())
        {
            console.log("Cross reference section already expanded")
            return true
        }
        else {
            await this.CRsection.click()
            return true
        }
    }
    async CRSectionHide(){
        if (await this.CRsectionexpanded.isVisible())
        {
            await this.HideCRSection.click()
        }
        else
        {
            console.log("Cross reference section is already hidden")
        }
    }
    async VerifyCRinDialog(PrimaryIncidentID, IncidentIDs) {
        //const SelectIncidentpage = new SelectIncident(this.page)
        //const inDialog = CRDialog == "CrossReference" ? `//*[@label='(LBL_CrossReference_Incidents_Area)']` : ''
        //await SelectIncidentpage.SelectIncident(PrimaryIncidentID)
        //await this.page.bringToFront()
        //await this.CRSectionOpen()
       // if (CRDialog == "CrossReference") {
            await this.tearoff.click()
        //}
        await this.page.waitForTimeout(5000)
        
        let element = await this.NoOfIncidentsinCRDialog.count();
        console.log(`Verified on Cross Reference Incidents dialog: Number of Incidents:`, element);
        appendToLogFile (`Verified on Cross Reference Incidents dialog: Number of Incidents:`, element)
        let found = 1
        for (let i = 0; i < element; i++) {
            let IncidentFound = await this.IncidentIDinCRDialog.nth(i).textContent()
            for (let k = 0; k < IncidentIDs.length; k++) {
                if (IncidentFound == IncidentIDs[k]) {
                    found = 0
                    console.log(`Verfied on Cross Reference Incident Dialog: Incidents ${PrimaryIncidentID} and ${IncidentIDs[k]} are cross referenced`);
                    //return 0;
                    break;
                }
            }
            if (found == 1) {
                console.log(`Incident ${IncidentFound} is not cross referenced to ${PrimaryIncidentID} incident`)
                //return -1

            }
        }
        if (await this.page.locator(`//*[contains(@class, 'cross-reference-view')]//*[contains(@class,'dialog-header')]`).nth(1).isVisible()) {
            await this.page.locator(`//*[contains(@class, "cross-reference-view")]//button[@title ="Close"]`).click()
        }
        console.log (found)
        return(found)
    }

    async VerifyCrossReference(PrimaryIncidentID, IncidentIDs) {
        //Open the incident panel for the primary incident ID
        const SelectIncidentpage = new SelectIncident(this.page)
        await SelectIncidentpage.SelectIncident(PrimaryIncidentID)
        await this.page.bringToFront()
        await this.CRCommentsValidation(IncidentIDs[0],"Add")
        //await this.CRCommentsValidation(IncidentIDs[1]) - This isn't needed for 2 incidents other than the primary one, need to check how we can validate this for primary incident.
        //To check whether the Cross section is alredy opened, and if not it will open the section
        await this.CRSectionOpen()
        await this.VerifyCRinDialog(PrimaryIncidentID, IncidentIDs)
            //to get the number of incidents cross referenced to the primary incident
            
            let element = await this.NoOfIncidentsinCRSection.count()
            console.log(`Number of cross referenced incidents:`, element);
            let found = 1
            for (let i = 0; i < element; i++) {//for all the cross referenced incidents
              let IncidentFound = await this.IncidentIDinCRSection.nth(i).textContent()//read the incidentID
                for (let k = 0; k < IncidentIDs.length; k++) {//compare against all the list of incidents sent to the function
                    if (IncidentFound == IncidentIDs[k]) {
                        found = 0
                        console.log(`Incidents ${PrimaryIncidentID} and ${IncidentIDs[k]} are cross referenced`);
                        await this.ContextMenuinCRSection.nth(i).click()//click on the context menu
                        await this.OpenContextMenuinCRSection.click()//to open incident panel*/
                        await this.page.waitForTimeout(10000)
                        //to check whether the incident panel for the cross referenced incident is opened or not.
                        let incidentpanelopened = await this.page.locator(`//span[@class='dialog-text-display ' and starts-with(text(),'${IncidentIDs[k]}')]`).isVisible()//to check whethe the incident anel for t he cross referenced incident is opened or not.
                        if(incidentpanelopened){
                            appendToLogFile(`Pass:Incident panel opened from the context menu for Incident ${IncidentIDs[k]}`)
                            console.log (`Incident panel opened from the context menu for the cross referenced incident ${IncidentIDs[k]}`)
                            
                            await this.page.locator(`//*[contains(@class, 'hide-event-panel')]`).click() //Close the incident panel of the CR'ed incident
                            await SelectIncidentpage.SelectIncident(PrimaryIncidentID)//open the incident panel for the primary incident.
                            await this.CRSectionOpen()//to check whether cross reference section is expanded or not.
                            //return true
                        }
                        else{
                            appendToLogFile(`Fail:Incident Panel not opened from the context menu for incident ${IncidentIDs[k]}`)
                            await this.page.locator(`//*[contains(@class, 'hide-event-panel')]`).click() //Close the incident panel of the CR'ed incident
                            await SelectIncidentpage.SelectIncident(PrimaryIncidentID)//open the incident panel for the primary incident.
                            await this.CRSectionOpen()//to check whether cross reference section is expanded or not.
                            //return false
                        }
                        break;
                    }
                    if (found == 1) {
                        console.log(`Incident ${IncidentFound} is not cross referenced to ${PrimaryIncidentID} incident`)
                        appendToLogFile(`Incident ${IncidentFound} is not cross referenced to ${PrimaryIncidentID} incident`)
                        break;
                    }
                }
                
            }
        //else {
                //appendToLogFile(`Fail:Incident Panel not opened for incident ${IncidentId}`)
               // return false


            }
        }
    module.exports = { CreateCrossReference }
