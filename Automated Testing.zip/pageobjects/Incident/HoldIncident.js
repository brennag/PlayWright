const{DialogOpen}=require('../General/DialogOpen')
const{CommonUtils}=require('../CommonUtils')
class HoldIncident{
    constructor(page){
        this.page=page;
        this.DialogOpenpage= new DialogOpen(page)
        this.CommonUtilspage= new CommonUtils(page)
        this.holdminutesduration = page.locator(`//*[@id="holdMinuteInput"]`)
        this.SubmitBtn = page.locator("//*[contains(@class,'btn btn-primary submit-btn cd')]")
        
    }
    async HoldIncident(Incident_ID, duration,Unit_Id,Unit_Type)
    {
        await this.DialogOpenpage.DialogOpen('Hold Incident','HOLD INCIDENT')
        await this.CommonUtilspage.SelectDropdownValue('(lbl_HoldIncident_IncidentID)',Incident_ID)
        if(duration){
            await this.holdminutesduration.fill(duration)
        }
        else{
            console.log(`Hold Minute duration not provided. default vakue selected`)
        }
        if(Unit_Id){
            await this.CommonUtilspage.SelectDropdownValue('(lbl_HoldIncident_Unit)',Unit_Id)
        }
        else{
            console.log(`Hold Incident Unit Id not provided`)
        }
        if(Unit_Type){
            await this.CommonUtilspage.SelectDropdownValue('(lbl_HoldIncident_UnitType)',Unit_Type)
        }
       
        await this.CommonUtilspage.EnterText('lbl_HoldIncident_Remark','holding incident for test')
        await this.SubmitBtn.click()

    }
}
module.exports={HoldIncident}