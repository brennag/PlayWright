const{IncidentAdvSearch}=require('./IncidentAdvSearch')
const{DialogOpen}=require('../General/DialogOpen')
const{expect}=require('@playwright/test')
class CloseIncident{
    constructor(page){
        this.page=page
        this.DialogOpenpage =new DialogOpen(page)
        this.incidentid = page.locator(`//*[@label='(LBL_CloseIncident_IncidentID)']`)
        this.resultcode = page.locator(`//*[@label='(LBL_CloseIncident_ResultCode)']//input[@type='text']`)
        this.resultclassification = page.locator(`//*[@label='(LBL_CloseIncident_ResultClassification)']//input[@type='text']`)
        this.qualifier = page.locator(`//*[@label='(LBL_CloseIncident_Qualifier)']//input[@type='text']`)
        this.resolution = page.locator(`//*[@label='(LBL_CloseIncident_Resolution)']//input[@type='text']`)
        //this.showonlyselected = page.locator(`//*[@class="toggle-button"]`)
        this.showonlyselected = page.locator(`//*[@label="(LBL_CloseIncident_SearchTags)"]//*[@class="toggle-button"]`)
        this.submitBtn =page.locator(`//*[contains(@class,'main-command-dialog-container')]//*[text()='Submit']`)
    }

    async closeIncident(Incident_ID,Result_Code,Result_Classification,Qualifier,Resolution,tag)
    {
       const IncidentAdvSearchpage = new IncidentAdvSearch(page)
       let found=true
       await this.DialogOpenpage.DialogOpen('Close Incident',`CLOSE -e ${Incident_ID}`)
       console.log((await this.incidentid.textContent()).trim())
       await expect(this.incidentid).toContainText(Incident_ID)
       if((await this.resultcode.inputValue()).includes(Result_Code)){
        console.log(`Result code:${Result_Code} matched in Close Incident dialog`)
       }else{
        console.log(`Result code:${Result_Code} NOT matched in Close Incident dialog`)
        found =false;
       }
       if((await this.resultclassification.inputValue()).includes(Result_Classification)){
        console.log(`Result Classification:${Result_Classification} matched in Close Incident dialog`)
       }else{
        console.log(`Result Classification:${Result_Classification} NOT matched in Close Incident dialog`)
        found =false;
       }
       if((await this.qualifier.inputValue()).includes(Qualifier)){
        console.log(`Qualifier:${Qualifier} matched in Close Incident dialog`)
       }
       else{
        console.log(`Qualifier:${Qualifier} NOT matched in Close Incident dialog`)
        found=false
       }
       if((await this.resolution.inputValue()).includes(Resolution)){
        console.log(`Resolution:${Resolution} matched in Close Incident dialog`)
       }
       else{
        console.log(`Resolution:${Resolution} NOT matched in Close Incident dialog`)
        found=false;
       }
       let selectedTags = await this.selectedTags()
       console.log(selectedTags)
       if(selectedTags.includes(tag)){
        console.log(`Tag:${tag} correctly selected in Close Incident dialog`)
       }
       else{
        console.log(`Tag:${tag} NOT  selected in Close Incident dialog`)
        found =false
       }
       if(found){
        console.log(`Pass: All details correctly shown in close incident`)
       }
       else{
        console.log(`Fail: All details NOT correctly shown in close incident`)
       }
       
       await this.submitBtn.click()
       await this.page.waitForTimeout(3000)
       if(await this.page.locator(`//*[contains(text(),'Incident ${Incident_ID} was unable to close')]`).isVisible()){
        await this.submitBtn.click()
        await this.page.waitForTimeout(2000)
        await this.submitBtn.click()
       }
       const Incident_status =await IncidentAdvSearchpage.incidentAdvSearch(null,Incident_ID,null)

       if(Incident_status=='Closed'){
        console.log(`Pass:  Incident ${Incident_ID} is closed Successfully`)
        return true
       }
       else{
        console.log(`Fail :Incident ${Incident_ID} is NOT closed Successfully`)
        return false
       }

    }

    async selectedTags()
    {
        this.showonlyselected.click()
        let allSelectedTags =[]
        const tag=await this.page.locator(`//*[@class="tag selected"]`)
        for(let i=0;i<await tag.count();i++){
            allSelectedTags.push(await tag.nth(i).textContent())
        }
        return allSelectedTags
    }
}
module.exports={CloseIncident}
