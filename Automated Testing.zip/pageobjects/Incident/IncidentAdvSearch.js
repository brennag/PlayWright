const{DialogOpen}=require('../General/DialogOpen')
const{CommonUtils}=require('../CommonUtils')
const{expect }=require('@playwright/test')
const{appendToLogFile}=require('../../tests/testlogs')
class IncidentAdvSearch{
    constructor(page)
    {
        this.page=page;
        this.DialogOpenpage =new DialogOpen(page)
        this.CommonUtilspage = new CommonUtils(page)
        this.Rangesettingdropdown = page.locator(`//div[contains(text(),'Range setting')]/following-sibling::*//*[contains(@class,"select__dropdown")]`)
        this.AdvancedSearch = page.locator(`//*[@id="btnAdvancedEventSearch"]`)
        this.submitbutton = page.locator(`//*[contains(@class,'advance-search-criteria')]//*[@class="btn btn-primary submit-btn"]`)
        this.dialogclosebutton = page.locator(`//*[contains(@class,'event-search-view')]//*[@class="min-max-btn close-btn"]`)
    }

    // It takes two input parameters Incident id, incident status : Open/Closed. if only incidentid provided , it will return status . if only status provided it will return a set of incidents
    async incidentAdvSearch(Range,Incident_Id,Incident_status)
    {
        await this.DialogOpenpage.DialogOpen('Incident Search','INCIDENT SEARCH')
        await this.Rangesettingdropdown.click()
        if(Range){
            await this.page.locator(`//*[starts-with(text(),'${Range}')]`).last().click();   
        }
        else{
            await this.page.locator(`//*[starts-with(text(),'Past 1 Month')]`).last().click();
        }
        await this.AdvancedSearch.click()
        if(Incident_Id !=null && Incident_status==null)
        {
            await this.CommonUtilspage.EnterText('LBL_IncidentSearch_INCIDENT_ID',Incident_Id)
            await this.submitbutton.click()
            await this.page.waitForTimeout(3000)
            if(!await this.searchresultsfound()){
                await this.dialogclosebutton.click()
                return false;
            }
            let isContactActive= await this.page.locator(`//*[@title="${Incident_Id}"]/parent::*/following-sibling::*//*[@class='fa fa-star ng-scope']`).isVisible()
            if(isContactActive){
                Incident_status='Open'
            }
            else{
                Incident_status='Closed'
            }
            await this.dialogclosebutton.click()
            return Incident_status;
        }
        else if(Incident_Id ==null && Incident_status!=null)
        {
            await this.CommonUtilspage.SelectDropdownValue(`(LBL_IncidentSearch_OpenClosed)`,Incident_status)
            await this.submitbutton.click()
            await this.page.waitForTimeout(3000)
            if(!await this.searchresultsfound()){
                await this.dialogclosebutton.click()
                return false;
            }
            const str = await this.page.locator(`//*[contains(@class,"pager-count-container")]`).textContent();
            const match = str.match(/of (\d+) items/);
            const noOfRows = parseInt(match[1]);
            console.log(`Total incidents: ${noOfRows}`);
     
            const AllIncidents = new Set();
            let pagination = 100;
            let currentPage = parseInt(await this.page.locator(`//*[@aria-label="Selected page"]`).inputValue());
            let maxRepeats = 20;
            let repeatCount = 0;
     
            while (AllIncidents.size < noOfRows && repeatCount < maxRepeats) {
              const visibleEventLinks = this.page.locator(`//a[starts-with(@id, "EventId-")]`);
              const count = await visibleEventLinks.count();
           
              let foundNew = false;
           
              for (let i = 0; i < count; i++) {
                const el = visibleEventLinks.nth(i);
                const id = (await el.textContent())?.trim();
                if (id && !AllIncidents.has(id)) {
                    AllIncidents.add(id);
                //   console.log(`Collected (${AllIncidents.size}/${noOfRows}): ${id}`);
                  foundNew = true;
                }
              }
         
              // If no new incidents are found, increment repeat counter
              repeatCount = foundNew ? 0 : repeatCount + 1;
         
              // Scroll to load more rows
              await this.page.locator(`(//*[@role="presentation"]//*[@role="rowgroup"])[2]`).hover();
              await this.page.mouse.wheel(0, 100);
              await this.page.waitForTimeout(300);
         
              // Check for pagination when we hit batch limits
              if (AllIncidents.size >= pagination) {
                await this.page.locator(`(//*[@role="presentation"]//*[@role="rowgroup"])[2]`).hover();
                await this.page.mouse.wheel(0, -10000);
                await this.page.locator(`//*[@aria-label="Page forward"]`).click();
                await this.page.waitForTimeout(3000);
                currentPage += 1;
                pagination += 100;
              }
            }
     
            if (AllIncidents.size === noOfRows) {
              console.log('All incidents collected!');
            } else {
              console.log(`Collected only ${AllIncidents.size} of ${noOfRows}`);
            }
            await this.dialogclosebutton.click()
            return AllIncidents
        }
        else if(Incident_Id !=null && Incident_status!=null) 
            {
                await this.CommonUtilspage.EnterText('LBL_IncidentSearch_INCIDENT_ID',Incident_Id)
                await this.CommonUtilspage.SelectDropdownValue(`(LBL_IncidentSearch_OpenClosed)`,Incident_status)
                await this.submitbutton.click()
                await this.page.waitForTimeout(3000)
                if(!await this.searchresultsfound()){
                    await this.dialogclosebutton.click()
                    return false;
                }
                await expect(this.page.locator(`//*[contains(@id,'EventId')]`)).toContainText(Incident_Id)
                let isContactActive= await this.page.locator(`//*[@title="${Incident_Id}"]/parent::*/following-sibling::*//*[@class='fa fa-star ng-scope']`).isVisible()
                if(Incident_status=='Open'){
                    await expect(isContactActive).toBeTruthy()   
                    appendToLogFile(`Pass: Advanced Incident search shows ${Incident_Id} as 'active' while incident status provided as ${Incident_status}`)
                    await this.dialogclosebutton.click()
                    return true
                }
                else if(Incident_status=='Closed'){
                    await expect(isContactActive).toBeFalsy()
                    appendToLogFile(`Pass: Advanced Incident search shows ${Incident_Id} as 'closed' while incident status provided as ${Incident_status}`)
                    await this.dialogclosebutton.click()
                    return true
                }
            }  
         else if(Incident_Id ==null && Incident_status==null)
            {
                console.log(`No inputs provided for incident advanced search`)
                await this.dialogclosebutton.click()
                return false
            } 
        await this.dialogclosebutton.click()
    }

    async searchresultsfound()
    {
        if(await this.page.locator(`//*[contains(text(),'No results for the given input search criteria')]`).isVisible()){
            console.log(`No results found for the given input search criteria`)
            return false
        }
        return true
    }
}
module.exports={IncidentAdvSearch}