const{DialogOpen}=require('../General/DialogOpen')
const{CommonUtils}=require('../CommonUtils')
class ReopenIncident{
    constructor(page){
        this.page=page;
        this.DialogOpenpage= new DialogOpen(page)
        this.CommonUtilspage= new CommonUtils(page)
        this.SubmitBtn = page.locator("//*[contains(@class,'btn btn-primary submit-btn cd')]")

        
    }
    async ReopenIncident(Incident_ID, Remarks)
    {
        await this.DialogOpenpage.DialogOpen('Reopen Incident','Reopen Incident')
        await this.CommonUtilspage.EnterText('LBL_ReOpen_IncidentID', Incident_ID)
        await this.CommonUtilspage.EnterText('LBL_ReOpen_Remarks',Remarks)
        await this.SubmitBtn.click()

        if(!await this.DialogOpenpage.DialogOpen('Reopen Incident',null))
            {
                console.log(`Reopen Incident dialog closed successfully`)
            }

    }
}
module.exports={ReopenIncident}