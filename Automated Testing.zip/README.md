# Introduction 
This Repo is to store Automated tests made using PlayWright for use with OnCall. 

# Getting Started
1. SW Required; VSCode with plugins (PlayWright for VSCode, JavaScript (ES6) code snippets, Azure Tools, Allure Support)
2. Install PlayWright by typing the following in the VSCode Terminal - "npm install playwright" AND "npm init playwright@latest"
3. Connect to Repo via Azure Tools
4. Generate a project within PlayWright
5. Add project to remote repo
6. Clone the path
7. Each person can contribute and merge code
8. If using Git, you will need to cd to your dir and run git init followed by git add. (if you have files you already want to upload)

# Connecting to Repo and Working with code branches (First time)
1. Connect to VM
2. Open VS Code and a Browser to the Repo you want to work on
3. From the browser, select Clone > Clone in VS Code
4. Locate a local folder on the VM to clone the repo to
5. Install PlayWright (overwrite files as appropriate)
6. Make changes to file(s) as appropriate
7. Select Source control
8. Select Commit (add a commit comment)
9. Sync changes

# Continuing to work with Repo
1. Ensure you are using the latest version of code from Repo by Refreshing
2. Synchronise changes

# Build and Test
1. Use an env file to define the environment
2. Use an auth file to save auth login state
3. Use page objects to build up locators on a page

# Source Control
Whilst working with the Azure Repo, it is imperitive that the code you are working on is the latest version.  In order to check this is the case, please adhere to the following steps;

To connect to the repo to begin work, you will need to;
1. Create a local directory on whichever machine you are working on.
2. Navigate to the repo on that same machine https://dev.azure.com/hexagon-si-emea/UK/_git/Automated%20Testing
3. Select Clone
4. Select Clone in VS Code
5. Follow the prompts to open the code in VS Code.

You should now have a working copy of the repo locally, which you can work with.

To commit changes to the repo;
1. Make your changes locally
2. Save your changes and close your updated files
3. Select Source Control (in VS Code) - a list of the changes will appear in a list 
4. Select Commit
5. Type a comment, which summarises the changes, which have taken place
6. Select the Tick button on the right hand side
7. Select Sync to push and pull all changes

To check you are working on the latest code within VS Code
1. Select Source Control
2. Select Synchronise changes (on master branch)


# Best Practice
In order to organise PlayWright tests correctly start by establishing the following 

To generate tests;
1. Use CodeGen to build a skeleton script
2. Refine the script
3. Add assertions

All Tests should adhere to the F.I.R.S.T principle, they should be Fast, Independant, Repeatable, Self-Validating, Thorough.

We should avoid third party dependencies

Before creating test scripts, we need to find all the locators on the page and store them in a page object so that if something changes on that page, we only need to update once

PlayWright prefers to use user facing elements rather than rely on DOM structures of CSS classes

Use Web assertions rather than manual assertions.  Use assertions such as;
* Element present / Not present
* Visible / Hidden
* Enabled / Disabled
* Text matches value
* Element attribute

Use soft assertions to record where the script has varied from the execution without halting the test, such as 

// Make a few checks that will not stop the test when failed...

await expect.soft(page.getByTestId('status')).toHaveText('Success');

// ... and continue the test to check more things.

await page.getByRole('link', { name: 'next page' }).click();

Use logged in state to skip the login process and begin tests immediately

Naming Conventions

Each locator should follow the following format so that it is readable.  
Choose meaningful names that convey the purpose of the variable or function. Consistent naming conventions enhance clarity and maintainability.

Some examples
* Camel Case = userName_textbox
* Snake Case = user_name_texbox
* Kebab Case = user-name-textbox



Reporting for PlayWright will be provided by Allure https://allurereport.org/docs/playwright/

Ultimate Goals for tests

* Use parallel tests
* Use data driven (Database / Excel sourced) tests
* Reuse code, which is proven to work
* Minimise code duplication


Coding standards to try and adhere to;
* Write as few lines as possible.
* Use appropriate naming conventions.
* Segment blocks of code in the same section into paragraphs.
* Use indentation to mark the beginning and end of control structures. Specify the code between them.
* Don’t use lengthy functions. Ideally, a single function should carry out a single task.
* Use the DRY (Don’t Repeat Yourself) principle. Automate repetitive tasks whenever necessary. The same piece of code should not be repeated in the script.
* Avoid Deep Nesting. Too many nesting levels make code harder to read and follow.
* Capitalize SQL special words and function names to distinguish them from table and column names.
* Avoid long lines. It is easier for humans to read blocks of lines that are horizontally short and vertically long.
* Divide code into smaller, self-contained modules or functions for reusability and maintainability. Identify inefficient algorithms or data structures and refactor for better performance.


Use comments to add steps or descriptions to the test.  Include TODO statements so that the script can be enhanced in future.
When to add comments:

* Include comments for intricate or non-obvious code segments.
* Explain business rules, domain-specific logic, or regulatory requirements.
* Clarify how your code handles edge cases or exceptional scenarios.
* Document workarounds due to limitations or external dependencies.
* Mark areas where improvements or additional features are needed.

When Not to add comments:

* Avoid redundant comments that merely repeat what the code already expresses clearly.
* If the code’s purpose is evident (e.g., simple variable assignments), skip unnecessary comments.
* Remove temporary comments used for debugging once the issue is resolved.
* Incorrect comments can mislead other developers, so ensure accuracy.

Resources for learning
1. https://www.youtube.com/@ChecklyHQ
2. https://www.youtube.com/@CommitQuality
3. https://www.youtube.com/@QaAutomationAlchemist
4. https://www.youtube.com/@Playwrightdev
5. https://www.youtube.com/@RaghavPal
6. For internal users - https://hexagon.udemy.com/course/playwright-tutorials-automation-testing/?utm_campaign=share-to-teams-from-product&utm_source=ms-teams