class checkAvailableUnits {
    constructor() {
    }

    Check() {

        // Import the mysql2 module
        const mysql = require('mysql2');
        // Create a connection to the database
        const connection = mysql.createConnection({
            host: 'https://metpsprd7777bzqaxfsjg.database.windows.net',
            user: 'metpsDbOwner',
            password: 'D2jwwhleaoxw32x!',
            database: 'sqldb-metpsprddispatch'
        });
        // Connect to the database
        connection.connect(error => {
            if (error) {
                console.error('Error connecting to the database:', error);
                return;
            }
            console.log('Connected to the database');
        });
        // Run a database query
        connection.query('select AU.UnitId from activeunit AU where AU.Status = 0', (error, results) => {
            if (error) {
                console.error('Error executing query:', error);
                return;
            }
            console.log('Query results:', results);
        });
        // Close the connection
        connection.end();
        // Initialize an empty array to store available units
        this.availableUnits = [];
    }

    checkAvailableUnits(units) {
        this.availableUnits = units.filter((unit) => unit.isAvailable);
        return this.availableUnits;
    }
}
module.exports = { checkAvailableUnits };
// const { checkAvailableUnits } = require('./helpers/checkAvailableUnits');