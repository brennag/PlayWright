//connect to SQL DB
 const mysql = require('mysql2');
 const connection = mysql.createConnection({
     host: 'https://metpsprd7777bzqaxfsjg.database.windows.net',
     user: 'metpsDbOwner',
     password: 'D2jwwhleaoxw32x!',
     database: 'sqldb-metpsprddispatch',
    });
// Connect to the database
