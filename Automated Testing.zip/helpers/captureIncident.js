
    await expect(page.locator('#CALLTAKER-ORIGINAL-VIEW')).toContainText('Incident Information');
    //Record Incident Information
    const IncidentInfo = page.getByText('Incident Information:');
    const IncRegex = new RegExp('MPS\\d+');
    const IncidentNumber = IncRegex.exec(IncidentInfo)[0].toString();
    if (IncidentNumber !== null) {
        console.log(IncidentNumber)
    }
    else {
        console.log('Incident Number not found')
    }

    OR USE Regex
    const textBetween = FullText ? FullText.match(/: (.*?) \|/) : null;
    console.log(`text is: ${textBetween}`);
    const IncidentID = textBetween ? textBetween[1] : null;
    