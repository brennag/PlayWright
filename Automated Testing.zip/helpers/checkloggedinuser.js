class loggedInUser {
    constructor(page){

// Import the mysql2 module
const mysql = require('mysql2');

// Create a connection to the database
const connection = mysql.createConnection({
  host: 'https://metpsprd7777bzqaxfsjg.database.windows.net',     // Replace with your host
  user: 'metpsDbOwner',          // Replace with your username
  password: 'D2jwwhleaoxw32x!',          // Replace with your password
  database: 'sqldb-metpsprddispatch'       // Replace with your database name
});

// Connect to the database
connection.connect(error => {
  if (error) {
    console.error('Error connecting to the database:', error);
    return;
  }
  console.log('Connected to the database');
});

// Run a database query
connection.query('select DE.firstname, DE.lastname,DE.employeeid, de.UserName from definedemployee DE, definedemployeesession DES where DE.EmployeeId=DES.EmployeeId', (error, results) => {
  if (error) {
    console.error('Error executing query:', error);
    return;
  }
  console.log('Query results:', results);
});

// Close the connection
connection.end();
}}
module.exports={loggedInUser}