var mysql = require('mysql');

const connection = mysql.createConnection({
  host: 'metpsprd7777bzqaxfsjg.database.windows.net',     // Replace with your host
  user: 'metpsDbOwner',          // Replace with your username
  password: 'D2jwwhleaoxw32x!',          // Replace with your password
  database: 'sqldb-metpsprddispatch'       // Replace with your database name
});

connection.connect(error => {
  if (error) {
    console.error('Error connecting to the database:', error);
    return;
  }
  console.log('Connected to the database');
});


connection.query('select DE.firstname, DE.lastname,DE.employeeid, de.UserName from definedemployee DE, definedemployeesession DES where DE.EmployeeId=DES.EmployeeId', (error, results) => {
  if (error) {
    console.error('Error executing query:', error);
    return;
  }
  console.log('Query results:', results);
});

connection.end();