class Menu 
{
    constructor(page)
    {
        this.page =page;
        this.menuicon =page.locator("//button[@class='oc-navbar-toggle']");
      

    }
    async enterfrommenu(option1,option2,option3)
    {
        await this.menuicon.click()
        await this.page.getByText(`${option1}`, { exact: true }).first().click()
        await this.page.getByText(`${option2}`, { exact: true }).click()
        
          if (option3!=null)
            {
                await this.page.getByText(`${option3}`, { exact: true }).click();
            }    
            else
            {
                console.log(`"the option 3 is ${option3}"`)
            }
    }
}
module.exports ={Menu};