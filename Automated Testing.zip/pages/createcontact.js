const { validateHeaderValue } = require("http")
const { expect } = require("playwright/test")

exports.CreateContactPage = class CreateContactPage {

    constructor(page) {
        //Locators within the page
        //create contact essential elements
        this.page = page
        this.createcontact_tab = page.getByTitle('Create Contact')
        this.clearform_button = page.getByTitle('Clear Form').getByRole('img')
        this.location_field = page.locator('.dialog-location-input').first()
        this.location_selection = page.getByRole('button', { name: '#address' })
        this.eventType_dropdown = page.locator('#event-type-select svg')
        this.eventType_dropdown_selection = page.getByText('#eventtype', { exact: true })
        this.eventSubtype_dropdown = page.locator('#event-sub-type-select svg')
        this.eventSubtype_dropdown_selection = page.getByText('#eventsubtype', { exact: true })
        this.sendToDispatch_button = page.getByRole('button', { name: 'Send to Despatch' })
        //contact form sections navigation
        this.contactSection = page.getByTitle('Contact Form')
        this.commentSection = page.getByTitle('Comments', { exact: true })
        //||
        //==>
            this.comments_textbox = page.locator('.divRemarkInputField')
            this.commentsPinScrolling_button = page.getByTitle('Scrolling Off/On').getByRole('img')
            this.commentsSearch_button = page.getByTitle('Search for keywords')
            this.commentsRemarksSearch_button = page.getByRole('searchbox', { name: 'Remark Search' })
            this.commentsSettings_button = page.getByTitle('Settings').getByRole('img')
            //||
            //==>
                this.commentsSettingsShowAvatar_toggle = page.locator('#navTab').getByRole('button').first()
                this.commentsSettingsShowTimestamps_toggle = page.locator('#navTab').getByRole('button').nth(1)
                this.commentsSettingsUserSettings_toggle = page.locator('span').filter({ hasText: 'User Settings' }).getByRole('button')
                this.commentsSettingsShowAll_Checkbox = page.locator('label').filter({ hasText: 'Show All' })
                this.commentsSettingsShowPositionID_checkbox = page.getByText('Show Position ID')
                this.commentsSettingsShowUserNames_checkbox = page.getByText('Show User Names')
                this.commentsSettingsShowEmployeeID_checkbox = page.getByText('Show Employee ID')
                this.commentsSettingsCommon_RadioButton = page.locator('label').filter({ hasText: 'Common' })
                this.commentsSettingsFontSize85_RadioButton = page.locator('label').filter({ hasText: 'Small - 85%' })
                this.commentsSettingsFontSizeNormal_RadioButton = page.locator('label').filter({ hasText: 'Normal - 100%' })
                this.commentsSettingsFontSizeLarge_RadioButton = page.locator('label').filter({ hasText: 'Large - 115%' })
                this.commentsSettingsFontSizeXL_RadioButton = page.locator('label').filter({ hasText: 'XL - 125%' })
                this.commentsSettingsFontSizeXXL_RadioButton = page.locator('label').filter({ hasText: 'XXL - 150%' })
                this.commentsSettingsSortByNewest_RadioButton = page.locator('label').filter({ hasText: 'New on Top' })
                this.commentsSettingsSortByOldest_RadioButton = page.locator('label').filter({ hasText: 'Oldest on Top' })
                this.commentsSettingsSpacingDefault_RadioButton = page.locator('label').filter({ hasText: 'Default' })
                this.commentsSettingsSpacingTight_RadioButton = page.locator('label').filter({ hasText: 'Tight' })
            this.commentsDock_button = page.getByRole('img', { name: 'Dock Comments' })
            this.commentsStyle_button = page.getByTitle('Style').locator('i')
            //||
            //==>
                this.commentsStyleNormal_RadioButton = page.locator('label').filter({ hasText: /^Normal$/ })
                this.commentsStyleHigh_RadioButton = page.locator('label').filter({ hasText: 'High Priority' })
                this.commentsStyleMedium_RadioButton = page.locator('label').filter({ hasText: 'Medium Priority' })
                this.commentsStyleCritical_RadioButton = page.locator('label').filter({ hasText: 'Critical Priority' })

        this.attachmentSection = page.getByTitle('Attachments', { exact: true })
        //||
        //==>
            this.attachmentsSelectAll_checkbox = page.getByRole('row', { name: 'Name Type' }).locator('label')
            this.attachmentSelect_checkbox = page.getByRole('row', { name: 'row' }).locator('label')
            this.attachmentName_label = page.getByText(filename)
            this.attachmentSecurityLevel_label = page.getByText(securitylevel)
            this.attachmentNameColumn_header = page.getByRole('columnheader', { name: 'Name' })
            this.attachmentTypeColumn_header = page.getByRole('columnheader', { name: 'Type' })
            this.attachmentaddAttachment_button = page.getByRole('button', { name: 'Add Attachment' })
                //||
                //==>
                this.attachmentSecurityLevel_dropdown = page.locator('div:nth-child(4) > div > #HxgnSelector > .hxgn-inner-select__control > .hxgn-inner-select__indicators > .hxgn-inner-select__indicator > .css-19bqh2r')
                this.attachmentSecurityLevel_selection = page.locator('div:nth-child(4) > div > #HxgnSelector > .hxgn-inner-select__control > .hxgn-inner-select__value-container')
                this.attachmentSecurity_option = page.getByText(securitylevel, { exact: true })
                this.attachmentCancel_button = page.getByRole('button', { name: 'Cancel' })
                this.attachmentAttach_button = page.getByRole('button', { name: 'Attach', exact: true })
                this.attachmentName-label = page.getByText(filename)
        this.suppinfoSection = page.getByTitle('Supp Info', { exact: true })
        //||
        //==>
            this.suppinfoFilterDisplay_selection = page.getByTestId('supp-info-panel').locator('div').filter({ hasText: /^Show All$/ }).nth(3)
            this.suppinfoFilterDisplay_dropdown = page.getByTestId('supp-info-panel').locator('svg')
            this.addEditSuppInfo_button = page.getByRole('button', { name: 'Add / Edit Supplemental' })
            this.suppinfoAddEdit_dialog = page.getByRole('button', { name: 'Add Edit Supplemental – × -' })
            this.suppinfoAddEdit_dialog_close = page.getByRole('button', { name: '×', exact: true })
            this.suppinfoAddEdit_dialog_minimise = page.getByRole('button', { name: '–', exact: true })
            //||
            //==>
                this.suppinfoPersonTab_button = page.getByRole('button', { name: 'Person (0)', exact: true })
                //||
                //==>
                    this.suppinfoPersonReason_selection = page.getByRole('button', { name: 'Person (0)', exact: true })
                    this.suppinfoPersonReason_selector = page.locator('#react-select-36-option-0')
                    this.suppinfoPersonReason_input = page.locator('#react-select-36-input')
                    this.suppinfoPersonTitle_textbox = page.locator('#Title')
                    this.suppinfoSurname_textbox = page.locator('#Surname')
                    this.suppinfoMaidenname_textbox = page.locator('#MaidenName')
                    this.suppinfoForename_textbox = page.locator('#Forename')
                    this.suppinfoNickname_textbox = page.locator('#NickName')
                    this.suppinfoDoB_textbox = page.locator('#Ukdob')
                    this.suppinfoApparentAge_textbox = page.locator('#Age')
                    this.suppinfoSex_dropdown = page.locator('#react-select-37-input')
                    this.suppinfoEthnicity_dropdown = page.locator('#react-select-38-input')
                    this.suppinfoHeight_textbox = page.locator('#PersonHeight')
                    this.suppinfoMarksOrScars_textbox = page.locator('#MarksScars')
                    this.suppinfoUnitID_dropdown = page.locator('#react-select-39-input')
                    this.suppinfoMobilePhoneNumber_textbox = page.locator('#PhoneNumber')
                    this.suppinfoHomePhoneNumber_textbox = page.locator('#PhoneNumberHome')
                    this.suppinfoPersonType_dropdown = page.locator('#react-select-40-input')
                    this.suppinfoWorkPhoneNumber_textbox = page.locator('#PhoneNumberWork')
                    this.suppinfoOtherPhoneNumber_textbox = page.locator('#PhoneNumberOther')
                    this.suppinfoEmailAddress_textbox = page.locator('#EmailAddress')
                    this.suppinfoSocialMedia_textbox = page.locator('#SocialMedia')
                    this.suppinfoIDDocRef_textbox = page.locator('#IDDocRef')
                    this.suppinfoRemarks_textbox = page.locator('#IDDocRef')
                    this.suppinfoOccupation_textbox = page.locator('#Occupation')
                    this.suppinfoAddress_textbox = page.locator('#Address')
                    this.suppinfoOrganisation_textbox = page.locator('#OrganisationBusinessName')
                    this.suppinfoPNCReason_dropdown = page.locator('#react-select-41-input')
                    this.suppinfoRequestPOLESearch_dropdown = page.locator('#react-select-42-input')
                    this.suppinfoRequestorEmployeeID_textbox = page.locator('#RequestorEmployeeID')
                    this.suppinfoVehicleLink_textbox = page.locator('#VehicleLink')
                    this.suppinfoPropertyLink_textbox = page.locator('#PropertyLink')
                    this.suppinfoCommon_checkbox = page.getByRole('checkbox')
                    this.suppinfoAddPerson_button = page.getByRole('button', { name: 'Add Person', exact: true })
                    //^
                this.suppinfoVehicleTab_button = page.getByRole('button', { name: 'Vehicle (0)', exact: true })
                // ||
                // ==>
                    VehicleStatus
                    this.suppinfoVehicleVRN_textbox = page.locator('#LicensePlateNumber')
                    this.suppinfoVehicleMake_textbox = page.locator('#Make')
                    this.suppinfoVehicleModel_textbox = page.locator('#Model')
                    this.suppinfoVehicleColour_textbox = page.locator('#Colour')
                    VehicleType
                    this.suppinfoVehicleChassis_textbox = page.locator('#Chassis')
                    this.suppinfoVehicleEngine_textbox = page.locator('#Engine')
                    this.suppinfoVehicleVIN_textbox = page.locator('#Vin')
                    VehiclePNCResonNumber
                    VehicleRequestPoleSearch
                    this.suppinfoVehicleRequestorEmployeeID_textbox = page.locator('#RequestorEmployeeID')
                    this.suppinfoVehicleDescription_textbox = page.locator('#Description')
                    this.suppinfoVehicleLinks_textbox = page.locator('#Links')
                    this.suppinfoVehicleOriginatorEmployeeID_textbox = page.locator('#OriginatorEmployeeId')
                    this.suppinfoVehicleAddVehicle_buton = page.getByRole('button', { name: 'Add Vehicle', exact: true })
                    // ^
                this.suppinfoPropertyTab_button = getByRole('button', { name: 'Property (0)', exact: true })
                // ||
                // ==>
                    this.suppinfoPropertyType_dropdown = blah
                    this.suppinfoPropertyStatus_dropdown = blah
                    this.suppinfoPropertyCurrency_dropdown = blah
                    this.suppinfoPropertyValue_textbox = page.locator('#Value')
                    this.suppinfoPropertyMake_textbox = page.locator('#Make')
                    this.suppinfoPropertyModel_textbox = page.locator('#Model')
                    this.suppinfoPropertySerialNumber_textbox = page.locator('#SerialNumber')
                    this.suppinfoPropertyIMEINumber_textbox = page.locator('#IMEINumber')
                    this.suppinfoPropertyMark_textbox = page.locator('#PropertyMark')
                    this.suppinfoPropertyInscription_textbox = page.locator('#Inscription')
                    this.suppinfoPropertyDescription_textbox = page.locator('#Description')
                    PropertyRequestPoleSearch
                    this.suppinfoPropertySuppInfoLinks_textbox = page.locator('#SuppInfoLinks')
                    this.suppinfoPropertyAddProperty_button = page.getByRole('button', { name: 'Add Property', exact: true })
                    //^
                this.suppinfoReferencesTab_button = page.getByRole('button', { name: 'References (0)', exact: true })
                // ||
                // ==>
                    suppinfoReferencesInternalMPSReference_dropdown = blah
                    suppinfoReferencesReferenceNumber_textbox = page.locator('#ReferenceNumber')
                    NeighbouringPoliceForce
                    UKPoliceForces
                    OtherAgencies
                    PartnerAgencies
                    LocalAuthorities
                    suppinfoReferencesRefOtherOrg_textbox = page.locator('#ReferenceOtherOrganisation')
                    suppinfoReferencesRefComments_textbox = page.locator('#ReferenceComments')
                    suppinfoReferencesAddReferences_button = page.getByRole('button', { name: 'Add Reference', exact: true })




        //Test for visibility of incident number expect(page.getByText('Incident Information:')).toBeVisible();
    }

    async gotoCreateContactPage() {
        await this.page.goto('https://metps-dispatch.hexagonsi.com/oncall/#!/oncall/?tab=Create%20Contact');
        await expect (this.page).toHaveTitle('Create Contact');
    }

    async createContact(address, eventtype, eventsubtype) {
        await this.clearform_button.click();
        await this.location_field.click();
        await this.location_field.fill(address);
        await this.location_selection.click(address);
        await this.eventType_dropdown.click();
        await this.eventType_dropdown_selection.click(eventtype);
        await this.eventSubtype_dropdown.click();
        await this.eventSubtype_dropdown_selection.click(eventsubtype);
        await this.sendToDispatch_button.click();

    }

    async navigateContact() {
        await this.contactSection.click();
        await this.commentSection.click();
        await this.attachmentSection.click();
        await this.suppinfoSection.click();

    }

    async addsuppinfoPerson(){

        await page.getByRole('button', { name: 'Add Edit Supplemental – × -' }).click();
        
        await page.getByRole('button', { name: 'Add / Edit Supplemental' }).click();
        //Reason
        await page.locator('#react-select-36-input').press('ArrowDown');
        await page.locator('#react-select-36-option-0').click();
        await page.locator('#react-select-36-input').press('Tab');
        await page.locator('#Title').fill('Mr');
        await page.locator('#Title').press('Tab');
        await page.locator('#Surname').fill('Brennan');
        await page.locator('#Surname').press('Tab');
        await page.locator('#MaidenName').fill('Strange');
        await page.locator('#MaidenName').press('Tab');
        await page.locator('#Forename').fill('Gary');
        await page.locator('#Forename').press('Tab');
        await page.locator('#NickName').fill('GZA');
        await page.locator('#NickName').press('Tab');
        await page.locator('#Ukdob').fill('04/09/1979');
        await page.locator('#Ukdob').press('Tab');
        await page.locator('#Age').press('Tab');
        await page.locator('#react-select-37-input').press('ArrowDown');
        await page.locator('#react-select-37-input').press('Enter');
        await page.locator('#react-select-37-input').press('Tab');
        await page.locator('#react-select-38-input').press('ArrowDown');
        await page.locator('#react-select-38-input').press('Enter');
        await page.locator('#react-select-38-input').press('Tab');
        await page.locator('#PersonHeight').fill('M180');
        await page.locator('#PersonHeight').press('Tab');
        await page.locator('#MarksScars').fill('None');
        await page.locator('#MarksScars').press('Tab');
        await page.locator('#react-select-39-input').press('ArrowDown');
        await page.locator('#react-select-39-input').press('ArrowDown');
        await page.locator('#react-select-39-input').press('Enter');
        await page.locator('#react-select-39-input').press('Tab');
        await page.locator('#PhoneNumber').fill('07412511475');
        await page.locator('#PhoneNumber').press('Tab');
        await page.locator('#PhoneNumberHome').fill('01249444630');
        await page.locator('#PhoneNumberHome').press('Tab');
        await page.locator('#react-select-40-input').press('ArrowDown');
        await page.locator('#react-select-40-input').press('Enter');
        await page.locator('#react-select-40-input').press('Tab');
        await page.locator('#PhoneNumberWork').fill('01793598657');
        await page.locator('#PhoneNumberWork').press('Tab');
        await page.locator('#PhoneNumberOther').fill('01793555888');
        await page.locator('#PhoneNumberOther').press('Tab');
        await page.locator('#EmailAddress').fill('gary.brennan@gmail.com');
        await page.locator('#EmailAddress').press('Tab');
        await page.locator('#SocialMedia').fill('bobwalooooza');
        await page.locator('#SocialMedia').press('Tab');
        await page.locator('#IDDocRef').fill('5hhuhud');
        await page.locator('#IDDocRef').press('Tab');
        await page.locator('#Remarks').fill('this is a comment');
        await page.locator('#Remarks').press('Tab');
        await page.locator('#Occupation').fill('IT manager');
        await page.locator('#Occupation').press('Tab');
        await page.locator('#Address').fill('29 The Broadway');
        await page.locator('#Address').press('Tab');
        await page.locator('#OrganisationBusinessName').fill('Hexagon');
        await page.locator('#OrganisationBusinessName').press('Tab');
        await page.locator('#react-select-41-input').press('ArrowDown');
        await page.locator('#react-select-41-input').press('ArrowDown');
        await page.locator('#react-select-41-input').press('ArrowDown');
        await page.locator('#react-select-41-input').press('ArrowDown');
        await page.locator('#react-select-41-input').press('ArrowDown');
        await page.locator('#react-select-41-input').press('ArrowDown');
        await page.locator('#react-select-41-input').press('ArrowUp');
        await page.locator('#react-select-41-input').press('Enter');
        await page.locator('#react-select-41-input').press('Tab');
        await page.locator('#react-select-42-input').press('ArrowDown');
        await page.locator('#react-select-42-input').press('Enter');
        await page.locator('#react-select-42-input').press('Tab');
        await page.locator('#RequestorEmployeeID').fill('111111');
        await page.locator('#RequestorEmployeeID').press('Tab');
        await page.locator('#VehicleLink').fill('None');
        await page.locator('#VehicleLink').press('Tab');
        await page.locator('#PropertyLink').fill('None');
        await page.locator('#PropertyLink').press('Tab');
        await page.getByRole('checkbox').uncheck();
        await page.getByRole('checkbox').press('Tab');
        await page.getByRole('button', { name: 'Add Person', exact: true }).click();
        

        
    }
}